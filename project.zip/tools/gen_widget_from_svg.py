# Builds the Home Screen "Cassette Player" widget art + layout directly from the real
# Now Playing SVG skins in app/src/main/assets/index.html, so the widget has the SAME structure
# (360 x 322 design units) as the Now Playing screen. Needs: python3, playwright + chromium.
#   python3 tools/gen_widget_from_svg.py
import re, os, sys, math
from playwright.sync_api import sync_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
HTML = os.path.join(HERE, "..", "app", "src", "main", "assets", "index.html")
RES = os.path.join(HERE, "..", "app", "src", "main", "res")
OUT = os.path.join(RES, "drawable-nodpi")
LAYOUT_OUT = os.path.join(RES, "layout", "widget_cassette.xml")
INFO = {}   # clock geometry per skin, filled while rendering
KEYS = ["cas", "cas2", "cas3", "cas4", "cas5", "cd", "cd2", "cd3", "cd4", "cd5"]
VW, VH = 360.0, 322.0
FW, FH = 900, 805                 # background png size (2.5 px per unit)
# The reel has 6 spokes (60 deg symmetry). A frame step above 30 deg looks like it turns BACKWARDS (wagon-wheel effect),
# so use 30 frames = 12 deg per frame (smooth, and still turns the right way).
REEL_FRAMES = 30
REEL_FLIP_MS = 187   # widget: 30 frames x 187 ms. On the real phone the widget ran twice as fast as the computed value,
                     # so this is calibrated by observation (Now Playing turns in 2.8 s) - change this number if still off.
KEY_W, KEY_H, KEY_Y, KEY_PITCH = 34.0, 36.0, 266.0, 38.5714286
KEY_X0 = 180.0 - 3 * KEY_PITCH - KEY_W / 2      # 7 keys centred like the Now Playing screen

# header timers: two LCD boxes (REC time, PLAY time). Native views (LED, label, chronometer, highlight) are placed on them.
HDR_TAPE = dict(y=71.0, h=24.0, x=(22.0, 126.0), w=100.0)
HDR_CD = dict(y=19.0, h=19.0, x=(22.0, 126.0), w=100.0)

src = open(HTML, encoding="utf-8").read()
FONT = re.search(r"body\{[^}]*font-family:([^;}]+)", src)
FONT = FONT.group(1).strip() if FONT else "sans-serif"


# render with the REAL page stylesheet so fonts / strokes / paused animation states are exactly what Now Playing shows
STYLE = "\n".join(re.findall(r"<style[^>]*>(.*?)</style>", src, re.S))


def svg_of(k):
    i = src.index('id="sk-%s"' % k)
    j = src.index("<svg", i)
    e = src.index("</svg>", j) + 6
    return src[j:e]


def page_html(svg, w, h):
    svg = re.sub(r"<svg ", '<svg width="%d" height="%d" ' % (w, h), svg, count=1)
    return ("<html><head><style>%s</style></head><body style=\"margin:0;background:transparent;font-family:%s\"><div id=\"np\">%s</div></body></html>" % (STYLE, FONT, svg))


def shot(page, svg, w, h, js, path, vb=None):
    page.set_viewport_size({"width": w, "height": h})
    page.set_content(page_html(svg, w, h))
    page.wait_for_timeout(120)
    page.evaluate("([js,vb])=>{const svg=document.querySelector('svg');if(vb)svg.setAttribute('viewBox',vb);(new Function('svg',js))(svg)}", [js, vb])
    page.wait_for_timeout(60)
    page.screenshot(path=os.path.join(OUT, path), omit_background=True, clip={"x": 0, "y": 0, "width": w, "height": h})


# ---------------------------------------------------------------- JS snippets
JS_BG = """
svg.querySelectorAll('.led-r,.led-p,.led-s,.sk-time,.sk-t,.cass-img,.ck,.reel,.pack,.tape,.disk').forEach(e=>e.remove());
svg.querySelectorAll('text').forEach(t=>{const s=t.textContent.trim();if(s==='SIDE A'||s==='90 min')t.remove()});
svg.querySelectorAll('path').forEach(p=>{if(p.getAttribute('stroke')==='#fff'&&p.getAttribute('stroke-linecap')==='round'&&p.getAttribute('fill')==='none')p.remove()});
const keys=[...svg.querySelectorAll('g.key')];const rec=keys[0];
const body=rec.children[0],sheen=rec.children[1];
keys.forEach(k=>k.remove());
const X0=%(x0)f,P=%(p)f;
for(let i=0;i<7;i++){const x=X0+i*P;
 const b=body.cloneNode(true);b.setAttribute('x',x);svg.appendChild(b);
 const s=sheen.cloneNode(true);s.setAttribute('x',x+3);svg.appendChild(s);}
""" % {"x0": KEY_X0, "p": KEY_PITCH}

JS_HDR = """
(function(){
 const NS='http://www.w3.org/2000/svg';
 let acc='#9fd3ff';
 const tape=!!svg.querySelector('rect[stroke="#47506a"]');
 svg.querySelectorAll('text').forEach(t=>{const s=t.textContent.trim();if(s==='REC'||s==='PLAY'){acc=t.getAttribute('fill');t.remove()}});
 svg.querySelectorAll('rect[stroke="#47506a"]').forEach(r=>r.remove());
 const G=tape?%(tape)s:%(cd)s;
 G.x.forEach(x=>{const r=document.createElementNS(NS,'rect');
  r.setAttribute('x',x);r.setAttribute('y',G.y);r.setAttribute('width',G.w);r.setAttribute('height',G.h);r.setAttribute('rx',4);
  r.setAttribute('fill',tape?'#0e1a0e':'#0a0d14');r.setAttribute('stroke',tape?'#47506a':acc);r.setAttribute('stroke-width',tape?1.5:1);
  if(!tape)r.setAttribute('stroke-opacity','.7');svg.appendChild(r);});
 if(!tape)svg.querySelectorAll('text').forEach(t=>{const y=parseFloat(t.getAttribute('y'));if(y===46||y===58)t.setAttribute('y',y+5)});
})();
""" % {"tape": "{x:[22,126],y:71,w:100,h:24}", "cd": "{x:[22,126],y:19,w:100,h:19}"}

JS_ONLY = """
function keep(svg,sel){const ks=new Set();
 svg.querySelectorAll(sel).forEach(e=>{let n=e;while(n&&n!==svg){ks.add(n);n=n.parentNode}e.querySelectorAll('*').forEach(x=>ks.add(x));});
 [...svg.querySelectorAll('*')].forEach(e=>{if(e.tagName==='defs'||e.closest('defs')||ks.has(e))return;if(e.parentNode)e.remove();});}
keep(svg,'%s');
"""


def main():
    os.makedirs(OUT, exist_ok=True)
    with sync_playwright() as p:
        br = p.chromium.launch()
        page = br.new_page(viewport={"width": FW, "height": FH}, device_scale_factor=1)
        classes = set()
        for si, k in enumerate(KEYS):
            svg = svg_of(k)
            classes |= set(re.findall(r'class="([^"]+)"', svg))
            # 1) static background
            shot(page, svg, FW, FH, JS_BG + JS_HDR, "ck_bg%d.png" % si)
            # 2) clock: dial + hands
            gm = re.search(r'<g class="ck" data-x="([\d.]+)" data-y="([\d.]+)">(<(?:circle|rect)[^>]*>)', svg)
            cx, cy = float(gm.group(1)), float(gm.group(2))
            first = gm.group(3)
            sw = float(re.search(r'stroke-width="([\d.]+)"', first).group(1))
            if first.startswith("<circle"):
                r = float(re.search(r' r="([\d.]+)"', first).group(1))
            else:
                r = float(re.search(r' width="([\d.]+)"', first).group(1)) / 2
            R = r + sw / 2 + 1.0
            S = 400 if si < 5 else 440
            vb = "%f %f %f %f" % (cx - R, cy - R, 2 * R, 2 * R)
            INFO[si] = dict(cx=cx, cy=cy, R=R)
            shot(page, svg, S, S, (JS_ONLY % ".ck") +
                 "svg.querySelectorAll('.hh,.mh,.sh').forEach(e=>e.remove());const g=svg.querySelector('.ck');"
                 "const cs=[...g.querySelectorAll(':scope > circle')];cs[cs.length-1].remove();cs[cs.length-2].remove();",
                 "ck_dial%d.png" % (si + 1), vb)
            hw = 7.0
            hb = "%f %f %f %f" % (cx - hw, cy - R, 2 * hw, 2 * R)
            hwpx = int(round(S * (2 * hw) / (2 * R)))
            for cls, nm in (("hh", "hh"), ("mh", "hm"), ("sh", "hs")):
                extra = ""
                if cls == "sh":   # centre cap goes on the second hand
                    extra = ""
                js = (JS_ONLY % ".ck") + (
                    "const g=svg.querySelector('.ck');const cs=[...g.querySelectorAll(':scope > circle')];"
                    "const caps=[cs[cs.length-1],cs[cs.length-2]];"
                    "[...g.children].forEach(c=>{const keep=c.classList.contains('%s')||(%s&&caps.includes(c));if(!keep)c.remove()});"
                    % (cls, "true" if cls == "sh" else "false"))
                shot(page, svg, hwpx, S, js, "ck_%s%d.png" % (nm, si + 1), hb)
            # 3) CD disc frames (each CD skin has its own disc colours)
            if si >= 5:
                R2 = 64.0
                vb2 = "%f %f %f %f" % (108 - R2, 146 - R2, 2 * R2, 2 * R2)
                for f in range(1):
                    js = (JS_ONLY % ".disk") + ("const d=svg.querySelector('.disk');d.removeAttribute('style');d.style.animation='none';d.setAttribute('transform','rotate(%d 108 146)');"
                                               "d.querySelectorAll('.sk-art').forEach(e=>e.remove());" % (f * 30))
                    shot(page, svg, 320, 320, js, "ck_d%d_%02d.png" % (si, f), vb2)
            # 4) CD highlights (static arcs drawn over the disc)
            if si == 5:
                R2 = 70.0
                vb2 = "%f %f %f %f" % (108 - R2, 146 - R2, 2 * R2, 2 * R2)
                js = ("[...svg.children].forEach(c=>{if(c.tagName==='defs')return;"
                      "const keep=c.tagName==='path'&&c.getAttribute('stroke')==='#fff'&&c.getAttribute('stroke-linecap')==='round'&&c.getAttribute('fill')==='none';"
                      "if(!keep)c.remove()});")
                shot(page, svg, 280, 280, js, "ck_cd_hl.png", vb2)
            # 5) tape reel + packs (identical on all tape skins) and key glyphs
            if si == 0:
                R2 = 18.0
                for f in range(1):
                    js = (JS_ONLY % ".reel") + ("const r=svg.querySelector('.reel.a');r.removeAttribute('style');r.style.animation='none';r.setAttribute('transform','rotate(%f 132 201)');" % (f * 360.0))
                    shot(page, svg, 192, 192, js, "ck_reel_g%d.png" % f, "%f %f %f %f" % (132 - R2, 201 - R2, 2 * R2, 2 * R2))
                R3 = 23.0
                for lv in range(8):
                    sc = 0.7 + (1.04 - 0.7) * lv / 7.0
                    js = (JS_ONLY % ".pack") + ("const a=svg.querySelector('.pkA');svg.querySelectorAll('.pack').forEach(e=>{if(e!==a)e.remove()});"
                                               "a.removeAttribute('style');a.style.animation='none';a.setAttribute('transform','translate(132 201) scale(%f) translate(-132 -201)');" % sc)
                    shot(page, svg, 160, 160, js, "ck_pack%d.png" % lv, "%f %f %f %f" % (132 - R3, 201 - R3, 2 * R3, 2 * R3))
                names = ["rec", "prev", "rew", "play", "pause", "ff", "next", "stop"]
                for ki, nm in enumerate(names):
                    js = ("[...svg.children].forEach(c=>{if(c.tagName!=='defs'&&!(c.matches&&c.matches('.k-%s')))c.remove()});"
                          "const g=svg.querySelector('.k-%s');[...g.children].slice(0,2).forEach(e=>e.remove());" % (nm, nm))
                    # key x for this key inside the SVG
                    kx = float(re.search(r'<g class="key k-%s" data-k="%s"><rect x="([\d.]+)"' % (nm, nm), svg).group(1))
                    shot(page, svg, 136, 144, js, "ck_ic_%s.png" % nm, "%f %f %f %f" % (kx, KEY_Y, KEY_W, KEY_H))
                # LEDs
                led = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12 12" width="48" height="48">'
                       '<circle cx="6" cy="6" r="3.6" fill="%s" style="filter:drop-shadow(0 0 %s %s)"/></svg>')
                for nm, col, gl in (("rec_off", "#5a1a1a", ""), ("rec_on", "#ff3030", "#ff3333"),
                                    ("play_off", "#1b3a22", ""), ("play_on", "#39ff5a", "#39ff5a")):
                    page.set_viewport_size({"width": 48, "height": 48})
                    page.set_content("<html><body style='margin:0;background:transparent'>%s</body></html>" %
                                     (led % (col, "1.2" if gl else "0", gl or "transparent")))
                    page.screenshot(path=os.path.join(OUT, "ck_led_%s.png" % nm), omit_background=True)
                # highlight glow for the REC / PLAY boxes (drawn over the box while that function is active)
                for nm, col, (bw, bh) in (("rec", "#ff3b3b", (100, 24)), ("play", "#39ff5a", (100, 24)), ("cdrec", "#ff3b3b", (100, 19)), ("cdplay", "#39ff5a", (100, 19))):
                    W, H = bw * 4, bh * 4
                    page.set_viewport_size({"width": W, "height": H})
                    page.set_content("<html><body style='margin:0;background:transparent'><svg viewBox='0 0 %d %d' width='%d' height='%d'>"
                                     "<rect x='1.5' y='1.5' width='%d' height='%d' rx='3.5' fill='%s' fill-opacity='.16' stroke='%s' stroke-width='1.6' style='filter:drop-shadow(0 0 1px %s)'/></svg></body></html>"
                                     % (bw, bh, W, H, bw - 3, bh - 3, col, col, col))
                    page.screenshot(path=os.path.join(OUT, "ck_hl_%s.png" % nm), omit_background=True)
                # skin button
                page.set_viewport_size({"width": 96, "height": 96})
                page.set_content("<html><body style='margin:0;background:transparent'><svg viewBox='0 0 24 24' width='96' height='96'>"
                                 "<circle cx='12' cy='12' r='11' fill='rgba(10,14,28,.55)' stroke='rgba(255,255,255,.55)' stroke-width='.8'/>"
                                 "<g transform='translate(5 5) scale(.58)' fill='none' stroke='#fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'>"
                                 "<polyline points='23 4 23 10 17 10'/><polyline points='1 20 1 14 7 14'/>"
                                 "<path d='M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15'/></g></svg></body></html>")
                page.screenshot(path=os.path.join(OUT, "ck_ic_skin.png"), omit_background=True)
        br.close()
    to_webp()
    print("classes seen in skins:", sorted(classes))
    write_layout()


def to_webp():
    """lossy WebP (with alpha) keeps the APK small; Android 8+ (minSdk 26) reads it from res/ like a png"""
    from PIL import Image
    n = 0
    for f in os.listdir(OUT):
        if f.startswith("ck_") and f.endswith(".png"):
            im = Image.open(os.path.join(OUT, f)).convert("RGBA")
            q = 80 if f.startswith("ck_d") and "_" in f[4:5] + f[5:6] else 88
            im.save(os.path.join(OUT, f[:-4] + ".webp"), "WEBP", quality=q, alpha_quality=90, method=6)
            os.remove(os.path.join(OUT, f))
            n += 1
    print("converted to webp:", n)


# ---------------------------------------------------------------- layout
def fmt(v):
    s = ("%.3f" % v).rstrip("0").rstrip(".")
    return s or "0"


def sp(w=None, h=None, weight=0, ver=False):
    return '<FrameLayout android:layout_width="%s" android:layout_height="%s" android:layout_weight="%s"/>' % (
        "match_parent" if ver else "0dp", "0dp" if ver else "match_parent", fmt(weight))


def at(x, y, w, h, inner):
    """place `inner` (a view with match_parent size) in the box x,y,w,h of the 360 x 322 design grid"""
    col = '<LinearLayout android:layout_width="0dp" android:layout_height="match_parent" android:layout_weight="%s" android:orientation="vertical">' % fmt(w)
    if y > 0.001:
        col += sp(weight=y, ver=True)
    col += '<FrameLayout android:layout_width="match_parent" android:layout_height="0dp" android:layout_weight="%s">%s</FrameLayout>' % (fmt(h), inner)
    if VH - y - h > 0.001:
        col += sp(weight=VH - y - h, ver=True)
    col += "</LinearLayout>"
    row = '<LinearLayout android:layout_width="match_parent" android:layout_height="match_parent" android:orientation="horizontal">'
    if x > 0.001:
        row += sp(weight=x)
    row += col
    if VW - x - w > 0.001:
        row += sp(weight=VW - x - w)
    return row + "</LinearLayout>"


def img(idn, drawable, extra=""):
    i = ' android:id="@+id/%s"' % idn if idn else ""
    sc = "" if "scaleType" in extra else ' android:scaleType="fitXY"'
    return '<ImageView%s android:layout_width="match_parent" android:layout_height="match_parent" android:src="@drawable/%s"%s%s/>' % (i, drawable, sc, extra)


def flipper(idn, frames, interval, vis=""):
    f = "".join(img(None, d) for d in frames)
    return '<ViewFlipper android:id="@+id/%s" android:layout_width="match_parent" android:layout_height="match_parent" android:flipInterval="%d" android:autoStart="true"%s>%s</ViewFlipper>' % (
        idn, interval, vis, f)


SPINS = {}


def spinner(idn, drawable, ms, rev=False, vis=""):
    """smooth, time-based rotation: ProgressBar + <rotate> drawable (Android interpolates every frame)"""
    SPINS["ck_spin_%s%s" % (drawable, "_rev" if rev else "")] = (drawable, rev)
    return ('<ProgressBar android:id="@+id/%s" style="@android:style/Widget.ProgressBar" android:layout_width="match_parent" android:layout_height="match_parent" '
            'android:indeterminate="true" android:indeterminateOnly="true" android:indeterminateDrawable="@drawable/ck_spin_%s%s" '
            'android:indeterminateDuration="%d" android:interpolator="@android:anim/linear_interpolator" android:indeterminateBehavior="repeat" '
            'android:minWidth="1dp" android:minHeight="1dp" android:maxWidth="2000dp" android:maxHeight="2000dp"%s/>') % (
        idn, drawable, "_rev" if rev else "", ms, vis)


def tv(idn, text, size, color, grav, bold=True, extra=""):
    return ('<TextView android:id="@+id/%s" android:layout_width="match_parent" android:layout_height="match_parent" android:text="%s" '
            'android:textColor="%s" android:textSize="%dsp" android:textStyle="%s" android:singleLine="true" android:ellipsize="end" '
            'android:includeFontPadding="false" android:gravity="%s"%s/>') % (idn, text, color, size, "bold" if bold else "normal", grav, extra)


def chrono(idn, size, color, grav):
    return ('<Chronometer android:id="@+id/%s" android:layout_width="match_parent" android:layout_height="match_parent" '
            'android:gravity="%s" android:textColor="%s" android:textSize="%dsp" android:textStyle="bold" android:fontFamily="monospace" '
            'android:singleLine="true" android:includeFontPadding="false"/>') % (idn, grav, color, size)


def clock(idn, n, vis):
    return ('<AnalogClock android:id="@+id/%s" android:layout_width="match_parent" android:layout_height="match_parent"%s '
            'android:dial="@drawable/ck_dial%d" android:hand_hour="@drawable/ck_hh%d" android:hand_minute="@drawable/ck_hm%d" android:hand_second="@drawable/ck_hs%d"/>') % (
        idn, vis, n, n, n, n)


def header(pfx, G, lab_sp, time_sp):
    """REC box + PLAY box: highlight glow, LED, label, chronometer.  pfx = ck (tape) or ck2 (cd)"""
    out = []
    hl = "" if pfx == "ck" else "cd"
    for i, (nm, lab) in enumerate((("rec", "REC"), ("play", "PLAY"))):
        x, y, w, h = G["x"][i], G["y"], G["w"], G["h"]
        out.append(at(x, y, w, h, img("%s_hl_%s" % (pfx, nm), "ck_hl_%s%s" % (hl, nm), ' android:visibility="gone"')))
        ls = 9 if h > 21 else 8
        out.append(at(x + 5, y + (h - ls) / 2, ls, ls, img("%s_led_%s" % (pfx, nm), "ck_led_%s_off" % nm, ' android:scaleType="fitCenter"')))
        lw = 24 if nm == "rec" else 30
        out.append(at(x + 5 + ls + 3, y, lw, h, tv("%s_lab_%s" % (pfx, nm), lab, lab_sp, "#8f98b8", "center_vertical")))
        tx = x + 5 + ls + 3 + lw
        out.append(at(tx, y, x + w - 7 - tx, h, chrono("%s_%s" % (pfx, "rtime" if nm == "rec" else "time"), time_sp, "#6b7390", "center_vertical|end")))
    return "".join(out)


def write_layout():
    # old widget XML kept the tuned flip speeds of the reels; read them from the previous file when it exists
    g = ["ck_reel_g%d" % i for i in range(REEL_FRAMES)]
    parts = []
    parts.append('<?xml version="1.0" encoding="utf-8"?>\n<!-- GENERATED by tools/gen_widget_from_svg.py : same structure as the Now Playing skins (360 x 322 design units) -->\n'
                 '<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android" android:id="@+id/w_root" android:layout_width="match_parent" android:layout_height="match_parent">')
    parts.append('<ImageView android:id="@+id/ck_bg" android:layout_width="match_parent" android:layout_height="match_parent" android:src="@drawable/ck_bg0" android:scaleType="fitXY"/>')

    # ---- cassette group
    t = []
    t.append(header("ck", HDR_TAPE, 10, 11))
    # label header: SIDE A / LIVE (left) + duration / FM (right)
    t.append(at(70, 116, 220, 13,
                '<LinearLayout android:layout_width="match_parent" android:layout_height="match_parent" android:orientation="horizontal">'
                '<TextView android:id="@+id/ck_side" android:layout_width="0dp" android:layout_height="match_parent" android:layout_weight="1" android:text="SIDE A" android:textColor="#ffffff" android:textSize="8sp" android:textStyle="bold" android:singleLine="true" android:includeFontPadding="false" android:gravity="center_vertical"/>'
                '<TextView android:id="@+id/ck_dur" android:layout_width="0dp" android:layout_height="match_parent" android:layout_weight="1" android:text="" android:textColor="#ffffff" android:textSize="8sp" android:textStyle="bold" android:singleLine="true" android:includeFontPadding="false" android:gravity="center_vertical|end"/>'
                '</LinearLayout>'))
    t.append(at(62, 133, 236, 26, tv("ck_track", "", 16, "#2b2b2b", "center", True, ' android:paddingStart="6dp" android:paddingEnd="6dp"')))
    # reels + tape packs (left = supply, right = take-up)
    for side, cxu in (("l", 132.0), ("r", 228.0)):
        t.append(at(cxu - 23, 201 - 23, 46, 46, img("ck_pack_" + side, "ck_pack7" if side == "l" else "ck_pack0")))
        reel = img("ck_reel_%s_off" % side, "ck_reel_g0")
        base_ms = REEL_FLIP_MS   # both reels equal, see REEL_FLIP_MS
        reel += spinner("ck_reel_%s_s" % side, "ck_reel_g0", 2800, False, ' android:visibility="gone"')
        reel += spinner("ck_reel_%s_ff" % side, "ck_reel_g0", 1200, False, ' android:visibility="gone"')
        reel += spinner("ck_reel_%s_rw" % side, "ck_reel_g0", 1200, True, ' android:visibility="gone"')
        t.append(at(cxu - 18, 201 - 18, 36, 36, reel))
    # clocks (one per skin, switched by the updater)
    for i in range(5):
        q = INFO[i]
        t.append(at(q["cx"] - q["R"], q["cy"] - q["R"], 2 * q["R"], 2 * q["R"],
                    clock("ck_clk%d" % (i + 1), i + 1, "" if i == 0 else ' android:visibility="gone"')))
    parts.append('<FrameLayout android:id="@+id/ck_tape_g" android:layout_width="match_parent" android:layout_height="match_parent">' + "".join(t) + "</FrameLayout>")

    # ---- CD group
    c = []
    c.append(header("ck2", HDR_CD, 8, 10))
    for s in range(5, 10):
        frames = ["ck_d%d_%02d" % (s, f) for f in range(12)]
        c.append(at(44, 82, 128, 128,
                    img("ck_cd_off%d" % s, "ck_d%d_00" % s, ' android:visibility="gone"') +
                    spinner("ck_cd_on%d" % s, "ck_d%d_00" % s, 1800, False, ' android:visibility="gone"')))
    c.append(at(38, 76, 140, 140, img(None, "ck_cd_hl")))
    for i in range(5, 10):
        q = INFO[i]
        c.append(at(q["cx"] - q["R"], q["cy"] - q["R"], 2 * q["R"], 2 * q["R"],
                    clock("ck2_clk%d" % (i + 1), i + 1, ' android:visibility="gone"')))
    c.append(at(30, 214, 300, 28, tv("ck2_track", "", 12, "#8fe3ff", "center_vertical")))
    parts.append('<FrameLayout android:id="@+id/ck_cd_g" android:layout_width="match_parent" android:layout_height="match_parent" android:visibility="gone">' + "".join(c) + "</FrameLayout>")

    # ---- keys (7, centred like Now Playing; the middle one toggles play / pause)
    ids = ["ck_k_rec", "ck_k_prev", "ck_k_rew", "ck_k_play", "ck_k_ff", "ck_k_next", "ck_k_stop"]
    icons = ["ck_ic_rec", "ck_ic_prev", "ck_ic_rew", "ck_ic_play", "ck_ic_ff", "ck_ic_next", "ck_ic_stop"]
    for i in range(7):
        parts.append(at(KEY_X0 + i * KEY_PITCH, KEY_Y, KEY_W, KEY_H,
                        '<ImageButton android:id="@+id/%s" android:layout_width="match_parent" android:layout_height="match_parent" '
                        'android:background="@android:color/transparent" android:src="@drawable/%s" android:scaleType="fitXY" android:padding="0dp" android:contentDescription="%s"/>' % (ids[i], icons[i], ids[i][5:])))
    # ---- skin button + counter (top right corner)
    parts.append(at(316, 7, 30, 30, '<ImageButton android:id="@+id/ck_skin" android:layout_width="match_parent" android:layout_height="match_parent" '
                                      'android:background="@android:color/transparent" android:src="@drawable/ck_ic_skin" android:scaleType="fitCenter" android:padding="0dp" android:contentDescription="Change skin"/>'))
    parts.append(at(308, 37, 46, 10, tv("ck_skin_n", "1/10", 7, "#dfe6f7", "center_horizontal")))
    parts.append("</FrameLayout>\n")
    open(LAYOUT_OUT, "w", encoding="utf-8").write("\n".join(parts))
    dd = os.path.join(RES, "drawable"); os.makedirs(dd, exist_ok=True)
    for nm, (dr, rev) in SPINS.items():
        a, b = (360, 0) if rev else (0, 360)
        open(os.path.join(dd, nm + ".xml"), "w").write(
            '<?xml version="1.0" encoding="utf-8"?>\n<rotate xmlns:android="http://schemas.android.com/apk/res/android" android:drawable="@drawable/%s" '
            'android:fromDegrees="%d" android:toDegrees="%d" android:pivotX="50%%" android:pivotY="50%%"/>\n' % (dr, a, b))
    print("layout written", LAYOUT_OUT)


if __name__ == "__main__":
    main()
