# Builds the Home Screen "Cassette Player" widget art + layout directly from the real
# Now Playing SVG skins in app/src/main/assets/index.html, so the widget has the SAME structure
# (360 x 322 design units) as the Now Playing screen. Needs: python3, playwright + chromium.
#   python3 tools/gen_widget_from_svg.py
import re, os, sys, math
from playwright.sync_api import sync_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
HTML = os.path.join(HERE, "..", "app", "src", "main", "assets", "index.html")
RES = os.path.join(HERE, "..", "app", "src", "main", "res")
OUT = os.path.join(RES, "drawable-nodpi")
LAYOUT_OUT = os.path.join(RES, "layout", "widget_cassette.xml")
KEYS = ["cas", "cas2", "cas3", "cas4", "cas5", "cd", "cd2", "cd3", "cd4", "cd5"]
VW, VH = 360.0, 322.0
FW, FH = 900, 805                 # background png size (2.5 px per unit)
# The reel has 6 spokes (60 deg symmetry). A frame step above 30 deg looks like it turns BACKWARDS (wagon-wheel effect),
# so use 15 frames = 24 deg per frame.
REEL_FRAMES = 15
KEY_W, KEY_H, KEY_Y, KEY_PITCH = 34.0, 36.0, 266.0, 38.5714286
KEY_X0 = 180.0 - 3 * KEY_PITCH - KEY_W / 2      # 7 keys centred like the Now Playing screen

src = open(HTML, encoding="utf-8").read()
FONT = re.search(r"body\{[^}]*font-family:([^;}]+)", src)
FONT = FONT.group(1).strip() if FONT else "sans-serif"


def svg_of(k):
    i = src.index('id="sk-%s"' % k)
    j = src.index("<svg", i)
    e = src.index("</svg>", j) + 6
    return src[j:e]


def page_html(svg, w, h):
    svg = re.sub(r"<svg ", '<svg width="%d" height="%d" ' % (w, h), svg, count=1)
    return ("<html><body style=\"margin:0;background:transparent;font-family:%s\">%s</body></html>" % (FONT, svg))


def shot(page, svg, w, h, js, path, vb=None):
    page.set_viewport_size({"width": w, "height": h})
    page.set_content(page_html(svg, w, h))
    page.wait_for_timeout(120)
    page.evaluate("([js,vb])=>{const svg=document.querySelector('svg');if(vb)svg.setAttribute('viewBox',vb);(new Function('svg',js))(svg)}", [js, vb])
    page.wait_for_timeout(60)
    page.screenshot(path=os.path.join(OUT, path), omit_background=True, clip={"x": 0, "y": 0, "width": w, "height": h})


# ---------------------------------------------------------------- JS snippets
JS_BG = """
svg.querySelectorAll('.led-r,.led-p,.led-s,.sk-time,.sk-t,.cass-img,.ck,.reel,.pack,.tape,.disk').forEach(e=>e.remove());
svg.querySelectorAll('text').forEach(t=>{const s=t.textContent.trim();if(s==='SIDE A'||s==='90 min')t.remove()});
svg.querySelectorAll('path').forEach(p=>{if(p.getAttribute('stroke')==='#fff'&&p.getAttribute('stroke-linecap')==='round'&&p.getAttribute('fill')==='none')p.remove()});
const keys=[...svg.querySelectorAll('g.key')];const rec=keys[0];
const body=rec.children[0],sheen=rec.children[1];
keys.forEach(k=>k.remove());
const X0=%(x0)f,P=%(p)f;
for(let i=0;i<7;i++){const x=X0+i*P;
 const b=body.cloneNode(true);b.setAttribute('x',x);svg.appendChild(b);
 const s=sheen.cloneNode(true);s.setAttribute('x',x+3);svg.appendChild(s);}
""" % {"x0": KEY_X0, "p": KEY_PITCH}

JS_ONLY = """
function keep(svg,sel){const ks=new Set();
 svg.querySelectorAll(sel).forEach(e=>{let n=e;while(n&&n!==svg){ks.add(n);n=n.parentNode}e.querySelectorAll('*').forEach(x=>ks.add(x));});
 [...svg.querySelectorAll('*')].forEach(e=>{if(e.tagName==='defs'||e.closest('defs')||ks.has(e))return;if(e.parentNode)e.remove();});}
keep(svg,'%s');
"""


def main():
    os.makedirs(OUT, exist_ok=True)
    info = {}
    with sync_playwright() as p:
        br = p.chromium.launch()
        page = br.new_page(viewport={"width": FW, "height": FH}, device_scale_factor=1)
        classes = set()
        for si, k in enumerate(KEYS):
            svg = svg_of(k)
            classes |= set(re.findall(r'class="([^"]+)"', svg))
            # 1) static background
            shot(page, svg, FW, FH, JS_BG, "ck_bg%d.png" % si)
            # 2) clock: dial + hands
            gm = re.search(r'<g class="ck" data-x="([\d.]+)" data-y="([\d.]+)">(<(?:circle|rect)[^>]*>)', svg)
            cx, cy = float(gm.group(1)), float(gm.group(2))
            first = gm.group(3)
            sw = float(re.search(r'stroke-width="([\d.]+)"', first).group(1))
            if first.startswith("<circle"):
                r = float(re.search(r' r="([\d.]+)"', first).group(1))
            else:
                r = float(re.search(r' width="([\d.]+)"', first).group(1)) / 2
            R = r + sw / 2 + 1.0
            S = 320 if si < 5 else 400
            vb = "%f %f %f %f" % (cx - R, cy - R, 2 * R, 2 * R)
            info[k] = dict(cx=cx, cy=cy, R=R)
            shot(page, svg, S, S, (JS_ONLY % ".ck") +
                 "svg.querySelectorAll('.hh,.mh,.sh').forEach(e=>e.remove());const g=svg.querySelector('.ck');"
                 "const cs=[...g.querySelectorAll(':scope > circle')];cs[cs.length-1].remove();cs[cs.length-2].remove();",
                 "ck_dial%d.png" % (si + 1), vb)
            hw = 7.0
            hb = "%f %f %f %f" % (cx - hw, cy - R, 2 * hw, 2 * R)
            hwpx = int(round(S * (2 * hw) / (2 * R)))
            for cls, nm in (("hh", "hh"), ("mh", "hm"), ("sh", "hs")):
                extra = ""
                if cls == "sh":   # centre cap goes on the second hand
                    extra = ""
                js = (JS_ONLY % ".ck") + (
                    "const g=svg.querySelector('.ck');const cs=[...g.querySelectorAll(':scope > circle')];"
                    "const caps=[cs[cs.length-1],cs[cs.length-2]];"
                    "[...g.children].forEach(c=>{const keep=c.classList.contains('%s')||(%s&&caps.includes(c));if(!keep)c.remove()});"
                    % (cls, "true" if cls == "sh" else "false"))
                shot(page, svg, hwpx, S, js, "ck_%s%d.png" % (nm, si + 1), hb)
            # 3) CD disc frames (each CD skin has its own disc colours)
            if si >= 5:
                R2 = 64.0
                vb2 = "%f %f %f %f" % (108 - R2, 146 - R2, 2 * R2, 2 * R2)
                for f in range(12):
                    js = (JS_ONLY % ".disk") + ("const d=svg.querySelector('.disk');d.removeAttribute('style');d.setAttribute('transform','rotate(%d 108 146)');"
                                               "d.querySelectorAll('.sk-art').forEach(e=>e.remove());" % (f * 30))
                    shot(page, svg, 256, 256, js, "ck_d%d_%02d.png" % (si, f), vb2)
            # 4) CD highlights (static arcs drawn over the disc)
            if si == 5:
                R2 = 70.0
                vb2 = "%f %f %f %f" % (108 - R2, 146 - R2, 2 * R2, 2 * R2)
                js = ("[...svg.children].forEach(c=>{if(c.tagName==='defs')return;"
                      "const keep=c.tagName==='path'&&c.getAttribute('stroke')==='#fff'&&c.getAttribute('stroke-linecap')==='round'&&c.getAttribute('fill')==='none';"
                      "if(!keep)c.remove()});")
                shot(page, svg, 280, 280, js, "ck_cd_hl.png", vb2)
            # 5) tape reel + packs (identical on all tape skins) and key glyphs
            if si == 0:
                R2 = 18.0
                for f in range(REEL_FRAMES):
                    js = (JS_ONLY % ".reel") + ("const r=svg.querySelector('.reel.a');r.removeAttribute('style');r.setAttribute('transform','rotate(%f 132 201)');" % (f * 360.0 / REEL_FRAMES))
                    shot(page, svg, 128, 128, js, "ck_reel_g%d.png" % f, "%f %f %f %f" % (132 - R2, 201 - R2, 2 * R2, 2 * R2))
                R3 = 23.0
                for lv in range(8):
                    sc = 0.7 + (1.04 - 0.7) * lv / 7.0
                    js = (JS_ONLY % ".pack") + ("const a=svg.querySelector('.pkA');svg.querySelectorAll('.pack').forEach(e=>{if(e!==a)e.remove()});"
                                               "a.removeAttribute('style');a.setAttribute('transform','translate(132 201) scale(%f) translate(-132 -201)');" % sc)
                    shot(page, svg, 160, 160, js, "ck_pack%d.png" % lv, "%f %f %f %f" % (132 - R3, 201 - R3, 2 * R3, 2 * R3))
                names = ["rec", "prev", "rew", "play", "pause", "ff", "next", "stop"]
                for ki, nm in enumerate(names):
                    js = ("[...svg.children].forEach(c=>{if(c.tagName!=='defs'&&!(c.matches&&c.matches('.k-%s')))c.remove()});"
                          "const g=svg.querySelector('.k-%s');[...g.children].slice(0,2).forEach(e=>e.remove());" % (nm, nm))
                    # key x for this key inside the SVG
                    kx = float(re.search(r'<g class="key k-%s" data-k="%s"><rect x="([\d.]+)"' % (nm, nm), svg).group(1))
                    shot(page, svg, 136, 144, js, "ck_ic_%s.png" % nm, "%f %f %f %f" % (kx, KEY_Y, KEY_W, KEY_H))
                # LEDs
                led = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12 12" width="48" height="48">'
                       '<circle cx="6" cy="6" r="3.6" fill="%s" style="filter:drop-shadow(0 0 %s %s)"/></svg>')
                for nm, col, gl in (("rec_off", "#5a1a1a", ""), ("rec_on", "#ff3030", "#ff3333"),
                                    ("play_off", "#1b3a22", ""), ("play_on", "#39ff5a", "#39ff5a")):
                    page.set_viewport_size({"width": 48, "height": 48})
                    page.set_content("<html><body style='margin:0;background:transparent'>%s</body></html>" %
                                     (led % (col, "1.2" if gl else "0", gl or "transparent")))
                    page.screenshot(path=os.path.join(OUT, "ck_led_%s.png" % nm), omit_background=True)
                # skin button
                page.set_viewport_size({"width": 96, "height": 96})
                page.set_content("<html><body style='margin:0;background:transparent'><svg viewBox='0 0 24 24' width='96' height='96'>"
                                 "<circle cx='12' cy='12' r='11' fill='rgba(10,14,28,.55)' stroke='rgba(255,255,255,.55)' stroke-width='.8'/>"
                                 "<g transform='translate(5 5) scale(.58)' fill='none' stroke='#fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'>"
                                 "<polyline points='23 4 23 10 17 10'/><polyline points='1 20 1 14 7 14'/>"
                                 "<path d='M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15'/></g></svg></body></html>")
                page.screenshot(path=os.path.join(OUT, "ck_ic_skin.png"), omit_background=True)
        br.close()
    print("classes seen in skins:", sorted(classes))
    write_layout()


# ---------------------------------------------------------------- layout
def fmt(v):
    s = ("%.3f" % v).rstrip("0").rstrip(".")
    return s or "0"


def sp(w=None, h=None, weight=0, ver=False):
    return '<FrameLayout android:layout_width="%s" android:layout_height="%s" android:layout_weight="%s"/>' % (
        "match_parent" if ver else "0dp", "0dp" if ver else "match_parent", fmt(weight))


def at(x, y, w, h, inner):
    """place `inner` (a view with match_parent size) in the box x,y,w,h of the 360 x 322 design grid"""
    col = '<LinearLayout android:layout_width="0dp" android:layout_height="match_parent" android:layout_weight="%s" android:orientation="vertical">' % fmt(w)
    if y > 0.001:
        col += sp(weight=y, ver=True)
    col += '<FrameLayout android:layout_width="match_parent" android:layout_height="0dp" android:layout_weight="%s">%s</FrameLayout>' % (fmt(h), inner)
    if VH - y - h > 0.001:
        col += sp(weight=VH - y - h, ver=True)
    col += "</LinearLayout>"
    row = '<LinearLayout android:layout_width="match_parent" android:layout_height="match_parent" android:orientation="horizontal">'
    if x > 0.001:
        row += sp(weight=x)
    row += col
    if VW - x - w > 0.001:
        row += sp(weight=VW - x - w)
    return row + "</LinearLayout>"


def img(idn, drawable, extra=""):
    i = ' android:id="@+id/%s"' % idn if idn else ""
    sc = "" if "scaleType" in extra else ' android:scaleType="fitXY"'
    return '<ImageView%s android:layout_width="match_parent" android:layout_height="match_parent" android:src="@drawable/%s"%s%s/>' % (i, drawable, sc, extra)


def flipper(idn, frames, interval, vis=""):
    f = "".join(img(None, d) for d in frames)
    return '<ViewFlipper android:id="@+id/%s" android:layout_width="match_parent" android:layout_height="match_parent" android:flipInterval="%d" android:autoStart="true"%s>%s</ViewFlipper>' % (
        idn, interval, vis, f)


def tv(idn, text, size, color, grav, bold=True, extra=""):
    return ('<TextView android:id="@+id/%s" android:layout_width="match_parent" android:layout_height="match_parent" android:text="%s" '
            'android:textColor="%s" android:textSize="%dsp" android:textStyle="%s" android:singleLine="true" android:ellipsize="end" '
            'android:includeFontPadding="false" android:gravity="%s"%s/>') % (idn, text, color, size, "bold" if bold else "normal", grav, extra)


def chrono(idn, size, color, grav):
    return ('<Chronometer android:id="@+id/%s" android:layout_width="match_parent" android:layout_height="match_parent" '
            'android:gravity="%s" android:textColor="%s" android:textSize="%dsp" android:textStyle="bold" android:fontFamily="monospace" '
            'android:singleLine="true" android:includeFontPadding="false"/>') % (idn, grav, color, size)


def clock(idn, n, vis):
    return ('<AnalogClock android:id="@+id/%s" android:layout_width="match_parent" android:layout_height="match_parent"%s '
            'android:dial="@drawable/ck_dial%d" android:hand_hour="@drawable/ck_hh%d" android:hand_minute="@drawable/ck_hm%d" android:hand_second="@drawable/ck_hs%d"/>') % (
        idn, vis, n, n, n, n)


def write_layout():
    # old widget XML kept the tuned flip speeds of the reels; read them from the previous file when it exists
    intervals = {"s": 70, "m": 56, "f": 45, "ff": 20, "rw": 20}   # same turning speed as before, for 24 deg frames
    g = ["ck_reel_g%d" % i for i in range(REEL_FRAMES)]
    parts = []
    parts.append('<?xml version="1.0" encoding="utf-8"?>\n<!-- GENERATED by tools/gen_widget_from_svg.py : same structure as the Now Playing skins (360 x 322 design units) -->\n'
                 '<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android" android:id="@+id/w_root" android:layout_width="match_parent" android:layout_height="match_parent">')
    parts.append('<ImageView android:id="@+id/ck_bg" android:layout_width="match_parent" android:layout_height="match_parent" android:src="@drawable/ck_bg0" android:scaleType="fitXY"/>')

    # ---- cassette group
    t = []
    t.append(at(70, 76, 12, 12, img("ck_led_play", "ck_led_play_off", ' android:scaleType="fitCenter"')))
    t.append(at(28, 76, 12, 12, img("ck_led_rec", "ck_led_rec_off", ' android:scaleType="fitCenter"')))
    t.append(at(108, 71, 96, 23, chrono("ck_time", 15, "#5dff7a", "center")))
    # label header: SIDE A / LIVE (left) + duration / FM (right)
    t.append(at(70, 116, 220, 13,
                '<LinearLayout android:layout_width="match_parent" android:layout_height="match_parent" android:orientation="horizontal">'
                '<TextView android:id="@+id/ck_side" android:layout_width="0dp" android:layout_height="match_parent" android:layout_weight="1" android:text="SIDE A" android:textColor="#ffffff" android:textSize="8sp" android:textStyle="bold" android:singleLine="true" android:includeFontPadding="false" android:gravity="center_vertical"/>'
                '<TextView android:id="@+id/ck_dur" android:layout_width="0dp" android:layout_height="match_parent" android:layout_weight="1" android:text="" android:textColor="#ffffff" android:textSize="8sp" android:textStyle="bold" android:singleLine="true" android:includeFontPadding="false" android:gravity="center_vertical|end"/>'
                '</LinearLayout>'))
    t.append(at(62, 133, 236, 26, tv("ck_track", "", 16, "#2b2b2b", "center", True, ' android:paddingStart="6dp" android:paddingEnd="6dp"')))
    # reels + tape packs (left = supply, right = take-up)
    for side, cxu in (("l", 132.0), ("r", 228.0)):
        t.append(at(cxu - 23, 201 - 23, 46, 46, img("ck_pack_" + side, "ck_pack7" if side == "l" else "ck_pack0")))
        reel = img("ck_reel_%s_off" % side, "ck_reel_g0")
        for kk in ("s", "m", "f", "ff"):
            reel += flipper("ck_reel_%s_%s" % (side, kk), g, intervals[kk], ' android:visibility="gone"')
        reel += flipper("ck_reel_%s_rw" % side, list(reversed(g)), intervals["rw"], ' android:visibility="gone"')
        t.append(at(cxu - 18, 201 - 18, 36, 36, reel))
    # clocks (one per skin, switched by the updater)
    cl = ""
    for i in range(5):
        cl += clock("ck_clk%d" % (i + 1), i + 1, "" if i == 0 else ' android:visibility="gone"')
    t.append(at(272 - 41.5, 56 - 41.5, 83, 83, cl))
    parts.append('<FrameLayout android:id="@+id/ck_tape_g" android:layout_width="match_parent" android:layout_height="match_parent">' + "".join(t) + "</FrameLayout>")

    # ---- CD group
    c = []
    c.append(at(64, 23, 12, 12, img("ck2_led_play", "ck_led_play_off", ' android:scaleType="fitCenter"')))
    c.append(at(24, 23, 12, 12, img("ck2_led_rec", "ck_led_rec_off", ' android:scaleType="fitCenter"')))
    for s in range(5, 10):
        frames = ["ck_d%d_%02d" % (s, f) for f in range(12)]
        c.append(at(44, 82, 128, 128,
                    img("ck_cd_off%d" % s, "ck_d%d_00" % s, ' android:visibility="gone"') +
                    flipper("ck_cd_on%d" % s, frames, 90, ' android:visibility="gone"')))
    c.append(at(38, 76, 140, 140, img(None, "ck_cd_hl")))
    cl = ""
    for i in range(5):
        cl += clock("ck2_clk%d" % (i + 6), i + 6, ' android:visibility="gone"')
    c.append(at(262 - 54, 146 - 54, 108, 108, cl))
    c.append(at(30, 214, 214, 28, tv("ck2_track", "", 12, "#8fe3ff", "center_vertical")))
    c.append(at(250, 214, 80, 28, chrono("ck2_time", 12, "#8fe3ff", "center_vertical|end")))
    parts.append('<FrameLayout android:id="@+id/ck_cd_g" android:layout_width="match_parent" android:layout_height="match_parent" android:visibility="gone">' + "".join(c) + "</FrameLayout>")

    # ---- keys (7, centred like Now Playing; the middle one toggles play / pause)
    ids = ["ck_k_rec", "ck_k_prev", "ck_k_rew", "ck_k_play", "ck_k_ff", "ck_k_next", "ck_k_stop"]
    icons = ["ck_ic_rec", "ck_ic_prev", "ck_ic_rew", "ck_ic_play", "ck_ic_ff", "ck_ic_next", "ck_ic_stop"]
    for i in range(7):
        parts.append(at(KEY_X0 + i * KEY_PITCH, KEY_Y, KEY_W, KEY_H,
                        '<ImageButton android:id="@+id/%s" android:layout_width="match_parent" android:layout_height="match_parent" '
                        'android:background="@android:color/transparent" android:src="@drawable/%s" android:scaleType="fitXY" android:padding="0dp" android:contentDescription="%s"/>' % (ids[i], icons[i], ids[i][5:])))
    # ---- skin button + counter (top right corner)
    parts.append(at(316, 7, 30, 30, '<ImageButton android:id="@+id/ck_skin" android:layout_width="match_parent" android:layout_height="match_parent" '
                                      'android:background="@android:color/transparent" android:src="@drawable/ck_ic_skin" android:scaleType="fitCenter" android:padding="0dp" android:contentDescription="Change skin"/>'))
    parts.append(at(308, 37, 46, 10, tv("ck_skin_n", "1/10", 7, "#dfe6f7", "center_horizontal")))
    parts.append("</FrameLayout>\n")
    open(LAYOUT_OUT, "w", encoding="utf-8").write("\n".join(parts))
    print("layout written", LAYOUT_OUT)


if __name__ == "__main__":
    main()
