# Cassette reels, tape packs and flange for the Home Screen widget.
# Shapes and sizes follow the reel of the "Now Playing" screen (index.html #cass SVG, 1 unit = 160/46.9 px):
#   flange r=17, 6 dark spokes, hub r=10.5, 6 white teeth, centre r=3.6, red marker.
# Layers (bottom to top):   flange (static)  ->  tape pack (static, tape colour, 8 sizes)  ->  turning reel (16 frames).
# The tape pack sits ON the flange, so the amount of tape on each reel is clearly visible.
# 6 white teeth on a dark hub (like a real cassette reel), no spokes / marker -> the picture repeats every 60 degrees.
# Frames: 8 x 7.5 degrees = one period, clockwise.
import math, os
import numpy as np
from PIL import Image, ImageDraw

OUT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "res", "drawable-nodpi")
W = 160                      # canvas px
K = 58 / 17.0                # px per unit
S = 4                        # supersampling
PERIOD = 60.0   # 6 identical teeth -> the picture repeats every 60 degrees
FRAMES = 8      # 8 frames x 7.5 deg = one period (looping them looks like a smooth continuous turn)
PACK_LEVELS = 8              # scale 0.70 .. 1.04 of r=22, like Now Playing
TAPE_LIGHT = (214, 156, 78); TAPE_DARK = (104, 64, 30)       # tape colour: warm amber-brown (shows well on the dark window)

def hexc(h): return tuple(int(h[i:i+2], 16) for i in (1, 3, 5))

def disc(r, cx, cy, gr, c0, c1):
    n = W*S
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float64)
    ux = (xx + .5 - n/2) / (K*S); uy = (yy + .5 - n/2) / (K*S)
    size = 2*r
    t = np.clip(np.hypot(ux-(-r+cx*size), uy-(-r+cy*size)) / (gr*size), 0, 1)[..., None]
    col = np.array(c0)*(1-t) + np.array(c1)*t
    a = (np.hypot(ux, uy) <= r).astype(np.float64)[..., None] * 255
    return Image.fromarray(np.concatenate([col, a], axis=2).astype(np.uint8), "RGBA")

def canvas(): return Image.new("RGBA", (W*S, W*S), (0, 0, 0, 0))
def save(im, name): im.resize((W, W), Image.LANCZOS).save(os.path.join(OUT, name + ".png"))
C = W*S/2; U = K*S

def flange():
    im = disc(17, .4, .35, .8, hexc("#ffffff"), hexc("#b9bcc6")); d = ImageDraw.Draw(im)
    d.ellipse([C-17*U, C-17*U, C+17*U, C+17*U], outline=hexc("#8d929c")+(255,), width=int(1*U))
    return im

def pack(s):
    r = 22*s
    im = disc(r, .4, .35, .9, TAPE_LIGHT, TAPE_DARK); d = ImageDraw.Draw(im)
    k = 11.5
    while k < r - .6:                                              # thin tape layers (winding)
        d.ellipse([C-k*U, C-k*U, C+k*U, C+k*U], outline=(60, 34, 14, 70), width=max(1, int(.28*U)))
        k += 1.05
    d.ellipse([C-r*U, C-r*U, C+r*U, C+r*U], outline=(52, 30, 12, 255), width=int(.9*U))            # dark edge
    d.ellipse([C-(r-1.0)*U, C-(r-1.0)*U, C+(r-1.0)*U, C+(r-1.0)*U], outline=(246, 206, 130, 200), width=max(1, int(.5*U)))  # light rim: shows the tape edge
    d.ellipse([C-11.6*U, C-11.6*U, C+11.6*U, C+11.6*U], outline=(30, 16, 6, 190), width=int(1.4*U))  # shadow where the tape starts at the hub
    hl = canvas(); h = ImageDraw.Draw(hl)                          # glossy highlight (fixed)
    h.pieslice([C-(r-1.6)*U, C-(r-1.6)*U, C+(r-1.6)*U, C+(r-1.6)*U], 205, 285, fill=(255, 255, 255, 42))
    return Image.alpha_composite(im, hl)

def reel():
    im = canvas(); d = ImageDraw.Draw(im)
    def circ(r, **kw): d.ellipse([C-r*U, C-r*U, C+r*U, C+r*U], **kw)
    def rrect(x, y, w, h, rx, ang, fill):
        layer = canvas(); ImageDraw.Draw(layer).rounded_rectangle([C+x*U, C+y*U, C+(x+w)*U, C+(y+h)*U], radius=rx*U, fill=fill)
        return layer.rotate(-ang, resample=Image.BICUBIC, center=(C, C))
    circ(10.5, fill=hexc("#15171d")+(255,), outline=hexc("#555555")+(255,), width=int(.8*U))     # dark hub
    for k in range(6):                                   # 6 white teeth
        im.alpha_composite(rrect(-2.1, -12.6, 4.2, 7.6, 1.3, 60*k, (255, 255, 255, 255)))
    circ(3.6, fill=(0, 0, 0, 255))
    return im

save(flange(), "ck_flange")
for i in range(PACK_LEVELS):
    save(pack(0.70 + (1.04-0.70) * i / (PACK_LEVELS-1)), "ck_pack%d" % i)
base = reel()
for i in range(FRAMES):
    save(base.rotate(-i*PERIOD/FRAMES, resample=Image.BICUBIC, center=(C, C)), "ck_reel_g%d" % i)
print("reels done")
