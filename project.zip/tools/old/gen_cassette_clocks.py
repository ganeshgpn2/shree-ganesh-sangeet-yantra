# 10 analog clock faces for the 10 skins of the cassette/CD widget (AnalogClock: dial + hour/minute/second hands).
# Skin 1 uses Devanagari numerals (१ ... १२).  Skins 1-5 are for the small header clock (320 px), 6-10 for the big CD clock (400 px).
import math, os, random
import numpy as np
from PIL import Image, ImageDraw, ImageFont

OUT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "res", "drawable-nodpi")
D = 400; SS = 3
FS = "/usr/share/fonts/truetype/freefont/FreeSerifBold.ttf"      # has Devanagari
FSANS = "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf"
POP = "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf"
DEV = ["१","२","३","४","५","६","७","८","९","१०","११","१२"]
ROM = ["I","II","III","IV","V","VI","VII","VIII","IX","X","XI","XII"]
def hx(h, a=255): h = h.lstrip('#'); return (int(h[0:2],16), int(h[2:4],16), int(h[4:6],16), a)
def lerp(a, b, t): return tuple(int(a[i]+(b[i]-a[i])*t) for i in range(len(a)))

def radial(size, c0, c1, cx=.5, cy=.5, r=.5, mask_r=None):
    yy, xx = np.mgrid[0:size, 0:size].astype(np.float64)
    t = np.clip(np.hypot(xx-cx*size, yy-cy*size) / (r*size), 0, 1)[..., None]
    col = np.array(c0[:3])*(1-t) + np.array(c1[:3])*t
    a = np.full((size, size, 1), 255.0)
    if mask_r: a = (np.hypot(xx-size/2, yy-size/2) <= mask_r*size).astype(np.float64)[..., None]*255
    return Image.fromarray(np.concatenate([col, a], axis=2).astype(np.uint8), "RGBA")

def sunburst(size, base, light, rays=48):
    yy, xx = np.mgrid[0:size, 0:size].astype(np.float64)
    ang = np.arctan2(yy-size/2, xx-size/2)
    t = (np.sin(ang*rays/2)*.5+.5)[..., None]*0.55 + np.clip(np.hypot(xx-size/2, yy-size/2)/(size/2), 0, 1)[..., None]*0.0
    col = np.array(base[:3])*(1-t) + np.array(light[:3])*t
    return Image.fromarray(np.concatenate([col, np.full((size, size, 1), 255.0)], axis=2).astype(np.uint8), "RGBA")

# ------------------------------------------------------------------ styles
STY = [
 dict(name="dev",  face=("#16328f","#07123d"), ring=("#ffe08a","#b8860b"), num="dev",  numc="#ffe9a8", tick="#ffd25a", hand="sword",  hc="#ffd25a", sc="#ff3b3b", sec="line",  pat=None),
 dict(name="rom",  face=("#f6ead0","#d9c59a"), ring=("#7a1f2f","#3b0a14"), num="rom",  numc="#5a1020", tick="#5a1020", hand="leaf",   hc="#4a0e1b", sc="#c1272d", sec="line",  pat=None),
 dict(name="ar4",  face=("#1f8f6b","#0a3a2c"), ring=("#f4d27a","#a9791a"), num="ar4",  numc="#fff1c4", tick="#f4d27a", hand="spade",  hc="#fff1c4", sc="#ffb300", sec="arrow", pat=None),
 dict(name="bat",  face=("#e9a24d","#7a4210"), ring=("#fff0c0","#a8782a"), num=None,   numc="#2a1604", tick="#2a1604", hand="baton",  hc="#2a1604", sc="#d81b1b", sec="line",  pat=None),
 dict(name="spt",  face=("#8a93a6","#242a38"), ring=("#f2f4f8","#7d8596"), num="ar",   numc="#ffffff", tick="#ffffff", hand="sword",  hc="#ffffff", sc="#ff5a1f", sec="arrow", pat=None),
 dict(name="neon", face=("#0b1d2e","#020609"), ring=("#7fe8ff","#1b7da1"), num="dots", numc="#8cf0ff", tick="#8cf0ff", hand="baton",  hc="#bff6ff", sc="#ff2e88", sec="line",  pat="rings"),
 dict(name="gil",  face=("#2a3d78","#0b1330"), ring=("#e9edf7","#7c869c"), num="rom",  numc="#e9edf7", tick="#e9edf7", hand="leaf",   hc="#e9edf7", sc="#ffcf4a", sec="line",  pat="rings"),
 dict(name="rose", face=("#f2c2c0","#b5636a"), ring=("#fff4ea","#c58a7a"), num="ar",   numc="#4d1626", tick="#4d1626", hand="spade",  hc="#4d1626", sc="#fff4ea", sec="arrow", pat="sun"),
 dict(name="teal", face=("#2fb7b0","#0a3f46"), ring=("#d8fffb","#2b8a89"), num="dia",  numc="#e6fffd", tick="#e6fffd", hand="sword",  hc="#e6fffd", sc="#ffd23f", sec="line",  pat="rings"),
 dict(name="gold", face=("#f3dc8c","#b98d2e"), ring=("#fff3c4","#8d6a12"), num="rom4", numc="#2b1f05", tick="#2b1f05", hand="leaf",   hc="#2b1f05", sc="#a4121a", sec="arrow", pat="sun"),
]

def numerals(d, st, S):
    c = D*S/2; f_col = hx(st['numc']); kind = st['num']; R = 150*S
    def font(path, size): return ImageFont.truetype(path, int(size*S))
    if kind in ("dev", "rom", "ar", "ar4", "rom4"):
        for i in range(12):
            if kind in ("ar4", "rom4") and i % 3: continue
            n = 12 if i == 0 else i
            lab = DEV[n-1] if kind == "dev" else (ROM[n-1] if kind in ("rom", "rom4") else str(n))
            if kind == "dev": size, r = (34 if n < 10 else 27), 134*S
            elif kind in ("rom", "rom4"): size, r = (30 if len(lab) <= 2 else 24) if kind == "rom" else 40, (138*S if kind == "rom" else 134*S)
            elif kind == "ar4": size, r = 44, 136*S
            else: size, r = 30, 138*S
            fp = FS if kind in ("dev", "rom", "rom4") else POP
            a = math.radians(i*30)
            d.text((c+r*math.sin(a), c-r*math.cos(a)), lab, font=font(fp, size), fill=f_col, anchor="mm")
    elif kind == "dots":
        for i in range(12):
            a = math.radians(i*30); r = 150*S; rad = (9 if i % 3 == 0 else 5)*S
            d.ellipse([c+r*math.sin(a)-rad, c-r*math.cos(a)-rad, c+r*math.sin(a)+rad, c-r*math.cos(a)+rad], fill=f_col)
    elif kind == "dia":
        for i in range(12):
            a = math.radians(i*30); r = 150*S; rad = (13 if i % 3 == 0 else 8)*S
            x, y = c+r*math.sin(a), c-r*math.cos(a)
            d.polygon([(x, y-rad), (x+rad*.7, y), (x, y+rad), (x-rad*.7, y)], fill=f_col)

def ticks(d, st, S):
    c = D*S/2; col = hx(st['tick'])
    for i in range(60):
        a = math.radians(i*6); five = i % 5 == 0
        if st['num'] in ("dots", "dia") and five: continue
        if st['name'] == "bat" and five:                                  # baton markers
            r1, r2, w = 176*S, 140*S, 9*S
        elif five: r1, r2, w = 182*S, 168*S, 4*S
        else: r1, r2, w = 182*S, 175*S, 2*S
        if st['num'] in ("dev", "rom", "ar", "ar4", "rom4") and five: continue
        d.line([c+r1*math.sin(a), c-r1*math.cos(a), c+r2*math.sin(a), c-r2*math.cos(a)], fill=col, width=int(w))

def make_dial(st, size):
    S = SS; N = D*S
    ring_o, ring_i = hx(st['ring'][0]), hx(st['ring'][1])
    im = radial(N, hx(st['ring'][0]), hx(st['ring'][1]), .38, .32, .62, mask_r=.5)            # bezel (metallic)
    face = radial(N, hx(st['face'][0]), hx(st['face'][1]), .42, .36, .62, mask_r=.5*(168/200))   # face
    fm = Image.new("L", (N, N), 0); ImageDraw.Draw(fm).ellipse([N/2-168*S, N/2-168*S, N/2+168*S, N/2+168*S], fill=255)
    layer = Image.new("RGBA", (N, N), (0, 0, 0, 0)); layer.paste(face if False else radial(N, hx(st['face'][0]), hx(st['face'][1]), .42, .36, .62), (0, 0), fm)
    if st['pat'] == "sun": layer.paste(sunburst(N, hx(st['face'][1]), hx(st['face'][0])), (0, 0), fm)
    im.alpha_composite(layer); d = ImageDraw.Draw(im); c = N/2
    if st['pat'] == "rings":
        for r in range(40, 168, 12): d.ellipse([c-r*S, c-r*S, c+r*S, c+r*S], outline=hx("#ffffff", 16), width=S)
    d.ellipse([c-168*S, c-168*S, c+168*S, c+168*S], outline=(0, 0, 0, 120), width=3*S)                 # inner rim shadow
    d.ellipse([c-196*S, c-196*S, c+196*S, c+196*S], outline=hx("#ffffff", 150), width=2*S)            # bezel highlight
    d.ellipse([c-198*S, c-198*S, c+198*S, c+198*S], outline=(0, 0, 0, 140), width=2*S)
    ticks(d, st, S); numerals(d, st, S)
    if st['num'] is None:                                                                             # small brand
        d.text((c, c-70*S), "गणेश", font=ImageFont.truetype(FS, 22*S), fill=hx(st['numc'], 200), anchor="mm")
    g = Image.new("RGBA", (N, N), (0, 0, 0, 0)); gd = ImageDraw.Draw(g)                              # glass reflection
    gd.pieslice([c-176*S, c-176*S, c+176*S, c+176*S], 205, 275, fill=(255, 255, 255, 38))
    im.alpha_composite(g)
    return im.resize((size, size), Image.LANCZOS)

def make_hand(kind, length, color, width, size, S=4, tail=26, seconds=False, sec_style="line"):
    """Hand pointing up from the canvas centre.  Canvas is as tall as the dial so the pivot is the centre; narrow to save memory."""
    sc = size/D; L = length*sc; Wd = int((width*2+40)*sc)
    H = size
    im = Image.new("RGBA", (Wd*S, H*S), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    cx, cy = Wd*S/2, H*S/2; col = hx(color); w = width*sc*S; Ls = L*S; ts = tail*sc*S
    if kind == "sword":
        d.polygon([(cx-w*.55, cy), (cx, cy-Ls), (cx+w*.55, cy), (cx, cy+ts)], fill=col)
        d.line([cx, cy-Ls*.9, cx, cy-w*.4], fill=(255, 255, 255, 90), width=max(1, int(w*.12)))
    elif kind == "leaf":
        pts = []
        for t in np.linspace(0, 1, 40): pts.append((cx+math.sin(t*math.pi)*w*.75, cy-t*Ls*.82))
        pts2 = [(2*cx-x, y) for x, y in reversed(pts)]
        d.polygon(pts+[(cx, cy-Ls)]+pts2+[(cx-w*.25, cy+ts), (cx+w*.25, cy+ts)], fill=col)
        d.line([cx, cy-Ls*.2, cx, cy-Ls*.82], fill=(0, 0, 0, 70), width=max(1, int(w*.1)))
    elif kind == "spade":
        d.rounded_rectangle([cx-w*.2, cy-Ls, cx+w*.2, cy+ts], radius=w*.2, fill=col)
        r = w*.62; yy = cy-Ls*.66
        d.polygon([(cx, yy-r*1.3), (cx+r, yy), (cx, yy+r*1.3), (cx-r, yy)], fill=col)
        d.polygon([(cx, yy-r*.8), (cx+r*.55, yy), (cx, yy+r*.8), (cx-r*.55, yy)], fill=(0, 0, 0, 70))
    elif kind == "baton":
        d.rounded_rectangle([cx-w*.45, cy-Ls, cx+w*.45, cy+ts], radius=w*.3, fill=col)
        d.rounded_rectangle([cx-w*.2, cy-Ls*.9, cx+w*.2, cy-Ls*.3], radius=w*.2, fill=(255, 255, 230, 235))   # lume
    if seconds:
        im = Image.new("RGBA", (Wd*S, H*S), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
        t2 = 46*sc*S
        d.line([cx, cy+t2, cx, cy-Ls], fill=col, width=max(2, int(2.4*sc*S)))
        d.ellipse([cx-5*sc*S, cy+t2-6*sc*S, cx+5*sc*S, cy+t2+6*sc*S], fill=col)
        if sec_style == "arrow": d.polygon([(cx, cy-Ls-4*S), (cx+6*sc*S, cy-Ls+18*sc*S), (cx-6*sc*S, cy-Ls+18*sc*S)], fill=col)
        else: d.ellipse([cx-7*sc*S, cy-Ls*.72-7*sc*S, cx+7*sc*S, cy-Ls*.72+7*sc*S], fill=col)
    if seconds:
        r = 9*sc*S; d.ellipse([cx-r, cy-r, cx+r, cy+r], fill=col); d.ellipse([cx-r*.4, cy-r*.4, cx+r*.4, cy+r*.4], fill=(0, 0, 0, 170))
    # soft shadow
    sh = Image.new("RGBA", im.size, (0, 0, 0, 0)); sh.paste((0, 0, 0, 80), (int(1.5*S), int(2.5*S)), im.split()[3])
    from PIL import ImageFilter
    out = Image.alpha_composite(sh.filter(ImageFilter.GaussianBlur(1.6*S)), im)
    return out.resize((Wd, H), Image.LANCZOS)

def hub(size, color):                       # centre cap drawn on top of the minute hand image
    S = 4; im = Image.new("RGBA", (size*S, size*S), (0, 0, 0, 0)); d = ImageDraw.Draw(im); c = size*S/2; r = 11*size/D*S
    d.ellipse([c-r, c-r, c+r, c+r], fill=hx(color)); d.ellipse([c-r*.45, c-r*.45, c+r*.45, c+r*.45], fill=(0, 0, 0, 160))
    return im.resize((size, size), Image.LANCZOS)

def save(im, name): im.save(os.path.join(OUT, name + ".png"), optimize=True)

for old in ("ck_dial", "ck_hand_hour", "ck_hand_min", "ck2_dial", "ck2_hand_hour", "ck2_hand_min"):
    p = os.path.join(OUT, old + ".png")
    if os.path.exists(p): os.remove(p)

for i, st in enumerate(STY):
    size = 320 if i < 5 else 400                     # i<5: header clock of tape skins; i>=5: big clock of CD skins
    k = i+1
    save(make_dial(st, size), "ck_dial%d" % k)
    save(make_hand(st['hand'], 104, st['hc'], 24, size), "ck_hh%d" % k)
    mh = make_hand(st['hand'], 152, st['hc'], 17, size)
    save(mh, "ck_hm%d" % k)
    save(make_hand("line", 168, st['sc'], 6, size, seconds=True, sec_style=st['sec']), "ck_hs%d" % k)
print("clocks done")
