# Draws the still artwork of the "Tape Blue" cassette Home Screen widget (360 x 322 design units).
# Moving parts (text, reels, LEDs, clock, equalizer, keys) are real views laid over this picture.
import math, random, os, glob
from PIL import Image, ImageDraw, ImageFilter, ImageFont
OUT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "res", "drawable-nodpi")
K = 6; W, H = 360, 322
GOLD=(226,176,58,255); GOLD_L=(255,222,120,255)
def new(): return Image.new("RGBA",(W*K,H*K),(0,0,0,0))
def comp(a,b): a.alpha_composite(b)
def vgrad(w,h,c1,c2):
    g=Image.new("RGBA",(w,h)); d=ImageDraw.Draw(g)
    for y in range(h):
        t=y/max(1,h-1); d.line([(0,y),(w,y)],fill=tuple(int(c1[i]+(c2[i]-c1[i])*t) for i in range(4)))
    return g
def rr(img,box,r,c1,c2=None,stroke=None,sw=1.0,glow=0,tl=True):
    x0,y0,x1,y1=[int(v*K) for v in box]
    if c1 is not None:
        g=vgrad(x1-x0,y1-y0,c1,c2 or c1); m=Image.new("L",g.size,0)
        ImageDraw.Draw(m).rounded_rectangle([0,0,g.width-1,g.height-1],radius=r*K,fill=255)
        l=new(); l.paste(g,(x0,y0),m); comp(img,l)
    if stroke:
        if glow:
            gl=new(); ImageDraw.Draw(gl).rounded_rectangle([x0,y0,x1,y1],radius=r*K,outline=stroke[:3]+(150,),width=int(sw*K*2))
            comp(img,gl.filter(ImageFilter.GaussianBlur(glow*K)))
        l=new(); ImageDraw.Draw(l).rounded_rectangle([x0,y0,x1,y1],radius=r*K,outline=stroke,width=max(1,int(sw*K))); comp(img,l)
def blob(img,box,col,blur):
    l=new(); ImageDraw.Draw(l).ellipse([v*K for v in box],fill=col); comp(img,l.filter(ImageFilter.GaussianBlur(blur*K)))
def poly(img,pts,fill,outline=None):
    l=new(); d=ImageDraw.Draw(l); d.polygon([(x*K,y*K) for x,y in pts],fill=fill,outline=outline); comp(img,l)
def circ(img,c,r,fill=None,outline=None,sw=1,glow=0):
    x,y=c
    if glow:
        gl=new(); ImageDraw.Draw(gl).ellipse([(x-r)*K,(y-r)*K,(x+r)*K,(y+r)*K],outline=(outline or fill)[:3]+(170,),width=int(sw*K*2))
        comp(img,gl.filter(ImageFilter.GaussianBlur(glow*K)))
    l=new(); ImageDraw.Draw(l).ellipse([(x-r)*K,(y-r)*K,(x+r)*K,(y+r)*K],fill=fill,outline=outline,width=max(1,int(sw*K))); comp(img,l)
def text(img,xy,t,size,fill,fontp="/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",anchor="mm"):
    l=new(); f=ImageFont.truetype(fontp,int(size*K)); ImageDraw.Draw(l).text((xy[0]*K,xy[1]*K),t,font=f,fill=fill,anchor=anchor); comp(img,l)

im=new()
# ---- body: royal blue, glow, gold frame, glass sheen ----
rr(im,(3,3,357,319),24,(46,96,214,255),(8,22,78,255),GOLD,2.4,glow=2.5)
blob(im,(-40,-30,170,120),(90,150,255,110),30); blob(im,(200,200,420,360),(60,120,240,90),30)
rr(im,(8,8,352,314),20,None,None,(255,226,140,255),0.9) if False else None
rr(im,(8,8,352,314),20,None,None,stroke=(255,226,140,170),sw=0.8)
rr(im,(8,8,352,100),20,(255,255,255,62),(255,255,255,0))
# ---- header plate + logo ----
rr(im,(22,20,206,66),9,(6,12,46,255),(10,22,70,255),GOLD,1.6,glow=1.5)
circ(im,(41,43),13.5,fill=(14,30,90,255),outline=GOLD,sw=1.6)
ImageDraw.Draw(im).arc([27*K,28*K,55*K,56*K],180,360,fill=GOLD,width=int(2.6*K))
rr(im,(25,40,31,52),2.5,GOLD,(180,130,30,255)); rr(im,(51,40,57,52),2.5,GOLD,(180,130,30,255))
dev=[p for p in glob.glob("/usr/share/fonts/**/*[Dd]evanagari*",recursive=True) if "Bold" in p or "bold" in p] or glob.glob("/usr/share/fonts/**/*[Dd]evanagari*",recursive=True)
if dev: text(im,(41,44),"ॐ",15,GOLD_L,dev[0])
else: text(im,(41,43),"♪",16,GOLD_L)
sw=ImageDraw.Draw(im)
pts=[(66+t*130, 63.2 - 2.2*math.sin(math.pi*t)) for t in [i/40 for i in range(41)]]
sw.line([(x*K,y*K) for x,y in pts],fill=GOLD,width=int(1.2*K))
# ---- REC / PLAY panel ----
rr(im,(22,71,106,94),8,(10,24,84,170),(6,14,52,170),(90,120,200,150),0.8)
# ---- notes ----
text(im,(220,48),"♫",24,GOLD_L); text(im,(220,76),"♪",16,GOLD)
text(im,(338,66),"♪",20,GOLD_L)
blob(im,(228,14,316,102),(255,200,60,90),9)
# ---- cassette glass panel ----
rr(im,(44,108,316,246),12,(74,126,232,215),(12,34,108,240),GOLD,1.5,glow=2)
rr(im,(48,112,312,242),10,None,None,stroke=(170,200,255,120),sw=0.7)
poly(im,[(52,112),(150,112),(96,242),(52,242)],(255,255,255,26))
for sx,sy in ((54,118),(306,118),(54,236),(306,236)):
    circ(im,(sx,sy),3.6,fill=(214,170,70,255),outline=(120,86,20,255),sw=0.6)
    ImageDraw.Draw(im).line([((sx-2)*K,(sy+1.2)*K),((sx+2)*K,(sy-1.2)*K)],fill=(90,60,10,255),width=int(0.8*K))
# ---- label ----
rr(im,(62,116,298,172),5,(252,242,214,255),(244,230,190,255))
rr(im,(62,116,298,129),5,(224,22,44,255),(178,10,30,255)); rr(im,(62,124,298,129),0,(200,16,36,255),(178,10,30,255))
d=ImageDraw.Draw(im)
for y in (160,166): d.line([(70*K,y*K),(290*K,y*K)],fill=(214,176,86,255),width=int(0.8*K))
# ---- tape window ----
rr(im,(104,178,256,224),23,(4,7,20,255),(6,12,34,255),(150,168,210,255),2,glow=1)
rr(im,(112,181,248,197),8,(255,255,255,26),(255,255,255,0))
d=ImageDraw.Draw(im)
for y in (196,202,208):
    d.line([(66*K,y*K),(98*K,y*K)],fill=GOLD,width=int(1.6*K)); d.line([(262*K,y*K),(294*K,y*K)],fill=GOLD,width=int(1.6*K))
# ---- bottom trapezoid ----
poly(im,[(126,246),(146,228),(214,228),(234,246)],(8,10,18,255),(40,40,48,255))
rr(im,(171,229,189,238),2,(240,240,246,255),(168,172,186,255))
for cx in (154,206):
    circ(im,(cx,236),5,fill=(214,40,24,255),outline=(30,10,10,255),sw=0.8,glow=1.5); circ(im,(cx-1.4,234.4),1.5,fill=(255,170,150,200))
# ---- key bar ----
rr(im,(22,258,338,308),14,(8,20,66,240),(5,11,40,248),GOLD,1.4,glow=1.5)
for cx,r in ((54,17.5),(94,17.5),(134,17.5),(180,24),(226,17.5),(266,17.5),(306,17.5)):
    circ(im,(cx,283),r,fill=(14,32,98,255),outline=GOLD,sw=2.0 if r>20 else 1.5,glow=1.6)
    circ(im,(cx,283),r-3,outline=(255,255,255,40),sw=0.6)
im.resize((W*3,H*3),Image.LANCZOS).save(os.path.join(OUT,"ck_bg.png"))

# ---- side equalizer (44 x 138 units) : 6 moving frames + an idle frame ----
EW,EH=44,138; Z=3
def eq(name,heights,dim=False):
    e=Image.new("RGBA",(EW*Z,EH*Z),(0,0,0,0)); d=ImageDraw.Draw(e)
    bw,gap=6.4,1.6; x0=(EW-(5*bw+4*gap))/2
    for i,n in enumerate(heights):
        for s in range(n):
            y1=EH-4-s*7; y0=y1-5.2; t=s/13
            col=(int(244+11*t),int(150+75*t),int(30+30*t),255)
            if dim: col=(150,120,50,150)
            d.rounded_rectangle([(x0+i*(bw+gap))*Z,y0*Z,(x0+i*(bw+gap)+bw)*Z,y1*Z],radius=1*Z,fill=col)
    e.save(os.path.join(OUT,name+".png"))
random.seed(11)
for f in range(6): eq("ck_eq%d"%f,[random.randint(3,13) for _ in range(5)])
eq("ck_eq_off",[2,2,2,2,2],True)
print("ok")
