# Draws the still artwork for the 10 "Now Playing" skins of the cassette Home Screen widget
# (360 x 322 design units). Moving parts (text, reels, disc, LEDs, clock, equalizer, keys) are real views on top.
import math, random, os, glob
from PIL import Image, ImageDraw, ImageFilter, ImageFont
OUT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "res", "drawable-nodpi")
K = 4; W, H = 360, 322; FW, FH = 900, 805
GOLD=(226,176,58,255); GOLD_L=(255,222,120,255)
def hx(s,a=255): s=s.lstrip('#'); return (int(s[0:2],16),int(s[2:4],16),int(s[4:6],16),a)
def new(): return Image.new("RGBA",(W*K,H*K),(0,0,0,0))
def comp(a,b): a.alpha_composite(b)
def vgrad(w,h,c1,c2,c3=None):
    g=Image.new("RGBA",(w,h)); d=ImageDraw.Draw(g)
    for y in range(h):
        t=y/max(1,h-1)
        if c3:
            a,b,u=(c1,c3,t*2) if t<.5 else (c3,c2,(t-.5)*2)
        else: a,b,u=c1,c2,t
        d.line([(0,y),(w,y)],fill=tuple(int(a[i]+(b[i]-a[i])*u) for i in range(4)))
    return g
def rr(img,box,r,c1,c2=None,stroke=None,sw=1.0,glow=0,c3=None):
    x0,y0,x1,y1=[int(v*K) for v in box]
    if c1 is not None:
        g=vgrad(x1-x0,y1-y0,c1,c2 or c1,c3); m=Image.new("L",g.size,0)
        ImageDraw.Draw(m).rounded_rectangle([0,0,g.width-1,g.height-1],radius=r*K,fill=255)
        l=new(); l.paste(g,(x0,y0),m); comp(img,l)
    if stroke:
        if glow:
            gl=new(); ImageDraw.Draw(gl).rounded_rectangle([x0,y0,x1,y1],radius=r*K,outline=stroke[:3]+(150,),width=int(sw*K*2))
            comp(img,gl.filter(ImageFilter.GaussianBlur(glow*K)))
        l=new(); ImageDraw.Draw(l).rounded_rectangle([x0,y0,x1,y1],radius=r*K,outline=stroke,width=max(1,int(sw*K))); comp(img,l)
def blob(img,box,col,blur):
    l=new(); ImageDraw.Draw(l).ellipse([v*K for v in box],fill=col); comp(img,l.filter(ImageFilter.GaussianBlur(blur*K)))
def poly(img,pts,fill,outline=None):
    l=new(); ImageDraw.Draw(l).polygon([(x*K,y*K) for x,y in pts],fill=fill,outline=outline); comp(img,l)
def circ(img,c,r,fill=None,outline=None,sw=1,glow=0):
    x,y=c
    if glow:
        gl=new(); ImageDraw.Draw(gl).ellipse([(x-r)*K,(y-r)*K,(x+r)*K,(y+r)*K],outline=(outline or fill)[:3]+(170,),width=int(sw*K*2))
        comp(img,gl.filter(ImageFilter.GaussianBlur(glow*K)))
    l=new(); ImageDraw.Draw(l).ellipse([(x-r)*K,(y-r)*K,(x+r)*K,(y+r)*K],fill=fill,outline=outline,width=max(1,int(sw*K))); comp(img,l)
def text(img,xy,t,size,fill,fontp="/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",anchor="mm"):
    l=new(); f=ImageFont.truetype(fontp,int(size*K)); ImageDraw.Draw(l).text((xy[0]*K,xy[1]*K),t,font=f,fill=fill,anchor=anchor); comp(img,l)
def save(im,name): im.resize((FW,FH),Image.LANCZOS).save(os.path.join(OUT,name+".png"),optimize=True)

KEYX=((54,17.5),(94,17.5),(134,17.5),(180,24),(226,17.5),(266,17.5),(306,17.5))

# ---------------- five cassette skins ----------------
TAPE=[ # body top, body bottom, glow, cassette top, cassette bottom, label head top/bottom, plate, keybar, key fill
 dict(b1="#2e60d6",b2="#08164e",gl=(90,150,255,110),c1=(74,126,232,215),c2=(12,34,108,240),h1="#e0162c",h2="#b20a1e",pl=((6,12,46),(10,22,70)),kb=((8,20,66),(5,11,40)),kf=(14,32,98)),
 dict(b1="#8a2536",b2="#2c0a12",gl=(230,110,130,100),c1=(190,86,72,225),c2=(92,30,26,240),h1="#2a86d2",h2="#1a5f9e",pl=((30,8,16),(44,12,24)),kb=((36,10,18),(22,6,12)),kf=(74,36,46)),
 dict(b1="#23805f",b2="#0a2a22",gl=(110,230,180,100),c1=(72,160,120,225),c2=(26,74,56,240),h1="#e8b030",h2="#b98816",pl=((8,34,26),(12,50,38)),kb=((10,42,32),(6,26,20)),kf=(30,86,68)),
 dict(b1="#c8741f",b2="#4a2406",gl=(255,190,110,100),c1=(232,170,84,225),c2=(120,72,28,240),h1="#2f5296",h2="#1f3a72",pl=((44,22,6),(66,34,10)),kb=((58,30,8),(36,18,4)),kf=(112,80,44)),
 dict(b1="#6c7486",b2="#1a1d28",gl=(200,210,235,100),c1=(142,150,170,225),c2=(60,68,88,240),h1="#e8bc3e",h2="#bd9122",pl=((20,23,32),(36,40,54)),kb=((32,36,48),(18,20,28)),kf=(66,74,94)),
]
def tape(idx,P):
    im=new()
    rr(im,(3,3,357,319),24,hx(P['b1']),hx(P['b2']),GOLD,2.4,glow=2.5)
    blob(im,(-40,-30,170,120),P['gl'],30); blob(im,(200,200,420,360),P['gl'][:3]+(80,),30)
    rr(im,(8,8,352,314),20,None,None,stroke=(255,226,140,170),sw=0.8)
    rr(im,(8,8,352,100),20,(255,255,255,62),(255,255,255,0))
    rr(im,(22,20,206,66),9,P['pl'][0]+(255,),P['pl'][1]+(255,),GOLD,1.6,glow=1.5)
    circ(im,(41,43),13.5,fill=(14,24,60,255),outline=GOLD,sw=1.6)
    ImageDraw.Draw(im).arc([27*K,28*K,55*K,56*K],180,360,fill=GOLD,width=int(2.6*K))
    rr(im,(25,40,31,52),2.5,GOLD,(180,130,30,255)); rr(im,(51,40,57,52),2.5,GOLD,(180,130,30,255))
    text(im,(41,43),"♪",16,GOLD_L)
    pts=[(66+t*130, 63.2 - 2.2*math.sin(math.pi*t)) for t in [i/40 for i in range(41)]]
    ImageDraw.Draw(im).line([(x*K,y*K) for x,y in pts],fill=GOLD,width=int(1.2*K))
    rr(im,(22,71,106,94),8,P['pl'][0]+(170,),P['pl'][0]+(170,),(255,255,255,70),0.8)
    text(im,(220,48),"♫",24,GOLD_L); text(im,(220,76),"♪",16,GOLD)
    blob(im,(228,14,316,102),(255,200,60,60),9)
    rr(im,(44,108,316,246),12,P['c1'],P['c2'],GOLD,1.5,glow=2)
    rr(im,(48,112,312,242),10,None,None,stroke=(255,255,255,80),sw=0.7)
    poly(im,[(52,112),(150,112),(96,242),(52,242)],(255,255,255,26))
    for sx,sy in ((54,118),(306,118),(54,236),(306,236)):
        circ(im,(sx,sy),3.6,fill=(214,170,70,255),outline=(120,86,20,255),sw=0.6)
        ImageDraw.Draw(im).line([((sx-2)*K,(sy+1.2)*K),((sx+2)*K,(sy-1.2)*K)],fill=(90,60,10,255),width=int(0.8*K))
    rr(im,(62,116,298,172),5,(252,242,214,255),(244,230,190,255))
    rr(im,(62,116,298,129),5,hx(P['h1']),hx(P['h2'])); rr(im,(62,124,298,129),0,hx(P['h1']),hx(P['h2']))
    d=ImageDraw.Draw(im)
    for y in (160,166): d.line([(70*K,y*K),(290*K,y*K)],fill=(214,176,86,255),width=int(0.8*K))
    rr(im,(104,178,256,224),23,(4,7,20,255),(6,12,34,255),(150,168,210,255),2,glow=1)
    rr(im,(112,181,248,197),8,(255,255,255,26),(255,255,255,0))
    d=ImageDraw.Draw(im)
    for y in (196,202,208):
        d.line([(66*K,y*K),(98*K,y*K)],fill=GOLD,width=int(1.6*K)); d.line([(262*K,y*K),(294*K,y*K)],fill=GOLD,width=int(1.6*K))
    poly(im,[(126,246),(146,228),(214,228),(234,246)],(8,10,18,255),(40,40,48,255))
    rr(im,(171,229,189,238),2,(240,240,246,255),(168,172,186,255))
    for cx in (154,206):
        circ(im,(cx,236),5,fill=(214,40,24,255),outline=(30,10,10,255),sw=0.8,glow=1.5); circ(im,(cx-1.4,234.4),1.5,fill=(255,170,150,200))
    rr(im,(22,258,338,308),14,P['kb'][0]+(240,),P['kb'][1]+(248,),GOLD,1.4,glow=1.5)
    for cx,r in KEYX:
        circ(im,(cx,283),r,fill=P['kf']+(255,),outline=GOLD,sw=2.0 if r>20 else 1.5,glow=1.6)
        circ(im,(cx,283),r-3,outline=(255,255,255,40),sw=0.6)
    skinbtn(im,GOLD)
    save(im,"ck_bg%d"%idx)

def skinbtn(im,col):   # round "change skin" button, top-right corner
    circ(im,(330,25),12.5,fill=(8,14,40,215),outline=col,sw=1.4,glow=1.2)

# ---------------- five CD skins ----------------
CD=[ # body top/mid/bottom, key fill, accent
 dict(b=("#4a4f5e","#2a2e3a","#14161d"),kf=(60,66,82),ac="#9fd3ff"),
 dict(b=("#2c4a8a","#17295a","#0a1230"),kf=(48,76,140),ac="#a9c8ff"),
 dict(b=("#8a2a3e","#561425","#2b0812"),kf=(120,44,64),ac="#ffd6a0"),
 dict(b=("#2f8f94","#17595f","#0a2d33"),kf=(36,112,118),ac="#b8f5f0"),
 dict(b=("#c9a24a","#8a6a22","#4a3610"),kf=(150,118,48),ac="#fff0c2"),
]
def cd(idx,P):
    im=new(); ac=hx(P['ac'])
    rr(im,(3,3,357,319),24,hx(P['b'][0]),hx(P['b'][2]),(7,8,11,255),2.5,c3=hx(P['b'][1]))
    rr(im,(8,8,352,314),20,None,None,stroke=ac[:3]+(90,),sw=0.8)
    rr(im,(8,8,352,100),20,(255,255,255,40),(255,255,255,0))
    rr(im,(14,14,346,250),16,(16,18,26,155),(12,14,20,165),ac,1.2,glow=1)
    # disc well
    circ(im,(108,146),68,fill=(6,16,26,245),outline=ac,sw=1.2)
    circ(im,(108,146),66,outline=(0,0,0,90),sw=2)
    circ(im,(262,146),55,fill=(0,0,0,70))
    d=ImageDraw.Draw(im)
    d.arc([(108-54.6)*K,(146-54.6)*K,(108+54.6)*K,(146+54.6)*K],200,257,fill=(255,255,255,215),width=int(4*K))
    d.arc([(108-54.6)*K,(146-54.6)*K,(108+54.6)*K,(146+54.6)*K],20,77,fill=(255,255,255,125),width=int(2*K))
    rr(im,(22,214,338,242),7,(6,16,26,240),(6,16,26,240),ac,1.0)
    rr(im,(22,258,338,308),14,(11,13,19,235),(8,9,14,245),ac[:3]+(200,),1.2,glow=1)
    for cx,r in KEYX:
        circ(im,(cx,283),r,fill=P['kf']+(255,),outline=ac,sw=2.0 if r>20 else 1.5,glow=1.2)
        circ(im,(cx,283),r-3,outline=(255,255,255,40),sw=0.6)
    skinbtn(im,ac)
    save(im,"ck_bg%d"%(5+idx))

for i,p in enumerate(TAPE): tape(i,p)
for i,p in enumerate(CD): cd(i,p)

# ---------------- side equalizer (tape skins) ----------------
EW,EH=44,138; Z=2
def eq(name,heights,dim=False):
    e=Image.new("RGBA",(EW*Z,EH*Z),(0,0,0,0)); d=ImageDraw.Draw(e)
    bw,gap=6.4,1.6; x0=(EW-(5*bw+4*gap))/2
    for i,n in enumerate(heights):
        for s in range(n):
            y1=EH-4-s*7; y0=y1-5.2; t=s/13
            col=(int(244+11*t),int(150+75*t),int(30+30*t),255)
            if dim: col=(150,120,50,150)
            d.rounded_rectangle([(x0+i*(bw+gap))*Z,y0*Z,(x0+i*(bw+gap)+bw)*Z,y1*Z],radius=1*Z,fill=col)
    e.save(os.path.join(OUT,name+".png"))
random.seed(11)
for f in range(6): eq("ck_eq%d"%f,[random.randint(3,13) for _ in range(5)])
eq("ck_eq_off",[2,2,2,2,2],True)

# ---------------- CD disc (12 turning frames), CD clock dial + hands, skin button icon ----------------
DS=3; D=136*DS//2*2
def disc(name,ang):
    S2=2; sz=D*S2; im=Image.new("RGBA",(sz,sz),(0,0,0,0)); d=ImageDraw.Draw(im); c=sz/2; u=sz/136
    d.ellipse([c-62*u,c-62*u,c+62*u,c+62*u],fill=(240,243,248,255),outline=(255,255,255,255),width=int(2*u))
    ov=Image.new("RGBA",(sz,sz),(0,0,0,0)); od=ImageDraw.Draw(ov)
    cols=[(127,227,255),(255,154,216),(255,226,122),(157,255,184),(179,166,255),(255,176,138)]
    for i,cl in enumerate(cols): od.pieslice([c-60*u,c-60*u,c+60*u,c+60*u],ang+i*60-90,ang+i*60-30,fill=cl+(40,))
    for a0,a1,col in ((-80,-52,(255,255,255,242)),(100,128,(255,255,255,242)),(10,32,(174,183,198,80)),(190,212,(174,183,198,80))):
        od.pieslice([c-60*u,c-60*u,c+60*u,c+60*u],ang+a0,ang+a1,fill=col)
    im.alpha_composite(ov); d=ImageDraw.Draw(im)
    for r in (28.5,33.5,38.4,43.4,48.4,53.3,57.7): d.ellipse([c-r*u,c-r*u,c+r*u,c+r*u],outline=(196,204,216,170),width=max(1,int(.5*u)))
    d.ellipse([c-20.5*u,c-20.5*u,c+20.5*u,c+20.5*u],fill=(236,239,245,255),outline=(170,178,191,255),width=int(.8*u))
    d.ellipse([c-5.6*u,c-5.6*u,c+5.6*u,c+5.6*u],fill=(6,16,26,255),outline=(170,178,191,255),width=int(1*u))
    im.resize((D,D),Image.LANCZOS).save(os.path.join(OUT,name+".png"))
for i in range(12): disc("ck_cd%d"%i,i*30)
disc("ck_cd_off",0)
FB="/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
def cddial():
    Wd=400; S2=3; im=Image.new("RGBA",(Wd*S2,Wd*S2),(0,0,0,0)); d=ImageDraw.Draw(im); c=Wd*S2/2
    d.ellipse([4*S2,4*S2,(Wd-4)*S2,(Wd-4)*S2],fill=(13,15,20,255),outline=(174,183,198,255),width=int(10*S2))
    f=ImageFont.truetype(FB,int(46*S2))
    for i in range(12):
        a=math.radians(i*30); r=c-80*S2; t=str(12 if i==0 else i)
        d.text((c+r*math.sin(a),c-r*math.cos(a)),t,font=f,fill=(219,232,255,255),anchor="mm")
    for i in range(60):
        a=math.radians(i*6); r1=c-34*S2; r2=c-(46*S2 if i%5==0 else 40*S2)
        if i%5: d.line([c+r1*math.sin(a),c-r1*math.cos(a),c+r2*math.sin(a),c-r2*math.cos(a)],fill=(143,154,176,255),width=2*S2)
    im.resize((Wd,Wd),Image.LANCZOS).save(os.path.join(OUT,"ck2_dial.png"))
def cdhand(name,length,width):
    Wd=400; S2=3; im=Image.new("RGBA",(Wd*S2,Wd*S2),(0,0,0,0)); d=ImageDraw.Draw(im); c=Wd*S2/2
    d.rounded_rectangle([c-width*S2/2,c-length*S2,c+width*S2/2,c+22*S2],radius=width*S2/2,fill=(232,240,255,255))
    d.ellipse([c-14*S2,c-14*S2,c+14*S2,c+14*S2],fill=(255,77,77,255))
    im.resize((Wd,Wd),Image.LANCZOS).save(os.path.join(OUT,name+".png"))
cddial(); cdhand("ck2_hand_hour",95,14); cdhand("ck2_hand_min",140,9)
# skin button icon: two arrows chasing round a ring
S2=4; im=Image.new("RGBA",(96*S2,96*S2),(0,0,0,0)); d=ImageDraw.Draw(im); c=48*S2; r=26*S2
for a0 in (200,20):
    d.arc([c-r,c-r,c+r,c+r],a0,a0+120,fill=GOLD_L,width=7*S2)
    e=math.radians(a0+120); ex,ey=c+r*math.cos(e),c+r*math.sin(e); tx,ty=-math.sin(e),math.cos(e); nx,ny=math.cos(e),math.sin(e)
    d.polygon([(ex+tx*16*S2,ey+ty*16*S2),(ex+nx*11*S2,ey+ny*11*S2),(ex-nx*11*S2,ey-ny*11*S2)],fill=GOLD_L)
im.resize((96,96),Image.LANCZOS).save(os.path.join(OUT,"ck_ic_skin.png"))
print("ok")
