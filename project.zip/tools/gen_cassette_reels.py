# Cassette reels + tape packs for the Home Screen widget.
# Copy of the reel drawn on the "Now Playing" screen (index.html, #cass SVG), unit for unit:
#   flange r=17 (white radial gradient, grey rim), 6 dark spokes, hub r=10.5, 6 white teeth,
#   centre r=3.6, red marker dot.  Turns clockwise, left reel 1.4 s/turn, right reel 1.9 s/turn.
#   Tape packs: brown circle r=22 scaled 0.70..1.04 (70 s ping-pong), pkA shrinks, pkB grows.
# 24 frames = 15 degrees apart = one full turn (the red marker makes the picture repeat only every 360 degrees).
import math, os
import numpy as np
from PIL import Image, ImageDraw

OUT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "res", "drawable-nodpi")
W = 160                      # output canvas (px)
K = 58 / 17.0                # px per SVG unit (flange r=17 -> 58 px, as in the widget background art)
S = 4                        # supersampling
FRAMES = 24
PACK_LEVELS = 8              # tape pack sizes (scale 0.70 .. 1.04)

def hexc(h): return tuple(int(h[i:i+2], 16) for i in (1, 3, 5))

def disc(r, cx, cy, gr, c0, c1, scale=1.0):
    """Filled circle (radius r units) with the SVG radial gradient (objectBoundingBox cx,cy,r given in bbox fractions)."""
    n = W*S
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float64)
    ux = (xx + .5 - n/2) / (K*S); uy = (yy + .5 - n/2) / (K*S)      # SVG units from the centre
    size = 2*r
    gx, gy, gR = -r + cx*size, -r + cy*size, gr*size
    t = np.clip(np.hypot(ux-gx, uy-gy) / gR, 0, 1)[..., None]
    col = np.array(c0)*(1-t) + np.array(c1)*t
    a = (np.hypot(ux, uy) <= r).astype(np.float64)[..., None] * 255
    return Image.fromarray(np.concatenate([col, a], axis=2).astype(np.uint8), "RGBA")

def upright_reel():
    im = disc(17, .4, .35, .8, hexc("#ffffff"), hexc("#b9bcc6"))
    d = ImageDraw.Draw(im); c = W*S/2; u = K*S
    def circ(r, **kw): d.ellipse([c-r*u, c-r*u, c+r*u, c+r*u], **kw)
    def rrect(x, y, w, h, rx, ang, fill):          # SVG rect (relative to centre) turned by ang degrees (clockwise)
        layer = Image.new("RGBA", im.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(layer)
        ld.rounded_rectangle([c+x*u, c+y*u, c+(x+w)*u, c+(y+h)*u], radius=rx*u, fill=fill)
        return layer.rotate(-ang, resample=Image.BICUBIC, center=(c, c))
    circ(17, outline=hexc("#8d929c")+(255,), width=int(1*u))                    # flange rim
    for k in range(6):                                                           # dark spokes, rotate(30+60k)
        im.alpha_composite(rrect(-1, -16, 2, 9, 0, 30+60*k, hexc("#2a2d36")+(255,)))
    circ(10.5, fill=hexc("#15171d")+(255,), outline=hexc("#555555")+(255,), width=int(.8*u))   # hub
    for k in range(6):                                                           # white teeth, rotate(60k)
        im.alpha_composite(rrect(-1.6, -11.5, 3.2, 6.5, 1, 60*k, hexc("#e9e9ee")+(255,)))
    circ(3.6, fill=(0, 0, 0, 255))                                               # centre
    d = ImageDraw.Draw(im)
    d.ellipse([c-2.2*u, c-14*u-2.2*u, c+2.2*u, c-14*u+2.2*u], fill=hexc("#e53935")+(255,))   # red marker
    return im

def save(im, name): im.resize((W, W), Image.LANCZOS).save(os.path.join(OUT, name + ".png"))

base = upright_reel(); c = W*S/2
for i in range(FRAMES):                                  # SVG rotate() is clockwise; PIL rotate() is counter-clockwise
    save(base.rotate(-i*360.0/FRAMES, resample=Image.BICUBIC, center=(c, c)), "ck_reel_f%d" % i)
for i in range(PACK_LEVELS):
    s = 0.70 + (1.04-0.70) * i / (PACK_LEVELS-1)
    save(disc(22*s, .4, .35, .9, hexc("#8a5f3b"), hexc("#3a2415")), "ck_pack%d" % i)
print("reels + packs done")
