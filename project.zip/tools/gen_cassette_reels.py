# Cassette reel frames for the Home Screen widget (realistic turning reels).
# A real cassette hub has 6 identical teeth, so the picture repeats every 60 degrees.
# We draw FRAMES pictures covering exactly one 60-degree period (7.5 degrees apart).
# Turning them in a loop looks like a smooth, continuous, counter-clockwise rotation
# (real cassettes turn counter-clockwise) with no "wagon wheel" flicker.
import math, os
from PIL import Image, ImageDraw

OUT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "res", "drawable-nodpi")
S = 4          # supersampling
W = 160
FRAMES = 8     # 8 x 7.5 deg = 60 deg = one full period of the 6-tooth hub
STEP = 60.0 / FRAMES

def reel(name, angle, tape):
    im = Image.new("RGBA", (W*S, W*S), (0, 0, 0, 0)); d = ImageDraw.Draw(im); c = W*S/2
    def circ(r, **kw): d.ellipse([c-r*S, c-r*S, c+r*S, c+r*S], **kw)
    if tape > 0:                                   # tape pack: dark brown with thin layer rings
        circ(tape, fill=(86, 54, 28, 255))
        for r in range(int(tape)-4, 62, -5):
            circ(r, outline=(104, 68, 36, 255), width=S)
        circ(tape, outline=(60, 38, 20, 255), width=2*S)
    R = 58                                          # white flange with gold edge
    circ(R, fill=(236, 236, 240, 255), outline=(212, 166, 58, 255), width=3*S)
    circ(R-5, outline=(205, 207, 214, 255), width=S)
    for k in range(6):                              # six dark spokes (+ thin ribs), turning
        a = math.radians(angle + k*60)
        d.line([c+18*S*math.cos(a), c+18*S*math.sin(a), c+50*S*math.cos(a), c+50*S*math.sin(a)],
               fill=(15, 15, 18, 255), width=11*S)
        b = math.radians(angle + k*60 + 22)
        d.line([c+30*S*math.cos(b), c+30*S*math.sin(b), c+52*S*math.cos(b), c+52*S*math.sin(b)],
               fill=(15, 15, 18, 255), width=5*S)
        m = math.radians(angle + k*60 + 30)         # small rivet between spokes (keeps 60-degree symmetry)
        circ_x, circ_y = c+40*S*math.cos(m), c+40*S*math.sin(m)
        d.ellipse([circ_x-3*S, circ_y-3*S, circ_x+3*S, circ_y+3*S], fill=(150, 152, 160, 255))
    circ(17, fill=(12, 12, 14, 255), outline=(70, 72, 80, 255), width=S)   # hub
    for k in range(6):                              # six white hub teeth pointing inward
        a = math.radians(angle + k*60)
        ca, sa = math.cos(a), math.sin(a)
        p = [(10, -2.2), (16, -2.8), (16, 2.8), (10, 2.2)]
        d.polygon([(c+(x*ca-y*sa)*S, c+(x*sa+y*ca)*S) for x, y in p], fill=(238, 238, 242, 255))
    circ(8, fill=(5, 5, 6, 255))                    # spindle hole
    hl = Image.new("RGBA", im.size, (0, 0, 0, 0)); h = ImageDraw.Draw(hl)   # fixed glossy highlight (does not turn)
    h.pieslice([c-R*S, c-R*S, c+R*S, c+R*S], 200, 290, fill=(255, 255, 255, 46))
    im = Image.alpha_composite(im, hl)
    im.resize((W, W), Image.LANCZOS).save(os.path.join(OUT, name + ".png"))

for i in range(FRAMES):
    ang = -i * STEP                                 # negative = counter-clockwise
    reel("ck_reel_l%d" % i, ang, 0)
    reel("ck_reel_r%d" % i, ang, 76)
reel("ck_reel_l_off", 0, 0); reel("ck_reel_r_off", 0, 76)
print("reels done")
