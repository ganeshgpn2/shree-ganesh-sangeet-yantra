# Generates the pictures used by the cassette (Now Playing) Home Screen widget.
import math, random, os
from PIL import Image, ImageDraw, ImageFont
OUT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "res", "drawable-nodpi")
S = 4  # supersampling

def new(w, h): return Image.new("RGBA", (w*S, h*S), (0,0,0,0))
def fin(im, name, w, h):
    im.resize((w, h), Image.LANCZOS).save(os.path.join(OUT, name + ".png"))
def font(path, size): return ImageFont.truetype(path, size*S)
SERIF_B = "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf"

GOLD=(201,162,70,255); CREAM=(250,238,200,255); DARK=(30,22,10,255)

# ---------- analog clock dial + hands (Roman numerals, like the Now Playing screen) ----------
def dial():
    W=400; im=new(W,W); d=ImageDraw.Draw(im); c=W*S/2
    d.ellipse([4*S,4*S,(W-4)*S,(W-4)*S], fill=GOLD)
    d.ellipse([22*S,22*S,(W-22)*S,(W-22)*S], fill=CREAM)
    for i in range(60):
        a=math.radians(i*6); r1=c-34*S; r2=c-(50*S if i%5==0 else 42*S)
        d.line([c+r1*math.sin(a),c-r1*math.cos(a),c+r2*math.sin(a),c-r2*math.cos(a)], fill=(90,70,30,255), width=(5 if i%5==0 else 2)*S)
    f=font(SERIF_B,34)
    for i,t in enumerate(["XII","I","II","III","IV","V","VI","VII","VIII","IX","X","XI"]):
        a=math.radians(i*30); r=c-92*S
        x=c+r*math.sin(a); y=c-r*math.cos(a)
        bb=d.textbbox((0,0),t,font=f); d.text((x-(bb[2]+bb[0])/2,y-(bb[3]+bb[1])/2),t,font=f,fill=(50,35,15,255))
    fin(im,"ck_dial",W,W)
def hand(name,length,width,color):
    W=400; im=new(W,W); d=ImageDraw.Draw(im); c=W*S/2
    d.rounded_rectangle([c-width*S/2,c-length*S,c+width*S/2,c+22*S], radius=width*S/2, fill=color)
    d.ellipse([c-14*S,c-14*S,c+14*S,c+14*S], fill=(200,30,30,255))
    fin(im,name,W,W)
dial(); hand("ck_hand_hour",110,14,(25,25,30,255)); hand("ck_hand_min",160,9,(25,25,30,255))

# ---------- reels (12 turning frames), left = little tape, right = big tape ----------
def reel(name,angle,tape):
    W=160; im=new(W,W); d=ImageDraw.Draw(im); c=W*S/2
    if tape>0:
        d.ellipse([c-tape*S,c-tape*S,c+tape*S,c+tape*S], fill=(110,70,35,255))
        d.ellipse([c-tape*S+6*S,c-tape*S+6*S,c+tape*S-6*S,c+tape*S-6*S], fill=(90,55,28,255))
    R=58
    d.ellipse([c-R*S,c-R*S,c+R*S,c+R*S], fill=(236,236,240,255), outline=(170,170,180,255), width=3*S)
    for k in range(6):
        a=math.radians(angle+k*60)
        x1=c+18*S*math.cos(a); y1=c+18*S*math.sin(a); x2=c+50*S*math.cos(a); y2=c+50*S*math.sin(a)
        d.line([x1,y1,x2,y2], fill=(15,15,18,255), width=11*S)
        b=math.radians(angle+k*60+22)
        d.line([c+30*S*math.cos(b),c+30*S*math.sin(b),c+52*S*math.cos(b),c+52*S*math.sin(b)], fill=(15,15,18,255), width=5*S)
    d.ellipse([c-17*S,c-17*S,c+17*S,c+17*S], fill=(12,12,14,255))
    d.ellipse([c-7*S,c-7*S,c+7*S,c+7*S], fill=(235,235,235,255))
    a=math.radians(angle+60); d.ellipse([c+38*S*math.cos(a)-6*S,c+38*S*math.sin(a)-6*S,c+38*S*math.cos(a)+6*S,c+38*S*math.sin(a)+6*S], fill=(230,50,50,255))
    fin(im,name,W,W)
for i in range(12):
    reel("ck_reel_l%d"%i, i*30, 0)
    reel("ck_reel_r%d"%i, i*30, 76)
reel("ck_reel_l_off", 0, 0); reel("ck_reel_r_off", 0, 76)

# ---------- LEDs ----------
def led(name,col,on):
    W=48; im=new(W,W); d=ImageDraw.Draw(im); c=W*S/2
    if on:
        for r,a in ((22,60),(18,110)): d.ellipse([c-r*S,c-r*S,c+r*S,c+r*S], fill=col[:3]+(a,))
        d.ellipse([c-12*S,c-12*S,c+12*S,c+12*S], fill=col)
        d.ellipse([c-6*S,c-8*S,c+2*S,c],fill=(255,255,255,150))
    else:
        d.ellipse([c-12*S,c-12*S,c+12*S,c+12*S], fill=(col[0]//4,col[1]//4,col[2]//4,255))
    fin(im,name,W,W)
led("ck_led_play_on",(60,255,110,255),True); led("ck_led_play_off",(60,255,110,255),False)
led("ck_led_rec_on",(255,50,50,255),True);  led("ck_led_rec_off",(255,50,50,255),False)

# ---------- key icons ----------
def icon(name,draw):
    W=96; im=new(W,W); d=ImageDraw.Draw(im); draw(d,W*S); fin(im,name,W,W)
def tri(d,x,y,w,h,col,right=True):
    pts=[(x,y),(x,y+h),(x+w,y+h/2)] if right else [(x+w,y),(x+w,y+h),(x,y+h/2)]
    d.polygon(pts,fill=col)
Y=(244,196,66,255); B=(120,170,255,255); G=(60,240,110,255); Wh=(236,236,242,255); Rd=(230,50,50,255)
icon("ck_ic_rec",lambda d,s: d.ellipse([s*.24,s*.24,s*.76,s*.76],fill=Rd))
icon("ck_ic_stop",lambda d,s: d.rounded_rectangle([s*.26,s*.26,s*.74,s*.74],radius=s*.05,fill=Wh))
icon("ck_ic_play",lambda d,s: tri(d,s*.30,s*.20,s*.46,s*.60,G))
icon("ck_ic_pause",lambda d,s:(d.rounded_rectangle([s*.28,s*.22,s*.44,s*.78],radius=s*.03,fill=Y),d.rounded_rectangle([s*.56,s*.22,s*.72,s*.78],radius=s*.03,fill=Y)))
icon("ck_ic_ff",lambda d,s:(tri(d,s*.18,s*.26,s*.32,s*.48,Y),tri(d,s*.48,s*.26,s*.32,s*.48,Y)))
icon("ck_ic_rew",lambda d,s:(tri(d,s*.20,s*.26,s*.32,s*.48,Y,False),tri(d,s*.50,s*.26,s*.32,s*.48,Y,False)))
icon("ck_ic_next",lambda d,s:(tri(d,s*.22,s*.24,s*.44,s*.52,B),d.rectangle([s*.68,s*.24,s*.76,s*.76],fill=B)))
icon("ck_ic_prev",lambda d,s:(tri(d,s*.34,s*.24,s*.44,s*.52,B,False),d.rectangle([s*.24,s*.24,s*.32,s*.76],fill=B)))

# ---------- visualizer frames ----------
random.seed(7)
for f in range(6):
    W,H=300,48; im=new(W,H); d=ImageDraw.Draw(im)
    n=30; bw=W/n
    for i in range(n):
        h=random.randint(5,H-4)
        col=(122,92,190,255) if i%3 else (150,115,215,255)
        d.rounded_rectangle([i*bw*S+2*S,(H-h)*S,(i+1)*bw*S-2*S,H*S],radius=2*S,fill=col)
    fin(im,"ck_vis%d"%f,W,H)
im=new(300,48); d=ImageDraw.Draw(im)
for i in range(30): d.rounded_rectangle([i*10*S+2*S,(48-6)*S,(i+1)*10*S-2*S,48*S],radius=2*S,fill=(100,80,150,255))
fin(im,"ck_vis_off",300,48)
print("done")
