(function(){
  if(window.__sgsBridge)return; window.__sgsBridge=1;
  var last="";
  function push(){
    try{
      var playing=false;
      try{var e=E();playing=!e.paused;}catch(x){}
      if(!playing){try{playing=!vd.paused}catch(x){}}
      var t=(typeof Q!=="undefined"&&Q[qi])?Q[qi]:null;
      var title=t?t.name:"Shree Ganesh Sangeet Yantra";
      var sub=t?(kind=="r"?"Radio · "+(t.cat||"Live"):((t.folder||[]).slice(-1)[0]||"")):"";
      var key=title+"|"+sub+"|"+playing;
      if(key===last)return; last=key;
      Android.update(String(title),String(sub),!!playing);
    }catch(x){}
  }
  try{
    [au,ra,vd].forEach(function(a){
      ["play","pause","playing","ended","emptied"].forEach(function(ev){
        a.addEventListener(ev,function(){setTimeout(push,80)});
      });
    });
    var oi=info; info=function(){var r=oi.apply(this,arguments);setTimeout(push,80);return r};
  }catch(x){}
  /* ---- real Android alarms ---- */
  /* The native Android service now rings alarms; switch off the old browser timer check. */
  try{alCheck=function(){}}catch(x){}
  var lastAl="";
  function pushAl(){try{var s=JSON.stringify(CFG.al);if(s===lastAl)return;lastAl=s;Android.setAlarms(s)}catch(x){}}
  try{
    var po=JSON.parse(Android.consumePendingOff()||"[]");
    if(po.length){CFG.al.forEach(function(a){if(po.indexOf(a.id)>=0)a.on=false});save();}
  }catch(x){}
  pushAl();
  try{document.getElementById("snz").addEventListener("click",function(){try{if(ringing)Android.snooze(String(ringing.id))}catch(x){}},true)}catch(x){}
  window.__sgsRing=function(id,snz){
    try{
      var a=CFG.al.find(function(x){return x.id==id});
      var dk=new Date().toDateString();
      if(!a||ringing||(!snz&&a.last===dk+a.time)){Android.alarmHandled();return}
      a.last=dk+a.time;snoozeAt=0;
      if(!a.days.length&&!snz)a.on=false;
      save();
      Promise.resolve(ring(a)).then(function(){Android.alarmHandled()},function(){Android.alarmHandled()});
      try{if($("#als").classList.contains("on"))alRender()}catch(x){}
    }catch(x){try{Android.alarmHandled()}catch(y){}}
  };
  setInterval(function(){push();pushAl()},3000);
})();
