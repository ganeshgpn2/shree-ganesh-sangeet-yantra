(function(){
  if(window.__sgsBridge)return; window.__sgsBridge=1;
  var last="";
  function push(force){
    try{
      var playing=false;
      try{var e=E();playing=!e.paused;}catch(x){}
      if(!playing){try{playing=!vd.paused}catch(x){}}
      var t=(typeof Q!=="undefined"&&Q[qi])?Q[qi]:null;
      var title=t?t.name:"Shree Ganesh Sangeet Yantra";
      var sub=t?(kind=="r"?"Radio · "+(t.cat||"Live"):((t.folder||[]).slice(-1)[0]||"")):"";
      var tk=t&&t.key?t.key:"";
      var key=title+"|"+sub+"|"+playing+"|"+kind+"|"+tk;
      if(key===last&&!force)return; last=key;
      var pos=0,dur=0;
      try{var ee=E();pos=Math.floor((ee.currentTime||0)*1000);dur=isFinite(ee.duration)?Math.floor(ee.duration*1000):0}catch(x){}
      Android.update(String(title),String(sub),!!playing);
      try{Android.state(JSON.stringify({t:String(title),s:String(sub),p:!!playing,k:(typeof kind!=="undefined"?kind:""),key:String(tk),pos:pos,dur:dur}))}catch(x){}
    }catch(x){}
  }
  try{
    [au,ra,vd].forEach(function(a){
      ["play","pause","playing","ended","emptied","seeked"].forEach(function(ev){
        a.addEventListener(ev,function(){setTimeout(function(){push(true)},80)});
      });
    });
    var oi=info; info=function(){var r=oi.apply(this,arguments);setTimeout(push,80);return r};
  }catch(x){}
  /* remember radio streams that really played on this phone (used as alarm backups) */
  try{ra.addEventListener("playing",function(){try{if(ra.src&&ra.src.indexOf("http")===0)Android.radioOk(ra.src)}catch(x){}})}catch(x){}
  /* ---- phone music/video library from Android MediaStore ---- */
  try{au.crossOrigin="anonymous";vd.crossOrigin="anonymous"}catch(x){}
  window.__sgsApplyScan=function(j){
    var mk=function(k){return function(r){return {name:r.n,ext:(r.e||"").toLowerCase(),folder:r.f,key:"ms:"+k+r.id,src:"ms",k:k,murl:"https://sgs.media/"+k+"/"+r.id,dur:r.d,album:r.al||""}}};
    var A=j.a.map(mk("a")),V=j.v.map(mk("v"));
    var cmp=function(x,y){return x.name.localeCompare(y.name,"ne")};
    A.sort(cmp);V.sort(cmp);
    lib={a:A,v:V,l:{}};
    j.a.forEach(function(r){if(r.s)artMap["ms:a"+r.id]=r.s});
    try{lw("sgs-art",artMap)}catch(x){}
    needPerm=false;
    var all=A.concat(V),nf={};all.forEach(function(x){nf[x.folder.join("/")]=1});
    window.__scanSummary=A.length+" गीत · "+V.length+" भिडियो · "+Object.keys(nf).length+" फोल्डर";
    dstat(window.__scanSummary);
    renderDev();
    window.__sgsLastScan=Date.now();
  };
  /* a small progress card at the bottom of the screen while the phone is scanned */
  function scanUI(ph,d,t){
    var el=document.getElementById("sgs-scan");
    if(ph===null){if(el)el.remove();return}
    if(!el){
      el=document.createElement("div");el.id="sgs-scan";
      el.style.cssText="position:fixed;left:12px;right:12px;bottom:90px;z-index:99999;background:#10233f;color:#fff;border:1px solid #f2b705;border-radius:14px;padding:12px 14px;font-size:14px;box-shadow:0 6px 20px #0008";
      el.innerHTML='<div id="sgs-scan-t" style="font-weight:700"></div><div style="height:8px;background:#ffffff33;border-radius:4px;margin-top:8px;overflow:hidden"><div id="sgs-scan-b" style="height:100%;width:0;background:#f2b705;transition:width .2s"></div></div>';
      document.body.appendChild(el);
    }
    var tt=document.getElementById("sgs-scan-t"),bb=document.getElementById("sgs-scan-b");
    if(ph==="done"){
      tt.textContent="✅ स्क्यान सकियो — "+(window.__scanSummary||"");bb.style.width="100%";
      var st=document.getElementById("scan-st");if(st)st.textContent="अन्तिम स्क्यान: "+(window.__scanSummary||"");
      setTimeout(function(){scanUI(null)},3500);return;
    }
    tt.textContent="📂 फोन स्क्यान हुँदैछ… "+ph+(t?" "+d+" / "+t:"");
    bb.style.width=(t?Math.min(100,Math.round(d*100/t)):5)+"%";
    var st2=document.getElementById("scan-st");if(st2)st2.textContent="स्क्यान हुँदैछ… "+ph+(t?" "+d+" / "+t:"");
  }
  window.__sgsScanProgress=function(ph,d,t){scanUI(ph,d,t)};
  window.__sgsScanDone=function(){
    try{window.__sgsApplyScan(JSON.parse(Android.scanResult()))}catch(x){try{toast("स्क्यान असफल: "+x)}catch(y){}}
    window.__scanBusy=false;scanUI("done");
  };
  window.__sgsScan=function(){
    if(window.__scanBusy)return;
    window.__scanBusy=true;scanUI("सुरु हुँदैछ…",0,0);
    try{if(Android.scanMediaAsync){Android.scanMediaAsync();return}}catch(x){}
    try{window.__sgsApplyScan(JSON.parse(Android.scanMedia()))}catch(x){try{toast("स्क्यान असफल: "+x)}catch(y){}}
    window.__scanBusy=false;scanUI(null);
  };
  window.__sgsScanRequest=function(){
    try{ if(Android.hasMediaPerm())window.__sgsScan(); else Android.requestMediaPerm(); }catch(x){}
  };
  window.__sgsScanSoon=function(){
    try{ if(Android.hasMediaPerm()&&(!window.__sgsLastScan||Date.now()-window.__sgsLastScan>30000))window.__sgsScan(); }catch(x){}
  };
  try{
    rescan=function(){window.__sgsScanRequest();return Promise.resolve()};
    addDir=function(){window.__sgsScanRequest()};
    askPerm=function(){window.__sgsScanRequest();return Promise.resolve()};
    indexArtists=function(){return Promise.resolve()};
    var oact=act;
    act=function(a){ if(a==="files"){window.__sgsScanRequest();return} return oact(a) };
  }catch(x){}
  try{ if(Android.hasMediaPerm())window.__sgsScan(); }catch(x){}
  /* ---- radio is played by the Android (native) player; this page only mirrors it ---- */
  var SIL=null;
  window.__nativeSilent=function(){
    try{
      if(!SIL){
        var AC=window.AudioContext||window.webkitAudioContext,c=new AC(),d=c.createMediaStreamDestination(),o=c.createOscillator(),g=c.createGain();
        g.gain.value=0;o.connect(g);g.connect(d);o.start();SIL={c:c,s:d.stream};
      }
      if(SIL.c.state==="suspended")SIL.c.resume();
      if(ra.srcObject!==SIL.s)ra.srcObject=SIL.s;ra.muted=true;ra._ig=Date.now();
      return Promise.resolve(ra.play()).catch(function(){});
    }catch(e){return Promise.resolve()}
  };
  window.__nativeRadioOn=function(t){
    try{
      if(Date.now()<(window.__nativeOff||0))return false;
      if(!Android.radioPlay)return false;
      window.__nativeSince=Date.now();window.__nativeMusic=false;
      Android.radioPlay(JSON.stringify({i:qi,q:Q.map(function(x){return {n:x.name,u:x.url,k:x.key,c:x.cat||""}})}));
      return true;
    }catch(e){return false}
  };
  function quiet(){return window.__nativeSince&&Date.now()-window.__nativeSince<1500}
  function own(el){return Date.now()-(el._ig||0)<150}
  ra.addEventListener("pause",function(){ if(own(ra)||quiet()||!ra.srcObject)return; try{Android.radioPause()}catch(e){} });
  ra.addEventListener("play",function(){ if(own(ra)||quiet()||!ra.srcObject)return; try{Android.radioResume()}catch(e){} });
  try{var osv=setVol;setVol=function(){osv();try{if(window.__nativeMusic)Android.radioVolume(au.volume);else if(ra.srcObject)Android.radioVolume(ra.volume)}catch(e){}}}catch(e){}
  window.__sgsNative=function(m){
    try{
      if(m.fail){
        window.__nativeOff=Date.now()+120000;
        try{ra.srcObject=null;ra.muted=false}catch(e){}
        try{toast("Android player असफल — एपभित्रको तरिकाले बजाउँदैछु")}catch(e){}
        load();return;
      }
      var prevK=Q[qi]&&Q[qi].key;
      if(m.q){
        var map={};allStations().forEach(function(x){map[x.key]=x});
        var cur=m.q[m.idx],L=m.q.map(function(k){return map[k]}).filter(Boolean);
        if(L.length){Q=L.slice();var j=L.findIndex(function(x){return x.key===cur});qi=j<0?0:j}
      }else if(m.idx!=null&&Q[m.idx]){qi=m.idx}
      kind="r";stopped=false;window.__nativeMusic=false;
      try{au._ig=Date.now();au.pause();vd.pause()}catch(e){}
      info();
      if(prevK!==(Q[qi]&&Q[qi].key)){try{renderNA()}catch(e){}}
      if(m.playing){window.__nativeSilent()}
      else if(!ra.paused){ra._ig=Date.now();ra.pause()}
    }catch(e){}
  };
  try{
    var st=JSON.parse(Android.radioState());
    if(st.mode&&st.q&&st.q.length)window.__sgsNative(st);
  }catch(e){}
  /* ---- phone songs are played by the Android (native) player; this page mirrors it ---- */
  window.__nativeSilentAu=function(){
    try{
      if(!SIL)window.__nativeSilent();
      if(SIL&&SIL.c.state==="suspended")SIL.c.resume();
      if(au.srcObject!==SIL.s)au.srcObject=SIL.s;au.muted=true;au._ig=Date.now();
      return Promise.resolve(au.play()).catch(function(){});
    }catch(e){return Promise.resolve()}
  };
  window.__nativeMusicOn=function(t){
    try{
      if(localStorage.getItem("sgs-nm")==="0")return false;
      if(Date.now()<(window.__nativeOffM||0))return false;
      if(!Android.musicPlay)return false;
      var ids=[];
      for(var i=0;i<Q.length;i++){var k=Q[i].key;if(typeof k==="string"&&k.indexOf("ms:a")===0)ids.push(+k.slice(4));else return false}
      if(!ids.length)return false;
      var sig=ids.length+":"+ids[0]+":"+ids[ids.length-1],msg={i:qi,sig:sig};
      if(sig!==window.__asig){msg.ids=ids;window.__asig=sig}
      window.__nativeSince=Date.now();window.__nativeMusic=true;window.__apos=0;window.__adur=(t.dur||0);window.__aat=performance.now();
      Android.musicPlay(JSON.stringify(msg));
      return true;
    }catch(e){return false}
  };
  (function(){
    var P=HTMLMediaElement.prototype,dc=Object.getOwnPropertyDescriptor(P,"currentTime"),dd=Object.getOwnPropertyDescriptor(P,"duration");
    Object.defineProperty(au,"currentTime",{configurable:true,
      get:function(){if(window.__nativeMusic){var p=window.__apos||0;if(!au.paused)p+=performance.now()-(window.__aat||0);return p/1000}return dc.get.call(au)},
      set:function(v){if(window.__nativeMusic){window.__apos=v*1000;window.__aat=performance.now();try{Android.musicSeek(Math.floor(v*1000))}catch(e){}}else dc.set.call(au,v)}});
    Object.defineProperty(au,"duration",{configurable:true,
      get:function(){if(window.__nativeMusic){var d=(window.__adur||0)/1000;return d>0?d:NaN}return dd.get.call(au)}});
  })();
  window.__sgsPos=function(p,d,pl){window.__apos=p;window.__aat=performance.now();if(d>0)window.__adur=d};
  au.addEventListener("pause",function(){ if(own(au)||quiet()||!au.srcObject||!window.__nativeMusic)return; try{Android.musicPause()}catch(e){} });
  au.addEventListener("play",function(){ if(own(au)||quiet()||!au.srcObject||!window.__nativeMusic)return; try{Android.musicResume()}catch(e){} });
  try{var oan=autoNext;autoNext=function(){if(window.__nativeMusic)return;return oan.apply(this,arguments)}}catch(e){}
  window.__sgsNativeM=function(m){
    try{
      if(m.fail){
        window.__nativeOffM=Date.now()+120000;window.__nativeMusic=false;window.__asig="";
        try{au.srcObject=null;au.muted=false}catch(e){}
        try{toast("Android player असफल — एपभित्रको तरिकाले बजाउँदैछु")}catch(e){}
        load();return;
      }
      window.__nativeMusic=true;
      var ck="ms:a"+m.cid,changed=!(Q[qi]&&Q[qi].key===ck);
      if(m.q){
        var map={};lib.a.forEach(function(x){map[x.key]=x});
        var L=m.q.map(function(id){return map["ms:a"+id]}).filter(Boolean);
        if(L.length){Q=L.slice()}
      }
      var j=Q.findIndex(function(x){return x.key===ck});
      if(j<0){Q=lib.a.slice();j=Q.findIndex(function(x){return x.key===ck})}
      if(j>=0)qi=j;
      kind="a";stopped=false;
      window.__adur=m.dur||window.__adur||0;
      if(m.pos!=null){window.__apos=m.pos;window.__aat=performance.now()}
      try{ra._ig=Date.now();ra.pause()}catch(e){}
      info();
      if(changed){
        clearTimeout(window._rdt);window._rdt=setTimeout(function(){try{renderDev()}catch(e){}},350);
        try{npLoad()}catch(e){}
      }
      if(m.playing){window.__nativeSilentAu()}
      else if(!au.paused){au._ig=Date.now();au.pause()}
    }catch(e){}
  };
  window.__toggleNM=function(b){
    var off=localStorage.getItem("sgs-nm")==="0";
    localStorage.setItem("sgs-nm",off?"1":"0");
    b.textContent="Android player (फोनका गीत): "+(off?"चालु":"बन्द")+" — थिचेर बदल्नुहोस्";
    try{toast(off?"चालु भयो":"बन्द भयो (अर्को गीतदेखि लागू)")}catch(e){}
  };
  setInterval(function(){try{Android.musicFlags(!!shuf,(rep|0),!!(T&&T.eot))}catch(e){}},1500);
  /* ---- real Android alarms ---- */
  /* The native Android service now rings alarms; switch off the old browser timer check. */
  try{alCheck=function(){}}catch(x){}
  var lastAl="";
  function pushAl(){try{var s=JSON.stringify(CFG.al);if(s===lastAl)return;lastAl=s;Android.setAlarms(s)}catch(x){}}
  try{
    var po=JSON.parse(Android.consumePendingOff()||"[]");
    if(po.length){CFG.al.forEach(function(a){if(po.indexOf(a.id)>=0)a.on=false});save();}
  }catch(x){}
  pushAl();
  try{document.getElementById("snz").addEventListener("click",function(){try{if(ringing)Android.snooze(String(ringing.id))}catch(x){}},true)}catch(x){}
  window.__sgsRing=function(id,snz){
    try{
      var a=CFG.al.find(function(x){return x.id==id});
      var dk=new Date().toDateString();
      if(!a||ringing||(!snz&&a.last===dk+a.time)){Android.alarmHandled();return}
      a.last=dk+a.time;snoozeAt=0;
      if(!a.days.length&&!snz)a.on=false;
      save();
      Promise.resolve(ring(a)).then(function(){Android.alarmHandled()},function(){Android.alarmHandled()});
      try{if($("#als").classList.contains("on"))alRender()}catch(x){}
    }catch(x){try{Android.alarmHandled()}catch(y){}}
  };
  var lastFv="";
  function pushFav(){
    try{
      var f=allStations().filter(function(x){return CFG.fav.r.indexOf(x.key)>=0}).map(function(x){return {k:x.key,n:x.name,c:x.cat||""}});
      var s=JSON.stringify(f);if(s===lastFv)return;lastFv=s;Android.setFavs(s);
    }catch(x){}
  }
  pushFav();
  setInterval(pushFav,6000);
  window.__sgsReady=true;
  setInterval(function(){push();pushAl()},3000);
})();
