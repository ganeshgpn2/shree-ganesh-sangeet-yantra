(function(){
  if(window.__sgsBridge)return; window.__sgsBridge=1;
  var last="";
  function push(){
    try{
      var playing=false;
      try{var e=E();playing=!e.paused;}catch(x){}
      if(!playing){try{playing=!vd.paused}catch(x){}}
      var t=(typeof Q!=="undefined"&&Q[qi])?Q[qi]:null;
      var title=t?t.name:"Shree Ganesh Sangeet Yantra";
      var sub=t?(kind=="r"?"Radio · "+(t.cat||"Live"):((t.folder||[]).slice(-1)[0]||"")):"";
      var key=title+"|"+sub+"|"+playing;
      if(key===last)return; last=key;
      Android.update(String(title),String(sub),!!playing);
    }catch(x){}
  }
  try{
    [au,ra,vd].forEach(function(a){
      ["play","pause","playing","ended","emptied"].forEach(function(ev){
        a.addEventListener(ev,function(){setTimeout(push,80)});
      });
    });
    var oi=info; info=function(){var r=oi.apply(this,arguments);setTimeout(push,80);return r};
  }catch(x){}
  setInterval(push,3000);
})();
