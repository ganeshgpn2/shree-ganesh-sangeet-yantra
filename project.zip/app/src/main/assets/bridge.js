(function(){
  if(window.__sgsBridge)return; window.__sgsBridge=1;
  var last="";
  function push(force){
    try{
      var playing=false;
      try{var e=E();playing=!e.paused;}catch(x){}
      if(!playing){try{playing=!vd.paused}catch(x){}}
      var t=(typeof Q!=="undefined"&&Q[qi])?Q[qi]:null;
      var title=t?t.name:"Shree Ganesh Sangeet Yantra";
      var sub=t?(kind=="r"?"Radio · "+(t.cat||"Live"):((t.folder||[]).slice(-1)[0]||"")):"";
      var tk=t&&t.key?t.key:"";
      var key=title+"|"+sub+"|"+playing+"|"+kind+"|"+tk;
      if(key===last&&!force)return; last=key;
      var pos=0,dur=0;
      try{var ee=E();pos=Math.floor((ee.currentTime||0)*1000);dur=isFinite(ee.duration)?Math.floor(ee.duration*1000):0}catch(x){}
      Android.update(String(title),String(sub),!!playing);
      try{Android.state(JSON.stringify({t:String(title),s:String(sub),p:!!playing,k:(typeof kind!=="undefined"?kind:""),key:String(tk),pos:pos,dur:dur}))}catch(x){}
    }catch(x){}
  }
  try{
    [au,ra,vd].forEach(function(a){
      ["play","pause","playing","ended","emptied","seeked"].forEach(function(ev){
        a.addEventListener(ev,function(){setTimeout(function(){push(true)},80)});
      });
    });
    var oi=info; info=function(){var r=oi.apply(this,arguments);setTimeout(push,80);return r};
  }catch(x){}
  /* remember radio streams that really played on this phone (used as alarm backups) */
  try{ra.addEventListener("playing",function(){try{if(ra.src&&ra.src.indexOf("http")===0)Android.radioOk(ra.src)}catch(x){}})}catch(x){}
  /* ---- phone music/video library from Android MediaStore ---- */
  try{au.crossOrigin="anonymous";vd.crossOrigin="anonymous"}catch(x){}
  window.__sgsScan=function(){
    try{
      var j=JSON.parse(Android.scanMedia());
      var mk=function(k){return function(r){return {name:r.n,ext:(r.e||"").toLowerCase(),folder:r.f,key:"ms:"+k+r.id,src:"ms",k:k,murl:"https://sgs.media/"+k+"/"+r.id,dur:r.d,album:r.al||""}}};
      var A=j.a.map(mk("a")),V=j.v.map(mk("v"));
      var cmp=function(x,y){return x.name.localeCompare(y.name,"ne")};
      A.sort(cmp);V.sort(cmp);
      lib={a:A,v:V,l:{}};
      j.a.forEach(function(r){if(r.s)artMap["ms:a"+r.id]=r.s});
      try{lw("sgs-art",artMap)}catch(x){}
      needPerm=false;
      var all=A.concat(V),nf={};all.forEach(function(x){nf[x.folder.join("/")]=1});
      dstat(A.length+" गीत · "+V.length+" भिडियो · "+Object.keys(nf).length+" फोल्डर");
      renderDev();
      window.__sgsLastScan=Date.now();
    }catch(x){try{toast("स्क्यान असफल: "+x)}catch(y){}}
  };
  window.__sgsScanRequest=function(){
    try{ if(Android.hasMediaPerm())window.__sgsScan(); else Android.requestMediaPerm(); }catch(x){}
  };
  window.__sgsScanSoon=function(){
    try{ if(Android.hasMediaPerm()&&(!window.__sgsLastScan||Date.now()-window.__sgsLastScan>30000))window.__sgsScan(); }catch(x){}
  };
  try{
    rescan=function(){window.__sgsScanRequest();return Promise.resolve()};
    addDir=function(){window.__sgsScanRequest()};
    askPerm=function(){window.__sgsScanRequest();return Promise.resolve()};
    indexArtists=function(){return Promise.resolve()};
    var oact=act;
    act=function(a){ if(a==="files"){window.__sgsScanRequest();return} return oact(a) };
  }catch(x){}
  try{ if(Android.hasMediaPerm())window.__sgsScan(); }catch(x){}
  /* ---- real Android alarms ---- */
  /* The native Android service now rings alarms; switch off the old browser timer check. */
  try{alCheck=function(){}}catch(x){}
  var lastAl="";
  function pushAl(){try{var s=JSON.stringify(CFG.al);if(s===lastAl)return;lastAl=s;Android.setAlarms(s)}catch(x){}}
  try{
    var po=JSON.parse(Android.consumePendingOff()||"[]");
    if(po.length){CFG.al.forEach(function(a){if(po.indexOf(a.id)>=0)a.on=false});save();}
  }catch(x){}
  pushAl();
  try{document.getElementById("snz").addEventListener("click",function(){try{if(ringing)Android.snooze(String(ringing.id))}catch(x){}},true)}catch(x){}
  window.__sgsRing=function(id,snz){
    try{
      var a=CFG.al.find(function(x){return x.id==id});
      var dk=new Date().toDateString();
      if(!a||ringing||(!snz&&a.last===dk+a.time)){Android.alarmHandled();return}
      a.last=dk+a.time;snoozeAt=0;
      if(!a.days.length&&!snz)a.on=false;
      save();
      Promise.resolve(ring(a)).then(function(){Android.alarmHandled()},function(){Android.alarmHandled()});
      try{if($("#als").classList.contains("on"))alRender()}catch(x){}
    }catch(x){try{Android.alarmHandled()}catch(y){}}
  };
  var lastFv="";
  function pushFav(){
    try{
      var f=allStations().filter(function(x){return CFG.fav.r.indexOf(x.key)>=0}).map(function(x){return {k:x.key,n:x.name,c:x.cat||""}});
      var s=JSON.stringify(f);if(s===lastFv)return;lastFv=s;Android.setFavs(s);
    }catch(x){}
  }
  pushFav();
  setInterval(pushFav,6000);
  window.__sgsReady=true;
  setInterval(function(){push();pushAl()},3000);
})();
