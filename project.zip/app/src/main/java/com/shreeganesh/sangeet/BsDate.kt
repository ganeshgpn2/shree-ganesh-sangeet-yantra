package com.shreeganesh.sangeet

import java.time.LocalDate
import java.time.temporal.ChronoUnit

/** Bikram Sambat date text (same table as the HTML app: 2080-2084 BS). */
object BsDate {
    private val M = arrayOf("बैशाख", "जेठ", "असार", "श्रावण", "भाद्र", "आश्विन", "कार्तिक", "मङ्सिर", "पौष", "माघ", "फाल्गुन", "चैत्र")
    private val W = arrayOf("आइतबार", "सोमबार", "मङ्गलबार", "बुधबार", "बिहीबार", "शुक्रबार", "शनिबार")
    private val Y = mapOf(
        2080 to intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 30),
        2081 to intArrayOf(31, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31),
        2082 to intArrayOf(31, 31, 31, 32, 31, 31, 30, 29, 30, 29, 30, 30),
        2083 to intArrayOf(31, 31, 32, 31, 31, 31, 30, 30, 29, 30, 30, 30),
        2084 to intArrayOf(31, 31, 32, 31, 31, 30, 30, 30, 29, 30, 30, 30)
    )

    fun weekdayName(d: LocalDate) = W[d.dayOfWeek.value % 7]

    /** [year, month(1-12), day] in Bikram Sambat, or null if outside the table. */
    fun ymd(today: LocalDate = LocalDate.now()): IntArray? {
        var n = ChronoUnit.DAYS.between(LocalDate.of(2023, 4, 14), today)
        if (n < 0) return null
        for (y in 2080..2084) {
            val m = Y[y] ?: continue
            for (i in 0 until 12) {
                if (n < m[i]) return intArrayOf(y, i + 1, (n + 1).toInt())
                n -= m[i]
            }
        }
        return null
    }

    private fun np(n: Int): String = n.toString().map { "०१२३४५६७८९"[it - '0'] }.joinToString("")

    fun text(today: LocalDate = LocalDate.now()): String {
        var n = ChronoUnit.DAYS.between(LocalDate.of(2023, 4, 14), today)
        if (n < 0) return weekdayName(today)
        for (y in 2080..2084) {
            val m = Y[y] ?: continue
            for (i in 0 until 12) {
                if (n < m[i]) return np(y) + " " + M[i] + " " + np((n + 1).toInt()) + ", " + weekdayName(today)
                n -= m[i]
            }
        }
        return weekdayName(today)
    }
}
