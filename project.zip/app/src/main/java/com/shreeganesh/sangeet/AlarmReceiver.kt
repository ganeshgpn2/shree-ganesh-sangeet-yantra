package com.shreeganesh.sangeet

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != AlarmScheduler.A_FIRE) return
        val raw = intent.getStringExtra("id") ?: return
        val snooze = raw.startsWith(AlarmScheduler.SNZ)
        val id = raw.removePrefix(AlarmScheduler.SNZ)
        val a = AlarmScheduler.find(ctx, id) ?: return
        if (!snooze && !a.optBoolean("on", false)) return
        val days = a.optJSONArray("days")
        if (!snooze && (days == null || days.length() == 0)) AlarmScheduler.markOff(ctx, id)
        AlarmScheduler.scheduleAll(ctx)
        val i = Intent(ctx, AlarmService::class.java).setAction(AlarmService.A_RING)
            .putExtra("id", id).putExtra("snz", snooze)
        try { ctx.startForegroundService(i) } catch (e: Exception) { }
    }
}
