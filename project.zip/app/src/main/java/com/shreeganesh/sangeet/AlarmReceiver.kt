package com.shreeganesh.sangeet

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.widget.Toast

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != AlarmScheduler.A_FIRE) return
        val raw = intent.getStringExtra("id") ?: return
        AlarmScheduler.appendLog(ctx, "FIRE received id=" + raw)
        val snooze = raw.startsWith(AlarmScheduler.SNZ)
        val id = raw.removePrefix(AlarmScheduler.SNZ)
        val a = AlarmScheduler.find(ctx, id)
        if (a == null) { Toast.makeText(ctx, "Alarm: record not found", Toast.LENGTH_LONG).show(); return }
        if (!snooze && !a.optBoolean("on", false)) return
        val days = a.optJSONArray("days")
        if (!snooze && (days == null || days.length() == 0)) AlarmScheduler.markOff(ctx, id)
        AlarmScheduler.scheduleAll(ctx)
        Toast.makeText(ctx, "⏰ Alarm " + a.optString("time"), Toast.LENGTH_LONG).show()
        val i = Intent(ctx, AlarmService::class.java).setAction(AlarmService.A_RING)
            .putExtra("id", id).putExtra("snz", snooze)
        try {
            ctx.startForegroundService(i)
        } catch (e: Exception) {
            AlarmScheduler.appendLog(ctx, "service start error: " + e.javaClass.simpleName + " " + e.message)
            Toast.makeText(ctx, "Alarm service error: " + e.javaClass.simpleName, Toast.LENGTH_LONG).show()
            fallback(ctx, id, a.optString("label").ifEmpty { "Alarm" }, a.optString("time"))
        }
    }

    /** If Android refuses to start the playback service, at least ring with a loud notification. */
    private fun fallback(ctx: Context, id: String, title: String, text: String) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        val ch = NotificationChannel("sgs_alarm_fallback", "Alarm (fallback)", NotificationManager.IMPORTANCE_HIGH)
        ch.setSound(sound, AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
        nm.createNotificationChannel(ch)
        val open = PendingIntent.getActivity(
            ctx, 101,
            Intent(ctx, MainActivity::class.java).putExtra("alarm_native", id)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, "sgs_alarm_fallback")
            .setSmallIcon(R.drawable.ic_notif).setContentTitle(title).setContentText(text)
            .setCategory(Notification.CATEGORY_ALARM).setContentIntent(open)
            .setFullScreenIntent(open, true).setAutoCancel(true).build()
        nm.notify(3, n)
    }
}
