package com.shreeganesh.sangeet

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

/**
 * Drop-down list opened by tapping the song / station name on the cassette widget.
 * Shows the phone songs and the radio stations (favourites first); a tap plays the chosen one
 * through the existing PlaybackService (same commands the widget buttons already use).
 */
class WidgetPickerActivity : Activity() {

    private class Item(val title: String, val sub: String, val radio: Boolean, val key: String, val fav: Boolean)

    private val songs = ArrayList<Item>()
    private val radios = ArrayList<Item>()
    private val shown = ArrayList<Item>()
    private var tab = 0
    private var query = ""
    private var loaded = false

    private lateinit var panel: LinearLayout
    private lateinit var listView: ListView
    private lateinit var empty: TextView
    private lateinit var tabSong: TextView
    private lateinit var tabRadio: TextView
    private lateinit var adapter: BaseAdapter

    private val gold = Color.parseColor("#F2B705")
    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        tab = if (WidgetState.kind(this) == "r") 1 else 0
        buildUi()
        Thread {
            val s = loadSongs()
            val r = loadRadios()
            runOnUiThread {
                songs.addAll(s); radios.addAll(r); loaded = true
                refresh()
                val i = shown.indexOfFirst { isCurrent(it) }
                if (i > 1) listView.setSelection(i - 1)
            }
        }.start()
    }

    // ------------------------------------------------------------------ data
    private fun loadSongs(): List<Item> {
        val out = ArrayList<Pair<String, Item>>()
        try {
            contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.ARTIST),
                "is_ringtone=0 AND is_alarm=0 AND is_notification=0", null, null
            )?.use { cur ->
                while (cur.moveToNext()) {
                    val id = cur.getLong(0)
                    val dn = cur.getString(1) ?: ""
                    val ar = cur.getString(2)?.takeIf { it != "<unknown>" } ?: ""
                    out.add(Pair(dn.lowercase(), Item(dn.substringBeforeLast('.', dn), ar, false, "ms:a$id", false)))
                }
            }
        } catch (e: Exception) { }
        out.sortBy { it.first }          // same order as the playback queue (by file name)
        return out.map { it.second }
    }

    private fun loadRadios(): List<Item> {
        val out = ArrayList<Item>()
        val seen = HashSet<String>()
        for (f in WidgetState.favs(this)) {                       // favourites first
            if (f.key.startsWith("http") && seen.add(f.key)) {
                val fr = WidgetState.freqOf(this, f.key)
                out.add(Item(f.name, (if (fr.isNotEmpty()) "FM $fr MHz" else "FM") + (if (f.cat.isNotEmpty()) " · " + f.cat else ""), true, f.key, true))
            }
        }
        try {
            val txt = assets.open("database.json").bufferedReader().use { it.readText() }
            val a = JSONObject(txt).getJSONArray("radios")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val url = o.optString("Stream URL")
                val name = o.optString("Name")
                if (!url.startsWith("http") || name.isEmpty() || !seen.add(url)) continue
                val fq = o.optDouble("Frequency (MHz)", 0.0)
                val prov = o.optString("Province")
                out.add(Item(name, (if (fq > 0) String.format("FM %.1f MHz", fq) else "FM") + (if (prov.isNotEmpty() && prov != "null") " · $prov" else ""), true, url, false))
            }
        } catch (e: Exception) { }
        return out
    }

    private fun isCurrent(it: Item): Boolean {
        val kind = WidgetState.kind(this)
        if (WidgetState.title(this).isEmpty()) return false
        return if (it.radio) kind == "r" && WidgetState.key(this) == it.key
        else kind != "r" && (WidgetState.key(this) == it.key || WidgetState.devKey(this) == it.key)
    }

    // ------------------------------------------------------------------ actions
    private fun play(it: Item) {
        if (it.radio) {
            PlaybackService.radioCmd(
                this, PlaybackService.A_R_PLAYONE,
                JSONObject().put("n", it.title).put("u", it.key).put("k", it.key).toString()
            )
        } else {
            PlaybackService.musicCmd(this, PlaybackService.A_M_PLAYKEY, key = it.key)
        }
        Toast.makeText(this, "▶ " + it.title, Toast.LENGTH_SHORT).show()
        finish()
        overridePendingTransition(0, 0)
    }

    private fun close() {
        panel.animate().alpha(0f).translationY(-dp(50).toFloat()).setDuration(150)
            .withEndAction { finish(); overridePendingTransition(0, 0) }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { close() }

    private fun refresh() {
        val src = if (tab == 0) songs else radios
        val q = query.trim().lowercase()
        shown.clear()
        for (i in src) if (q.isEmpty() || i.title.lowercase().contains(q) || i.sub.lowercase().contains(q)) shown.add(i)
        adapter.notifyDataSetChanged()
        empty.visibility = if (loaded && shown.isEmpty()) View.VISIBLE else View.GONE
        empty.text = if (!loaded) "" else if (q.isNotEmpty()) "कुनै नतिजा भेटिएन"
        else if (tab == 0) "फोनमा गीत भेटिएन।\nएप खोलेर संगीत स्क्यान गर्नुहोस्।" else "रेडियो भेटिएन"
        styleTab(tabSong, tab == 0); styleTab(tabRadio, tab == 1)
    }

    private fun styleTab(t: TextView, on: Boolean) {
        t.background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            if (on) setColor(gold) else { setColor(Color.parseColor("#22FFFFFF")); setStroke(dp(1), Color.parseColor("#66F2B705")) }
        }
        t.setTextColor(if (on) Color.parseColor("#0B1640") else Color.WHITE)
    }

    // ------------------------------------------------------------------ UI (built in code, no layout file)
    private fun buildUi() {
        val dm = resources.displayMetrics
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#99000000"))
        root.setOnClickListener { close() }

        panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.isClickable = true
        panel.setPadding(dp(12), dp(10), dp(12), dp(10))
        panel.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.parseColor("#1D3CA6"), Color.parseColor("#07123D"))).apply {
            cornerRadius = dp(20).toFloat(); setStroke(dp(2), gold)
        }
        val w = minOf((dm.widthPixels * 0.94f).toInt(), dp(440))
        val h = (dm.heightPixels * 0.72f).toInt()
        root.addView(panel, FrameLayout.LayoutParams(w, h, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(44) })

        // header
        val head = LinearLayout(this); head.orientation = LinearLayout.HORIZONTAL; head.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(this); title.text = "♫  गीत / रेडियो छान्नुहोस्"; title.setTextColor(gold); title.textSize = 16f; title.setTypeface(null, Typeface.BOLD)
        head.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val x = TextView(this); x.text = "✕"; x.setTextColor(Color.WHITE); x.textSize = 18f; x.gravity = Gravity.CENTER; x.setPadding(dp(10), dp(2), dp(4), dp(2))
        x.setOnClickListener { close() }
        head.addView(x)
        panel.addView(head)

        val now = TextView(this)
        val t = WidgetState.title(this)
        now.text = if (t.isEmpty()) "अहिले केही बजिरहेको छैन" else (if (WidgetState.playing(this)) "▶ अहिले: " else "⏸ अहिले: ") + t
        now.setTextColor(Color.parseColor("#B9C6F5")); now.textSize = 12f; now.setSingleLine(true); now.ellipsize = TextUtils.TruncateAt.END
        now.setPadding(0, dp(2), 0, dp(8))
        panel.addView(now)

        // tabs
        val tabs = LinearLayout(this); tabs.orientation = LinearLayout.HORIZONTAL
        tabSong = TextView(this); tabSong.text = "♪  फोनका गीत"
        tabRadio = TextView(this); tabRadio.text = "📻  रेडियो"
        for ((i, tv) in listOf(tabSong, tabRadio).withIndex()) {
            tv.gravity = Gravity.CENTER; tv.textSize = 14f; tv.setTypeface(null, Typeface.BOLD); tv.setPadding(0, dp(9), 0, dp(9))
            tv.setOnClickListener { tab = i; refresh(); listView.setSelection(0) }
            tabs.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i == 0) rightMargin = dp(6) else leftMargin = dp(6) })
        }
        panel.addView(tabs)

        // search
        val search = EditText(this)
        search.hint = "खोज्नुहोस्…"; search.setHintTextColor(Color.parseColor("#99FFFFFF")); search.setTextColor(Color.WHITE); search.textSize = 14f
        search.setSingleLine(true); search.setPadding(dp(14), dp(8), dp(14), dp(8))
        search.background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(Color.parseColor("#22FFFFFF")) }
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { query = s?.toString() ?: ""; refresh() }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        panel.addView(search, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8); bottomMargin = dp(6) })

        // list
        adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(p: Int): Any = shown[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
                val row: LinearLayout; val a: TextView; val b: TextView
                if (cv == null) {
                    row = LinearLayout(this@WidgetPickerActivity); row.orientation = LinearLayout.VERTICAL; row.setPadding(dp(10), dp(9), dp(10), dp(9))
                    a = TextView(this@WidgetPickerActivity); a.textSize = 15f; a.setTypeface(null, Typeface.BOLD); a.setSingleLine(true); a.ellipsize = TextUtils.TruncateAt.END
                    b = TextView(this@WidgetPickerActivity); b.textSize = 11f; b.setSingleLine(true); b.ellipsize = TextUtils.TruncateAt.END
                    row.addView(a); row.addView(b); row.tag = arrayOf(a, b)
                } else {
                    row = cv as LinearLayout
                    @Suppress("UNCHECKED_CAST") val ab = row.tag as Array<TextView>
                    a = ab[0]; b = ab[1]
                }
                val it = shown[p]; val cur = isCurrent(it)
                a.text = (if (cur) "▶ " else if (it.fav) "★ " else "") + it.title
                a.setTextColor(if (cur) gold else Color.WHITE)
                b.text = it.sub; b.setTextColor(Color.parseColor("#9FB0E8")); b.visibility = if (it.sub.isEmpty()) View.GONE else View.VISIBLE
                row.setBackgroundColor(if (cur) Color.parseColor("#33F2B705") else Color.TRANSPARENT)
                return row
            }
        }
        listView = ListView(this)
        listView.adapter = adapter
        listView.divider = ColorDrawable(Color.parseColor("#22FFFFFF")); listView.dividerHeight = 1
        listView.setOnItemClickListener { _, _, pos, _ -> if (pos in 0 until shown.size) play(shown[pos]) }
        empty = TextView(this); empty.setTextColor(Color.parseColor("#B9C6F5")); empty.textSize = 14f; empty.gravity = Gravity.CENTER; empty.visibility = View.GONE
        val box = FrameLayout(this)
        box.addView(listView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        box.addView(empty, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        panel.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // open the full app
        val open = TextView(this); open.text = "📱  एप खोल्नुहोस्"; open.setTextColor(gold); open.textSize = 13f; open.gravity = Gravity.CENTER; open.setPadding(0, dp(10), 0, dp(2))
        open.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
            finish(); overridePendingTransition(0, 0)
        }
        panel.addView(open)

        setContentView(root)
        refresh()
        // drop-down: slides down from the top while fading in
        panel.alpha = 0f; panel.translationY = -dp(60).toFloat()
        panel.animate().alpha(1f).translationY(0f).setDuration(220).setInterpolator(DecelerateInterpolator()).start()
    }
}
