package com.shreeganesh.sangeet

import android.content.Context
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject

/** Small storage shared by the app and the Home Screen widgets (survives app and phone restart). */
object WidgetState {
    data class Fav(val key: String, val name: String, val cat: String)

    private fun p(c: Context) = c.getSharedPreferences("sgs_widget", Context.MODE_PRIVATE)

    fun saveState(c: Context, json: String) {
        try {
            val o = JSONObject(json)
            val e = p(c).edit()
                .putString("title", o.optString("t"))
                .putString("sub", o.optString("s"))
                .putBoolean("playing", o.optBoolean("p"))
                .putString("kind", o.optString("k"))
                .putString("key", o.optString("key"))
                .putLong("pos", o.optLong("pos", 0))
                .putLong("dur", o.optLong("dur", 0))
                .putLong("posAt", SystemClock.elapsedRealtime())
            if (o.optString("k") == "r" && o.optString("key").isNotEmpty()) e.putString("lastRadio", o.optString("key"))
            if (o.optString("k") == "a" && o.optString("key").isNotEmpty())
                e.putString("devKey", o.optString("key")).putString("devTitle", o.optString("t")).putString("devSub", o.optString("s"))
            e.apply()
        } catch (e: Exception) { }
    }

    fun setPlaying(c: Context, b: Boolean) {
        val e = p(c).edit()
        if (!b && playing(c)) { // freeze the shown time at the moment playback stopped
            e.putLong("pos", pos(c) + (SystemClock.elapsedRealtime() - posAt(c))).putLong("posAt", SystemClock.elapsedRealtime())
        }
        e.putBoolean("playing", b).apply()
    }
    fun pos(c: Context) = p(c).getLong("pos", 0)
    fun posAt(c: Context) = p(c).getLong("posAt", 0)
    fun dur(c: Context) = p(c).getLong("dur", 0)
    fun title(c: Context) = p(c).getString("title", "") ?: ""
    fun sub(c: Context) = p(c).getString("sub", "") ?: ""
    fun playing(c: Context) = p(c).getBoolean("playing", false)
    fun kind(c: Context) = p(c).getString("kind", "") ?: ""
    fun key(c: Context) = p(c).getString("key", "") ?: ""
    fun lastRadio(c: Context) = p(c).getString("lastRadio", "") ?: ""
    fun devKey(c: Context) = p(c).getString("devKey", "") ?: ""
    fun devTitle(c: Context) = p(c).getString("devTitle", "") ?: ""
    fun devSub(c: Context) = p(c).getString("devSub", "") ?: ""
    fun favIdx(c: Context) = p(c).getInt("favIdx", 0)
    fun setFavIdx(c: Context, i: Int) { p(c).edit().putInt("favIdx", i).apply() }

    fun saveFavs(c: Context, json: String) {
        try { JSONArray(json); p(c).edit().putString("favs", json).apply() } catch (e: Exception) { }
    }

    fun favs(c: Context): List<Fav> {
        val out = ArrayList<Fav>()
        try {
            val a = JSONArray(p(c).getString("favs", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Fav(o.optString("k"), o.optString("n"), o.optString("c")))
            }
        } catch (e: Exception) { }
        return out
    }

    private var freq: HashMap<String, String>? = null

    /** Frequency (MHz) from the imported Excel database, when known. */
    fun freqOf(c: Context, key: String): String {
        if (freq == null) {
            val m = HashMap<String, String>()
            try {
                val txt = c.assets.open("database.json").bufferedReader().use { it.readText() }
                val a = JSONObject(txt).getJSONArray("radios")
                for (i in 0 until a.length()) {
                    val r = a.getJSONObject(i)
                    val f = r.optString("Frequency (MHz)", "")
                    if (f.isNotEmpty() && f != "null") {
                        m[r.optString("Key")] = f
                        val u = r.optString("Stream URL", "")
                        if (u.startsWith("http")) m[u.trim()] = f
                        r.optString("Alternate URLs", "").split(";", ",", " ", "\n")
                            .map { it.trim() }.filter { it.startsWith("http") }.forEach { m[it] = f }
                    }
                }
            } catch (e: Exception) { }
            freq = m
        }
        return freq!![key] ?: ""
    }
}
