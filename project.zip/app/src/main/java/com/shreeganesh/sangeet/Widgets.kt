package com.shreeganesh.sangeet

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Bundle

class MusicWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { WidgetState.reconcile(c); WidgetUpdater.updateAll(c) }
}

class FavWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { WidgetState.reconcile(c); WidgetUpdater.updateAll(c) }
}

class ClockWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        WidgetState.reconcile(c); WidgetUpdater.updateAll(c); WidgetUpdater.scheduleMidnight(c)
    }
    override fun onEnabled(c: Context) { WidgetUpdater.scheduleMidnight(c) }
    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        when (i.action) {
            WidgetUpdater.A_TICK, Intent.ACTION_DATE_CHANGED, Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED -> {
                WidgetUpdater.updateAll(c); WidgetUpdater.scheduleMidnight(c)
            }
        }
    }
}

class CassetteWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        WidgetState.reconcile(c); WidgetUpdater.updateAll(c); WidgetUpdater.scheduleMidnight(c)
    }
    /** Called when the user resizes the widget: redraw so the layout re-fits the new size. */
    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, opts: Bundle) {
        WidgetUpdater.updateAll(c)
    }
    override fun onEnabled(c: Context) { WidgetUpdater.scheduleMidnight(c) }
}
