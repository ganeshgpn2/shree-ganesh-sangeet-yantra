package com.shreeganesh.sangeet

import android.content.Context

/** App भाषा: पूर्वनिर्धारित English; Settings → Language बाट नेपाली छान्न सकिन्छ (JS ले setLang() बाट यहाँ लेख्छ)। */
object Lang {
    private const val P = "sgs_lang"
    fun isEn(c: Context): Boolean = c.getSharedPreferences(P, Context.MODE_PRIVATE).getString("l", "en") != "ne"
    fun set(c: Context, l: String) { c.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putString("l", if (l == "ne") "ne" else "en").apply() }
    fun t(c: Context, ne: String, en: String): String = if (isEn(c)) en else ne
}
