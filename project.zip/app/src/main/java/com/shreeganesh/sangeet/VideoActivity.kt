package com.shreeganesh.sangeet

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.VideoSize
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory

/**
 * एपभित्रको video player (ExoPlayer): WebView ले नचलाउने ढाँचा (MKV, HEVC/H.265, MPEG-TS, FLV, 3GP, DASH, HLS ...) यहाँ चल्छ।
 * Decoder नमिले अर्को (software) decoder मा आफैँ सर्छ (decoder fallback)।
 * Extras: url (https://sgs.media/v/<id> वा http(s)/content URL), title, start (ms)
 */
class VideoActivity : Activity() {

    private var player: ExoPlayer? = null
    private lateinit var box: FrameLayout
    private lateinit var surface: SurfaceView
    private lateinit var ctl: LinearLayout
    private lateinit var top: LinearLayout
    private lateinit var err: TextView
    private lateinit var errBtn: TextView
    private lateinit var seek: SeekBar
    private lateinit var cur: TextView
    private lateinit var dur: TextView
    private lateinit var bPlay: TextView
    private lateinit var bSpeed: TextView
    private val h = Handler(Looper.getMainLooper())
    private var uri: Uri = Uri.EMPTY
    private var key = ""
    private var vw = 0f
    private var vh = 0f
    private var fill = false
    private var dragging = false
    private var speedI = 1
    private val speeds = floatArrayOf(0.75f, 1f, 1.25f, 1.5f, 2f)
    private val prefs by lazy { getSharedPreferences("sgs_vpos", Context.MODE_PRIVATE) }

    private val hideRun = Runnable { showCtl(false) }
    private val tick = object : Runnable {
        override fun run() {
            val p = player ?: return
            if (!dragging) {
                val d = p.duration
                if (d > 0 && d != C.TIME_UNSET) seek.progress = (p.currentPosition * 1000 / d).toInt()
                cur.text = fmt(p.currentPosition)
                dur.text = if (d > 0 && d != C.TIME_UNSET) fmt(d) else "--:--"
            }
            h.postDelayed(this, 500)
        }
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return if (s >= 3600) String.format("%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60) else String.format("%02d:%02d", s / 60, s % 60)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val raw = intent.getStringExtra("url") ?: ""
        val title = intent.getStringExtra("title") ?: ""
        uri = resolve(raw)
        key = raw

        box = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        surface = SurfaceView(this)
        box.addView(surface, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))

        // top bar
        top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(Color.parseColor("#99000000")); setPadding(dp(6), dp(6), dp(6), dp(6)) }
        top.addView(btn("←", 22) { finish() }, LinearLayout.LayoutParams(dp(48), dp(44)))
        top.addView(TextView(this).apply { text = title; setTextColor(Color.WHITE); textSize = 15f; setSingleLine(true); ellipsize = android.text.TextUtils.TruncateAt.END },
            LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(btn("🔊", 18) { pickTrack(C.TRACK_TYPE_AUDIO) }, LinearLayout.LayoutParams(dp(48), dp(44)))
        box.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        // bottom controls
        ctl = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#99000000")); setPadding(dp(10), dp(6), dp(10), dp(10)) }
        val sr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        cur = TextView(this).apply { text = "00:00"; setTextColor(Color.WHITE); textSize = 12f }
        dur = TextView(this).apply { text = "--:--"; setTextColor(Color.WHITE); textSize = 12f }
        seek = SeekBar(this).apply {
            max = 1000
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, user: Boolean) {
                    if (user) { val dd = player?.duration ?: 0L; if (dd > 0) cur.text = fmt(dd * p / 1000) }
                }
                override fun onStartTrackingTouch(s: SeekBar) { dragging = true; h.removeCallbacks(hideRun) }
                override fun onStopTrackingTouch(s: SeekBar) {
                    val dd = player?.duration ?: 0L
                    if (dd > 0) player?.seekTo(dd * s.progress / 1000)
                    dragging = false; showCtl(true)
                }
            })
        }
        sr.addView(cur); sr.addView(seek, LinearLayout.LayoutParams(0, -2, 1f)); sr.addView(dur)
        ctl.addView(sr, LinearLayout.LayoutParams(-1, -2))
        val br = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        bSpeed = btn("1x", 15) { speedI = (speedI + 1) % speeds.size; player?.setPlaybackSpeed(speeds[speedI]); bSpeed.text = speeds[speedI].toString().removeSuffix(".0") + "x"; showCtl(true) }
        bPlay = btn("⏸", 26) { toggle() }
        br.addView(btn("⏪ 10", 15) { seekBy(-10_000) }, LinearLayout.LayoutParams(dp(78), dp(48)))
        br.addView(bPlay, LinearLayout.LayoutParams(dp(64), dp(48)))
        br.addView(btn("10 ⏩", 15) { seekBy(10_000) }, LinearLayout.LayoutParams(dp(78), dp(48)))
        br.addView(bSpeed, LinearLayout.LayoutParams(dp(58), dp(48)))
        br.addView(btn("⤢", 20) { fill = !fill; applySize(); showCtl(true) }, LinearLayout.LayoutParams(dp(52), dp(48)))
        ctl.addView(br, LinearLayout.LayoutParams(-1, -2))
        box.addView(ctl, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        // error panel
        err = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER; setPadding(dp(24), 0, dp(24), 0); visibility = View.GONE }
        errBtn = btn(Lang.t(this@VideoActivity, "बाहिरी Player मा खोल्नुहोस्", "Open in another player"), 15) { openExternal() }.apply {
            setBackgroundColor(Color.parseColor("#4682b4")); setPadding(dp(18), dp(10), dp(18), dp(10)); visibility = View.GONE
        }
        val ecol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        ecol.addView(err, LinearLayout.LayoutParams(-1, -2))
        ecol.addView(errBtn, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(14) })
        box.addView(ecol, FrameLayout.LayoutParams(-1, -1))

        // tap = controls, double tap left/right = -/+ 10s
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean { showCtl(ctl.visibility != View.VISIBLE); return true }
            override fun onDoubleTap(e: MotionEvent): Boolean { seekBy(if (e.x < box.width / 2) -10_000 else 10_000); return true }
        })
        surface.setOnTouchListener { _, e -> gd.onTouchEvent(e); true }
        box.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> applySize() }
        setContentView(box)
        hideBars()

        startPlayer(title)
    }

    private fun btn(t: String, size: Int, click: () -> Unit) = TextView(this).apply {
        text = t; textSize = size.toFloat(); setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setOnClickListener { click() }
    }

    private fun resolve(raw: String): Uri {
        val u = Uri.parse(raw)
        if (u.host == "sgs.media" && u.pathSegments.size >= 2) {
            val base = if (u.pathSegments[0] == "v") MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            return ContentUris.withAppendedId(base, u.pathSegments[1].toLong())
        }
        return u
    }

    private fun startPlayer(title: String) {
        val rf = DefaultRenderersFactory(this)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
            .setEnableDecoderFallback(true)
        val http = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true).setUserAgent("Mozilla/5.0 (Linux; Android) SGS")
        val p = ExoPlayer.Builder(this, rf)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http)))
            .build()
        player = p
        p.setVideoSurfaceView(surface)
        p.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(v: VideoSize) {
                if (v.width > 0 && v.height > 0) { vw = v.width * v.pixelWidthHeightRatio; vh = v.height.toFloat(); applySize() }
            }
            override fun onIsPlayingChanged(playing: Boolean) {
                bPlay.text = if (playing) "⏸" else "▶"
                if (playing) showCtl(true) else { h.removeCallbacks(hideRun) }
            }
            override fun onPlaybackStateChanged(s: Int) {
                if (s == Player.STATE_ENDED) { prefs.edit().remove(key).apply(); bPlay.text = "▶"; showCtl(true) }
            }
            override fun onPlayerError(e: PlaybackException) { showError(e) }
        })
        p.setMediaItem(MediaItem.Builder().setUri(uri).setMediaMetadata(androidx.media3.common.MediaMetadata.Builder().setTitle(title).build()).build())
        val start = prefs.getLong(key, intent.getLongExtra("start", 0L))
        if (start > 3000) p.seekTo(start)
        p.prepare()
        p.playWhenReady = true
        h.post(tick)
    }

    private fun showError(e: PlaybackException) {
        h.removeCallbacks(hideRun)
        err.text = Lang.t(this, "यो भिडियो यहाँ चलाउन सकिएन।\n", "This video could not be played here.\n") + e.errorCodeName +
            Lang.t(this, "\n\nयस्तो ढाँचा/codec यो फोनले चलाउन सक्दैन होला। अर्को Player (VLC / MX Player) मा खोल्न सकिन्छ।",
                "\n\nThis phone may not support the format/codec. You can open it in another player (VLC / MX Player).")
        err.visibility = View.VISIBLE; errBtn.visibility = View.VISIBLE
        showCtl(true)
    }

    private fun openExternal() {
        try {
            val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, null))
        } catch (e: Exception) {
            android.widget.Toast.makeText(this, Lang.t(this, "बाहिरी Player भेटिएन", "No other player found"), android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    private fun pickTrack(type: Int) {
        val p = player ?: return
        val gs = p.currentTracks.groups.filter { it.type == type && it.length > 0 }
        if (gs.isEmpty()) { android.widget.Toast.makeText(this, Lang.t(this, "अरू ट्र्याक छैन", "No other tracks"), android.widget.Toast.LENGTH_SHORT).show(); return }
        val names = ArrayList<String>(); val refs = ArrayList<Pair<androidx.media3.common.Tracks.Group, Int>>()
        gs.forEach { g ->
            for (i in 0 until g.length) {
                val f = g.getTrackFormat(i)
                val nm = f.label ?: f.language ?: "Track ${names.size + 1}"
                val ch = if (f.channelCount > 0) " · ${f.channelCount}ch" else ""
                names.add((if (g.isTrackSelected(i)) "✓ " else "") + nm + ch + (f.sampleMimeType?.let { " · " + it.substringAfter('/') } ?: ""))
                refs.add(Pair(g, i))
            }
        }
        AlertDialog.Builder(this).setTitle(Lang.t(this, "आवाज (Audio) ट्र्याक", "Audio track"))
            .setItems(names.toTypedArray()) { _, w ->
                val (g, i) = refs[w]
                p.trackSelectionParameters = p.trackSelectionParameters.buildUpon().setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i)).build()
            }.show()
    }

    private fun toggle() { player?.let { if (it.isPlaying) it.pause() else { if (it.playbackState == Player.STATE_ENDED) it.seekTo(0); it.play() } } }
    private fun seekBy(ms: Long) { player?.let { it.seekTo((it.currentPosition + ms).coerceIn(0L, if (it.duration > 0) it.duration else Long.MAX_VALUE)) }; showCtl(true) }

    private fun showCtl(show: Boolean) {
        h.removeCallbacks(hideRun)
        val v = if (show) View.VISIBLE else View.GONE
        ctl.visibility = v; top.visibility = v
        if (show && player?.isPlaying == true) h.postDelayed(hideRun, 3500)
    }

    private fun applySize() {
        val cw = box.width.toFloat(); val ch = box.height.toFloat()
        if (cw <= 0 || ch <= 0 || vw <= 0 || vh <= 0) return
        val r = vw / vh
        var w = cw; var hh = cw / r
        if (fill) { if (hh < ch) { hh = ch; w = ch * r } } else if (hh > ch) { hh = ch; w = ch * r }
        val lp = surface.layoutParams as FrameLayout.LayoutParams
        if (lp.width != w.toInt() || lp.height != hh.toInt()) { lp.width = w.toInt(); lp.height = hh.toInt(); lp.gravity = Gravity.CENTER; surface.layoutParams = lp }
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus) hideBars() }

    private fun savePos() {
        val p = player ?: return
        if (p.playbackState != Player.STATE_ENDED && p.currentPosition > 3000) prefs.edit().putLong(key, p.currentPosition).apply()
    }

    override fun onPause() { savePos(); player?.pause(); super.onPause() }

    override fun onDestroy() { h.removeCallbacksAndMessages(null); savePos(); player?.release(); player = null; super.onDestroy() }
}
