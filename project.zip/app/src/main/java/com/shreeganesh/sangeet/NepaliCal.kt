package com.shreeganesh.sangeet

import java.time.LocalDate
import kotlin.math.floor
import kotlin.math.sin

/**
 * Tithi (approximate, calculated from the sun and moon positions) and the holidays/festivals
 * of the Government of Nepal's 2083 BS notice, plus the national days that fall on the same
 * Bikram Sambat date every year.
 */
object NepaliCal {
    private val TN = arrayOf(
        "प्रतिपदा", "द्वितीया", "तृतीया", "चतुर्थी", "पञ्चमी", "षष्ठी", "सप्तमी",
        "अष्टमी", "नवमी", "दशमी", "एकादशी", "द्वादशी", "त्रयोदशी", "चतुर्दशी"
    )

    private fun rad(x: Double) = Math.toRadians(x)

    private fun jd(y: Int, m0: Int, d: Int, hour: Double): Double {
        var yy = y; var m = m0
        if (m <= 2) { yy -= 1; m += 12 }
        val a = yy / 100
        val b = 2 - a + a / 4
        return floor(365.25 * (yy + 4716)) + floor(30.6001 * (m + 1)) + d + hour / 24 + b - 1524.5
    }

    private fun sunLon(t: Double): Double {
        val l0 = 280.46646 + 36000.76983 * t
        val m = 357.52911 + 35999.05029 * t
        val c = (1.914602 - 0.004817 * t) * sin(rad(m)) + 0.019993 * sin(rad(2 * m)) + 0.000289 * sin(rad(3 * m))
        val om = 125.04 - 1934.136 * t
        return ((l0 + c - 0.00569 - 0.00478 * sin(rad(om))) % 360 + 360) % 360
    }

    private fun moonLon(t: Double): Double {
        val lp = 218.3164477 + 481267.88123421 * t
        val d = 297.8501921 + 445267.1114034 * t
        val m = 357.5291092 + 35999.0502909 * t
        val mp = 134.9633964 + 477198.8675055 * t
        val f = 93.2720950 + 483202.0175233 * t
        fun s(x: Double) = sin(rad(x))
        val l = lp + 6.288774 * s(mp) + 1.274027 * s(2 * d - mp) + 0.658314 * s(2 * d) + 0.213618 * s(2 * mp) -
            0.185116 * s(m) - 0.114332 * s(2 * f) + 0.058793 * s(2 * d - 2 * mp) + 0.057066 * s(2 * d - m - mp) +
            0.053322 * s(2 * d + mp) + 0.045758 * s(2 * d - m) - 0.040923 * s(m - mp) - 0.034720 * s(d) -
            0.030383 * s(m + mp) + 0.015327 * s(2 * d - 2 * f) - 0.012528 * s(mp + 2 * f) + 0.010980 * s(mp - 2 * f) +
            0.010675 * s(4 * d - mp) + 0.010034 * s(3 * mp) + 0.008548 * s(4 * d - 2 * mp) - 0.007888 * s(2 * d + m - mp) -
            0.006766 * s(2 * d + m) - 0.005163 * s(d - mp) + 0.004987 * s(d + m) + 0.004036 * s(2 * d - m + mp) +
            0.003994 * s(2 * mp + 2 * d) + 0.003861 * s(4 * d) + 0.003665 * s(2 * d - 3 * mp)
        return (l % 360 + 360) % 360
    }

    /** Tithi number 1..30 around sunrise in Nepal (about 06:15 NPT). */
    fun tithiNo(date: LocalDate): Int {
        val t = (jd(date.year, date.monthValue, date.dayOfMonth, 0.5) - 2451545.0) / 36525.0
        val e = ((moonLon(t) - sunLon(t)) % 360 + 360) % 360
        return (e / 12).toInt() + 1
    }

    fun tithiText(date: LocalDate): String {
        val t = tithiNo(date)
        return when {
            t == 15 -> "शुक्ल · पूर्णिमा"
            t == 30 -> "कृष्ण · औंसी"
            t < 15 -> "शुक्ल · " + TN[t - 1]
            else -> "कृष्ण · " + TN[t - 16]
        }
    }

    // BS month numbers: 1 बैशाख ... 12 चैत्र
    private val every = mapOf(
        "1-1" to "नयाँ वर्ष", "2-15" to "गणतन्त्र दिवस", "6-3" to "संविधान दिवस",
        "9-27" to "पृथ्वी जयन्ती", "10-1" to "माघे सङ्क्रान्ति", "10-16" to "सहिद दिवस",
        "11-7" to "प्रजातन्त्र दिवस"
    )

    // From the Home Ministry's holiday notice for 2083 BS.
    private val y2083 = mapOf(
        "1-18" to "विश्व मजदुर दिवस · बुद्ध जयन्ती", "5-12" to "रक्षाबन्धन", "5-13" to "गाईजात्रा",
        "5-19" to "श्रीकृष्ण जन्माष्टमी", "5-29" to "हरितालिका तीज", "6-9" to "इन्द्रजात्रा",
        "6-18" to "जितिया", "6-25" to "घटस्थापना", "7-22" to "लक्ष्मी पूजा (तिहार)", "7-25" to "भाइटिका",
        "7-29" to "छठ पर्व", "8-17" to "अपाङ्गता दिवस", "9-10" to "क्रिसमस", "9-15" to "तमू ल्होसार",
        "10-24" to "सोनम ल्होसार", "10-28" to "वसन्त पञ्चमी", "11-22" to "महाशिवरात्री",
        "11-24" to "महिला दिवस", "11-25" to "ग्याल्पो ल्होसार", "12-7" to "फागु पूर्णिमा", "12-23" to "घोडेजात्रा"
    )

    fun festival(date: LocalDate): String {
        val b = BsDate.ymd(date) ?: return ""
        val key = b[1].toString() + "-" + b[2]
        val out = ArrayList<String>()
        every[key]?.let { out.add(it) }
        if (b[0] == 2083) {
            y2083[key]?.let { out.add(it) }
            val m = b[1]; val d = b[2]
            if ((m == 6 && d == 31) || (m == 7 && d <= 6)) out.add("दशैं बिदा")
            if (m == 7 && d in 22..26) out.add("तिहार बिदा")
        }
        return out.joinToString(" · ")
    }
}
