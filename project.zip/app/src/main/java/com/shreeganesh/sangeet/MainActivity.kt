package com.shreeganesh.sangeet

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.net.Uri
import android.content.ContentUris
import android.provider.MediaStore
import java.io.FilterInputStream
import java.io.InputStream
import org.json.JSONArray
import org.json.JSONObject
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var pageReady = false
    private var pendingCmd: Pair<String, String>? = null
    private var pendingAlarm: Pair<String, Boolean>? = null

    inner class JsBridge {
        @JavascriptInterface
        fun update(title: String, sub: String, playing: Boolean) {
            if (PlaybackService.radioMode) {
                if (sub.startsWith("Radio")) return // the Android player reports radio itself
                if (playing) PlaybackService.radioCmd(applicationContext, PlaybackService.A_R_STOP) // device audio took over
            }
            runOnUiThread { PlaybackService.send(this@MainActivity, title, sub, playing) }
        }

        @JavascriptInterface
        fun radioPlay(json: String) { PlaybackService.radioCmd(applicationContext, PlaybackService.A_R_PLAY, json) }

        @JavascriptInterface
        fun radioPause() { PlaybackService.radioCmd(applicationContext, PlaybackService.A_R_PAUSE) }

        @JavascriptInterface
        fun radioResume() { PlaybackService.radioCmd(applicationContext, PlaybackService.A_R_RESUME) }

        @JavascriptInterface
        fun radioStop() { PlaybackService.radioCmd(applicationContext, PlaybackService.A_R_STOP) }

        @JavascriptInterface
        fun radioVolume(v: Double) { PlaybackService.radioVolume(v.toFloat()) }

        @JavascriptInterface
        fun radioState(): String = PlaybackService.radioStateJson()

        @JavascriptInterface
        fun setAlarms(json: String) {
            AlarmScheduler.store(applicationContext, json)
            val info = AlarmScheduler.scheduleAll(applicationContext)
            runOnUiThread {
                android.widget.Toast.makeText(
                    this@MainActivity,
                    if (info.isEmpty()) "Android Alarm सेट छैन. n=" + AlarmScheduler.loadArr(applicationContext).length() + AlarmScheduler.lastDebug else "Android Alarm सेट: $info" + AlarmScheduler.lastDebug,
                    android.widget.Toast.LENGTH_LONG
                ).show()
            }
        }

        @JavascriptInterface
        fun consumePendingOff(): String = AlarmScheduler.consumePendingOff(applicationContext)

        @JavascriptInterface
        fun hasMediaPerm(): Boolean = mediaPermGranted()

        @JavascriptInterface
        fun requestMediaPerm() { runOnUiThread { requestMediaPermission() } }

        @JavascriptInterface
        fun scanMedia(): String = MediaScanner.scan(applicationContext)

        @JavascriptInterface
        fun state(json: String) {
            if (PlaybackService.radioMode && json.contains("\"k\":\"r\"")) return // native player writes it
            WidgetState.saveState(applicationContext, json)
            WidgetUpdater.updateAll(applicationContext)
        }

        @JavascriptInterface
        fun setFavs(json: String) {
            WidgetState.saveFavs(applicationContext, json)
            WidgetUpdater.updateAll(applicationContext)
        }

        @JavascriptInterface
        fun version(): String = this@MainActivity.version()

        @JavascriptInterface
        fun radioOk(url: String) { AlarmScheduler.rememberRadio(applicationContext, url) }

        @JavascriptInterface
        fun snooze(id: String) { AlarmScheduler.snooze(applicationContext, id) }

        @JavascriptInterface
        fun alarmHandled() { AlarmService.cmd(applicationContext, AlarmService.A_STOP) }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            allowFileAccess = true
        }
        web.addJavascriptInterface(JsBridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, req: WebResourceRequest): WebResourceResponse? {
                val u = req.url
                if (u.host != "sgs.media") return null
                return try { serveMedia(u, req.requestHeaders["Range"] ?: req.requestHeaders["range"]) } catch (e: Exception) { null }
            }

            override fun onPageFinished(view: WebView, url: String?) {
                try {
                    val js = assets.open("bridge.js").bufferedReader().use { it.readText() }
                    view.evaluateJavascript(js, null)
                } catch (e: Exception) {
                }
                pageReady = true
                showReport(true)
                pendingAlarm?.let { runAlarm(it.first, it.second) }
                pendingAlarm = null
                pendingCmd?.let { runCmd(it.first, it.second, 0L) }
                pendingCmd = null
            }
        }
        web.webChromeClient = WebChromeClient()
        PlayerBus.js = { code -> runOnUiThread { web.evaluateJavascript(code, null) } }
        handleAlarmIntent(intent)
        handleCmdIntent(intent)
        if (savedInstanceState == null) {
            web.loadUrl("file:///android_asset/index.html")
        } else {
            web.restoreState(savedInstanceState)
        }
    }

    private fun mediaPermGranted(): Boolean =
        if (Build.VERSION.SDK_INT >= 33)
            checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED
        else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestMediaPermission() {
        val p = if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VIDEO)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        requestPermissions(p, 2)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == 2) {
            if (mediaPermGranted()) web.evaluateJavascript("window.__sgsScan&&window.__sgsScan()", null)
            else android.widget.Toast.makeText(this, "गीत/भिडियो देखाउन अनुमति चाहिन्छ", android.widget.Toast.LENGTH_LONG).show()
        }
    }

    private class Limited(s: InputStream, private var left: Long) : FilterInputStream(s) {
        override fun read(): Int { if (left <= 0) return -1; val r = super.read(); if (r >= 0) left--; return r }
        override fun read(b: ByteArray, o: Int, l: Int): Int {
            if (left <= 0) return -1
            val r = super.read(b, o, minOf(l.toLong(), left).toInt()); if (r > 0) left -= r; return r
        }
    }

    /** Streams a phone media file to the HTML player, with Range support so seeking works. */
    private fun serveMedia(u: Uri, range: String?): WebResourceResponse {
        val seg = u.pathSegments
        val base = if (seg[0] == "v") MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val uri = ContentUris.withAppendedId(base, seg[1].toLong())
        val afd = contentResolver.openAssetFileDescriptor(uri, "r")!!
        val total = afd.length
        val mime = contentResolver.getType(uri) ?: (if (seg[0] == "v") "video/mp4" else "audio/mpeg")
        var start = 0L
        var end = total - 1
        var status = 200
        if (range != null && range.startsWith("bytes=") && total > 0) {
            val parts = range.removePrefix("bytes=").split("-")
            start = parts.getOrNull(0)?.toLongOrNull() ?: 0L
            val e = parts.getOrNull(1)?.toLongOrNull()
            if (e != null) end = minOf(e, total - 1)
            if (start > end) start = 0
            status = 206
        }
        val input = afd.createInputStream()
        if (start > 0) input.skip(start)
        val h = HashMap<String, String>()
        h["Accept-Ranges"] = "bytes"
        h["Access-Control-Allow-Origin"] = "*"
        if (total > 0) {
            h["Content-Length"] = (end - start + 1).toString()
            if (status == 206) h["Content-Range"] = "bytes $start-$end/$total"
        }
        val stream: InputStream = if (total > 0) Limited(input, end - start + 1) else input
        return WebResourceResponse(mime, null, status, if (status == 206) "Partial Content" else "OK", h, stream)
    }

    private fun version(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "?"
    } catch (e: Exception) { "?" }

    private fun showReport(always: Boolean) {
        val lg = AlarmScheduler.consumeLog(applicationContext)
        if (lg.isEmpty() && !always) return
        android.app.AlertDialog.Builder(this)
            .setTitle("Android version: " + version())
            .setMessage(if (lg.isEmpty()) "Alarm रिपोर्ट: कुनै छैन (Alarm अहिलेसम्म बजेको छैन)" else "पछिल्लो Alarm रिपोर्ट:\n" + lg)
            .setPositiveButton("OK", null).show()
    }

    override fun onResume() {
        super.onResume()
        if (pageReady) {
            showReport(false)
            web.evaluateJavascript("window.__sgsScanSoon&&window.__sgsScanSoon()", null)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleAlarmIntent(intent)
        handleCmdIntent(intent)
    }

    @Suppress("DEPRECATION")
    private fun handleAlarmIntent(i: Intent?) {
        if (i == null) return
        val nat = i.getStringExtra("alarm_native")
        if (nat != null) {
            i.removeExtra("alarm_native")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
            getSystemService(android.app.NotificationManager::class.java).cancel(3)
            try {
                startForegroundService(
                    Intent(this, AlarmService::class.java).setAction(AlarmService.A_RING).putExtra("id", nat)
                )
            } catch (e: Exception) {
                AlarmScheduler.appendLog(applicationContext, "activity could not start alarm service: " + e.javaClass.simpleName)
            }
            return
        }
        val id = i.getStringExtra("alarm_id") ?: return
        val snz = i.getBooleanExtra("alarm_snz", false)
        i.removeExtra("alarm_id")
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
        )
        if (pageReady) runAlarm(id, snz) else pendingAlarm = Pair(id, snz)
    }

    private fun handleCmdIntent(i: Intent?) {
        if (i == null) return
        val c = i.getStringExtra("cmd") ?: return
        val a = i.getStringExtra("arg") ?: ""
        i.removeExtra("cmd")
        if (c == "open") return
        if (pageReady) runCmd(c, a, 0) else pendingCmd = Pair(c, a)
    }

    private fun runCmd(c: String, a: String, delay: Long) {
        val body = PlayerBus.script(c, a)
        if (body.isEmpty()) return
        // run as soon as the page's bridge is ready (no fixed waiting time)
        val js = "(function w(n){if(window.__sgsReady||n>60){" + body + "}else setTimeout(function(){w(n+1)},50)})(0)"
        Handler(Looper.getMainLooper()).postDelayed({ web.evaluateJavascript(js, null) }, delay)
    }

    private fun runAlarm(id: String, snz: Boolean) {
        val safe = id.replace("\\", "").replace("\"", "").replace("'", "")
        Handler(Looper.getMainLooper()).postDelayed({
            web.evaluateJavascript("if(window.__sgsRing)window.__sgsRing('$safe',$snz)", null)
        }, 1500)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else moveTaskToBack(true)
    }

    override fun onDestroy() {
        PlayerBus.js = null
        if (isFinishing && !PlaybackService.radioMode) stopService(Intent(this, PlaybackService::class.java))
        super.onDestroy()
    }
}
