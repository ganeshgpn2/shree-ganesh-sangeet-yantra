package com.shreeganesh.sangeet

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var pageReady = false
    private var pendingAlarm: Pair<String, Boolean>? = null

    inner class JsBridge {
        @JavascriptInterface
        fun update(title: String, sub: String, playing: Boolean) {
            runOnUiThread { PlaybackService.send(this@MainActivity, title, sub, playing) }
        }

        @JavascriptInterface
        fun setAlarms(json: String) {
            AlarmScheduler.store(applicationContext, json)
            val info = AlarmScheduler.scheduleAll(applicationContext)
            runOnUiThread {
                android.widget.Toast.makeText(
                    this@MainActivity,
                    if (info.isEmpty()) "Android Alarm सेट छैन. n=" + AlarmScheduler.loadArr(applicationContext).length() + AlarmScheduler.lastDebug else "Android Alarm सेट: $info" + AlarmScheduler.lastDebug,
                    android.widget.Toast.LENGTH_LONG
                ).show()
            }
        }

        @JavascriptInterface
        fun consumePendingOff(): String = AlarmScheduler.consumePendingOff(applicationContext)

        @JavascriptInterface
        fun radioOk(url: String) { AlarmScheduler.rememberRadio(applicationContext, url) }

        @JavascriptInterface
        fun snooze(id: String) { AlarmScheduler.snooze(applicationContext, id) }

        @JavascriptInterface
        fun alarmHandled() { AlarmService.cmd(applicationContext, AlarmService.A_STOP) }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            allowFileAccess = true
        }
        web.addJavascriptInterface(JsBridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                try {
                    val js = assets.open("bridge.js").bufferedReader().use { it.readText() }
                    view.evaluateJavascript(js, null)
                } catch (e: Exception) {
                }
                pageReady = true
                showReport(true)
                pendingAlarm?.let { runAlarm(it.first, it.second) }
                pendingAlarm = null
            }
        }
        web.webChromeClient = WebChromeClient()
        PlayerBus.js = { code -> runOnUiThread { web.evaluateJavascript(code, null) } }
        handleAlarmIntent(intent)
        if (savedInstanceState == null) {
            web.loadUrl("file:///android_asset/index.html")
        } else {
            web.restoreState(savedInstanceState)
        }
    }

    private fun version(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "?"
    } catch (e: Exception) { "?" }

    private fun showReport(always: Boolean) {
        val lg = AlarmScheduler.consumeLog(applicationContext)
        if (lg.isEmpty() && !always) return
        android.app.AlertDialog.Builder(this)
            .setTitle("Android version: " + version())
            .setMessage(if (lg.isEmpty()) "Alarm रिपोर्ट: कुनै छैन (Alarm अहिलेसम्म बजेको छैन)" else "पछिल्लो Alarm रिपोर्ट:\n" + lg)
            .setPositiveButton("OK", null).show()
    }

    override fun onResume() {
        super.onResume()
        if (pageReady) showReport(false)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleAlarmIntent(intent)
    }

    @Suppress("DEPRECATION")
    private fun handleAlarmIntent(i: Intent?) {
        if (i == null) return
        val id = i.getStringExtra("alarm_id") ?: return
        val snz = i.getBooleanExtra("alarm_snz", false)
        i.removeExtra("alarm_id")
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
        )
        if (pageReady) runAlarm(id, snz) else pendingAlarm = Pair(id, snz)
    }

    private fun runAlarm(id: String, snz: Boolean) {
        val safe = id.replace("\\", "").replace("\"", "").replace("'", "")
        Handler(Looper.getMainLooper()).postDelayed({
            web.evaluateJavascript("if(window.__sgsRing)window.__sgsRing('$safe',$snz)", null)
        }, 1500)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else moveTaskToBack(true)
    }

    override fun onDestroy() {
        PlayerBus.js = null
        if (isFinishing) stopService(Intent(this, PlaybackService::class.java))
        super.onDestroy()
    }
}
