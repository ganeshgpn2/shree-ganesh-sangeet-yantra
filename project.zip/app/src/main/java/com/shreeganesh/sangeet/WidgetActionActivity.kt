package com.shreeganesh.sangeet

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/** Invisible helper: a widget button tap lands here, runs the command, and closes at once. */
class WidgetActionActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val cmd = intent.getStringExtra("cmd") ?: ""
        val arg = intent.getStringExtra("arg") ?: ""
        val appAlive = PlayerBus.js != null
        val quiet = cmd == "toggle" || cmd == "next" || cmd == "prev" || cmd == "playfav" || cmd == "dplay" || cmd == "dnext" || cmd == "dprev"
        if (appAlive && quiet) {
            PlayerBus.run(cmd, arg)
        } else {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .putExtra("cmd", cmd).putExtra("arg", arg)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
        }
        finish()
    }
}
