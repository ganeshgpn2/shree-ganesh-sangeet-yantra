package com.shreeganesh.sangeet

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import org.json.JSONObject

/** Invisible helper: a widget button tap lands here, runs the command, and closes at once. */
class WidgetActionActivity : Activity() {

    private fun openApp(cmd: String, arg: String) {
        startActivity(
            Intent(this, MainActivity::class.java)
                .putExtra("cmd", cmd).putExtra("arg", arg)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        )
    }

    private fun lastIsRadio() = WidgetState.kind(this) == "r" && WidgetState.key(this).startsWith("http")

    /** Station next to the current one in the favourites list. */
    private fun neighbour(delta: Int): String? {
        val favs = WidgetState.favs(this).filter { it.key.startsWith("http") }
        if (favs.isEmpty()) return null
        val cur = if (lastIsRadio()) WidgetState.key(this) else WidgetState.lastRadio(this)
        val i = favs.indexOfFirst { it.key == cur }
        return favs[((if (i < 0) 0 else i) + delta + favs.size) % favs.size].key
    }

    private fun cassette(cmd: String) {
        val ctx = this
        when (cmd) {
            "ck_toggle" -> when {
                PlaybackService.radioMode -> PlaybackService.radioCmd(ctx, PlaybackService.A_R_TOGGLE)
                PlaybackService.musicMode -> PlaybackService.musicCmd(ctx, PlaybackService.A_M_TOGGLE)
                lastIsRadio() -> PlaybackService.radioCmd(
                    ctx, PlaybackService.A_R_PLAYONE,
                    JSONObject().put("n", WidgetState.title(ctx)).put("u", WidgetState.key(ctx)).put("k", WidgetState.key(ctx)).toString()
                )
                WidgetState.devKey(ctx).isNotEmpty() -> PlaybackService.musicCmd(ctx, PlaybackService.A_M_PLAYKEY, key = WidgetState.devKey(ctx))
                else -> openApp("open", "")
            }
            "ck_next", "ck_prev" -> {
                val d = if (cmd == "ck_next") 1 else -1
                when {
                    PlaybackService.radioMode -> PlaybackService.sendAction(ctx, if (d > 0) PlaybackService.A_NEXT else PlaybackService.A_PREV)
                    PlaybackService.musicMode -> PlaybackService.sendAction(ctx, if (d > 0) PlaybackService.A_NEXT else PlaybackService.A_PREV)
                    WidgetState.kind(ctx) == "r" -> neighbour(d)?.let { PlaybackService.radioCmd(ctx, PlaybackService.A_R_PLAYKEY, key = it) } ?: openApp("open", "")
                    WidgetState.devKey(ctx).isNotEmpty() -> PlaybackService.musicCmd(ctx, PlaybackService.A_M_PLAYKEY, key = WidgetState.devKey(ctx), d = d)
                    else -> openApp("open", "")
                }
            }
            "ck_rew", "ck_ff" -> {
                if (PlaybackService.musicMode) PlaybackService.sendAction(ctx, PlaybackService.A_M_SEEKBY, if (cmd == "ck_ff") 10_000L else -10_000L)
                else Toast.makeText(ctx, "अगाडि/पछाडि सार्न फोनको गीतमा मात्र मिल्छ", Toast.LENGTH_SHORT).show()
            }
            "ck_stop" -> {
                if (PlaybackService.running) PlaybackService.sendAction(ctx, PlaybackService.A_STOP_ALL)
                else PlayerBus.js?.invoke("try{stopAll()}catch(e){}")
            }
            "ck_rec" -> when {
                RecordService.active -> RecordService.stop(ctx)
                lastIsRadio() && WidgetState.playing(ctx) ->
                    RecordService.start(ctx, JSONObject().put("name", WidgetState.title(ctx)).put("url", WidgetState.key(ctx)).put("max", 0).toString())
                else -> Toast.makeText(ctx, "रेकर्ड गर्न पहिले रेडियो बजाउनुहोस्", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val cmd = intent.getStringExtra("cmd") ?: ""
        val arg = intent.getStringExtra("arg") ?: ""
        val appAlive = PlayerBus.js != null
        when {
            cmd.startsWith("ck_") -> cassette(cmd)
            // radio is played by the Android player: instant, no app screen needed
            cmd == "playfav" -> PlaybackService.radioCmd(this, PlaybackService.A_R_PLAYKEY, key = arg)
            // phone songs are played by the Android player too
            cmd == "dplay" -> if (PlaybackService.musicMode) PlaybackService.musicCmd(this, PlaybackService.A_M_TOGGLE)
                else PlaybackService.musicCmd(this, PlaybackService.A_M_PLAYKEY, key = arg)
            cmd == "dnext" -> if (PlaybackService.musicMode) PlaybackService.musicCmd(this, PlaybackService.A_M_NEXT)
                else PlaybackService.musicCmd(this, PlaybackService.A_M_PLAYKEY, key = arg, d = 1)
            cmd == "dprev" -> if (PlaybackService.musicMode) PlaybackService.musicCmd(this, PlaybackService.A_M_PREV)
                else PlaybackService.musicCmd(this, PlaybackService.A_M_PLAYKEY, key = arg, d = -1)
            cmd == "toggle" && PlaybackService.musicMode -> PlaybackService.musicCmd(this, PlaybackService.A_M_TOGGLE)
            cmd == "toggle" && PlaybackService.radioMode -> PlaybackService.radioCmd(this, PlaybackService.A_R_TOGGLE)
            appAlive && (cmd == "toggle" || cmd == "next" || cmd == "prev") -> PlayerBus.run(cmd, arg)
            else -> openApp(cmd, arg)
        }
        finish()
    }
}
