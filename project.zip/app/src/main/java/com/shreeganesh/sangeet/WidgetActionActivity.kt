package com.shreeganesh.sangeet

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/** Invisible helper: a widget button tap lands here, runs the command, and closes at once. */
class WidgetActionActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val cmd = intent.getStringExtra("cmd") ?: ""
        val arg = intent.getStringExtra("arg") ?: ""
        val appAlive = PlayerBus.js != null
        when {
            // radio is played by the Android player: instant, no app screen needed
            cmd == "playfav" -> PlaybackService.radioCmd(this, PlaybackService.A_R_PLAYKEY, key = arg)
            // phone songs are played by the Android player too
            cmd == "dplay" -> if (PlaybackService.musicMode) PlaybackService.musicCmd(this, PlaybackService.A_M_TOGGLE)
                else PlaybackService.musicCmd(this, PlaybackService.A_M_PLAYKEY, key = arg)
            cmd == "dnext" -> if (PlaybackService.musicMode) PlaybackService.musicCmd(this, PlaybackService.A_M_NEXT)
                else PlaybackService.musicCmd(this, PlaybackService.A_M_PLAYKEY, key = arg, d = 1)
            cmd == "dprev" -> if (PlaybackService.musicMode) PlaybackService.musicCmd(this, PlaybackService.A_M_PREV)
                else PlaybackService.musicCmd(this, PlaybackService.A_M_PLAYKEY, key = arg, d = -1)
            cmd == "toggle" && PlaybackService.musicMode -> PlaybackService.musicCmd(this, PlaybackService.A_M_TOGGLE)
            cmd == "toggle" && PlaybackService.radioMode -> PlaybackService.radioCmd(this, PlaybackService.A_R_TOGGLE)
            appAlive && (cmd == "toggle" || cmd == "next" || cmd == "prev" || cmd == "dplay" || cmd == "dnext" || cmd == "dprev") ->
                PlayerBus.run(cmd, arg)
            else -> startActivity(
                Intent(this, MainActivity::class.java)
                    .putExtra("cmd", cmd).putExtra("arg", arg)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
        }
        finish()
    }
}
