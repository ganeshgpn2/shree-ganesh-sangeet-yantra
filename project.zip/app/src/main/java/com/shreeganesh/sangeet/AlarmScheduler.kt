package com.shreeganesh.sangeet

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** Keeps the alarm list (sent from the HTML app) and schedules real Android alarms. */
object AlarmScheduler {
    private const val P = "sgs"
    const val A_FIRE = "sgs.FIRE"
    const val SNZ = "snz:"

    private fun prefs(c: Context) = c.getSharedPreferences(P, Context.MODE_PRIVATE)

    fun loadArr(c: Context): JSONArray =
        try { JSONArray(prefs(c).getString("alarms", "[]")) } catch (e: Exception) { JSONArray() }

    fun find(c: Context, id: String): JSONObject? {
        val arr = loadArr(c)
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optString("id") == id) return o
        }
        return null
    }

    fun store(c: Context, json: String) {
        try { JSONArray(json) } catch (e: Exception) { return } // ignore corrupt data
        prefs(c).edit().putString("alarms", json).apply()
        scheduleAll(c)
    }

    fun markOff(c: Context, id: String) {
        val arr = loadArr(c)
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optString("id") == id) o.put("on", false)
        }
        val off = prefs(c).getStringSet("off", emptySet())!!.toMutableSet().apply { add(id) }
        prefs(c).edit().putString("alarms", arr.toString()).putStringSet("off", off).apply()
    }

    fun consumePendingOff(c: Context): String {
        val off = prefs(c).getStringSet("off", emptySet())!!
        val s = JSONArray(off.toList()).toString()
        prefs(c).edit().remove("off").apply()
        return s
    }

    fun nextTime(a: JSONObject, from: Long = System.currentTimeMillis()): Long {
        val parts = a.optString("time", "06:00").split(":")
        val h = parts.getOrNull(0)?.toIntOrNull() ?: return -1
        val m = parts.getOrNull(1)?.toIntOrNull() ?: return -1
        val days = a.optJSONArray("days") ?: JSONArray()
        val set = HashSet<Int>()
        for (i in 0 until days.length()) set.add(days.optInt(i))
        for (off in 0..7) {
            val cal = Calendar.getInstance()
            cal.timeInMillis = from
            cal.add(Calendar.DAY_OF_YEAR, off)
            cal.set(Calendar.HOUR_OF_DAY, h); cal.set(Calendar.MINUTE, m)
            cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
            val dow = cal.get(Calendar.DAY_OF_WEEK) - 1 // 0 = Sunday, same as the HTML app
            if (cal.timeInMillis > from && (set.isEmpty() || set.contains(dow))) return cal.timeInMillis
        }
        return -1
    }

    private fun firePi(c: Context, id: String): PendingIntent = PendingIntent.getBroadcast(
        c, id.hashCode(),
        Intent(c, AlarmReceiver::class.java).setAction(A_FIRE).putExtra("id", id),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun setAt(c: Context, id: String, t: Long) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(
            c, 7, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        am.setAlarmClock(AlarmManager.AlarmClockInfo(t, show), firePi(c, id))
    }

    fun scheduleAll(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val p = prefs(c)
        p.getStringSet("ids", emptySet())!!.forEach { am.cancel(firePi(c, it)) }
        val ids = HashSet<String>()
        val arr = loadArr(c)
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (!o.optBoolean("on", false)) continue
            val id = o.optString("id")
            val t = nextTime(o)
            if (id.isEmpty() || t < 0) continue
            try { setAt(c, id, t); ids.add(id) } catch (e: Exception) { }
        }
        p.edit().putStringSet("ids", ids).apply()
    }

    fun snooze(c: Context, baseId: String, minutes: Int = 5) {
        try { setAt(c, SNZ + baseId, System.currentTimeMillis() + minutes * 60_000L) } catch (e: Exception) { }
    }

    /** Text for the next alarm (used later by the clock widget). */
    fun nextAlarmText(c: Context): String {
        var best = Long.MAX_VALUE; var label = ""
        val arr = loadArr(c)
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (!o.optBoolean("on", false)) continue
            val t = nextTime(o)
            if (t in 1 until best) { best = t; label = o.optString("time") }
        }
        return label
    }
}
