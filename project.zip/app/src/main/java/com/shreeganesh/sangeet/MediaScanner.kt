package com.shreeganesh.sangeet

import android.content.ContentUris
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject

/** Reads the phone's audio and video library from Android MediaStore (no file copying). */
object MediaScanner {

    private fun folderOf(rel: String?, data: String?): JSONArray {
        var p = rel ?: ""
        if (p.isEmpty() && data != null) {
            val d = data.substringBeforeLast('/', "")
            p = d.removePrefix("/storage/emulated/0/").removePrefix("/storage/emulated/").removePrefix("/sdcard/")
        }
        val arr = JSONArray()
        p.split('/').filter { it.isNotEmpty() }.forEach { arr.put(it) }
        return arr
    }

    fun scan(c: Context, cb: ((String, Int, Int) -> Unit)? = null): String {
        val out = JSONObject()
        val a = JSONArray()
        val v = JSONArray()
        try {
            val proj = mutableListOf(
                MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.DATA
            )
            if (Build.VERSION.SDK_INT >= 29) proj.add(MediaStore.MediaColumns.RELATIVE_PATH)
            val sel = "is_ringtone=0 AND is_alarm=0 AND is_notification=0"
            c.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj.toTypedArray(), sel, null, null
            )?.use { cur ->
                val iId = cur.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val iN = cur.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val iAr = cur.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val iAl = cur.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val iD = cur.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val iData = cur.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val iRel = if (Build.VERSION.SDK_INT >= 29) cur.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH) else -1
                val total = cur.count
                var n = 0
                while (cur.moveToNext()) {
                    n++
                    if (cb != null && n % 150 == 0) cb("गीत", n, total)
                    val dn = cur.getString(iN) ?: continue
                    val artist = cur.getString(iAr)?.takeIf { it != "<unknown>" } ?: ""
                    val o = JSONObject()
                    o.put("id", cur.getLong(iId))
                    o.put("n", dn.substringBeforeLast('.', dn))
                    o.put("e", if (dn.contains('.')) dn.substringAfterLast('.') else "mp3")
                    o.put("f", folderOf(if (iRel >= 0) cur.getString(iRel) else null, cur.getString(iData)))
                    o.put("s", artist)
                    o.put("al", cur.getString(iAl)?.takeIf { it != "<unknown>" } ?: "")
                    o.put("d", cur.getLong(iD))
                    a.put(o)
                }
            }
        } catch (e: Exception) { }
        try {
            val proj = mutableListOf(
                MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.DURATION, MediaStore.Video.Media.DATA
            )
            if (Build.VERSION.SDK_INT >= 29) proj.add(MediaStore.MediaColumns.RELATIVE_PATH)
            c.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI, proj.toTypedArray(), null, null, null
            )?.use { cur ->
                val iId = cur.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val iN = cur.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val iD = cur.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val iData = cur.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
                val iRel = if (Build.VERSION.SDK_INT >= 29) cur.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH) else -1
                val total = cur.count
                var n = 0
                while (cur.moveToNext()) {
                    n++
                    if (cb != null && n % 100 == 0) cb("भिडियो", n, total)
                    val dn = cur.getString(iN) ?: continue
                    val o = JSONObject()
                    o.put("id", cur.getLong(iId))
                    o.put("n", dn.substringBeforeLast('.', dn))
                    o.put("e", if (dn.contains('.')) dn.substringAfterLast('.') else "mp4")
                    o.put("f", folderOf(if (iRel >= 0) cur.getString(iRel) else null, cur.getString(iData)))
                    o.put("d", cur.getLong(iD))
                    v.put(o)
                }
            }
        } catch (e: Exception) { }
        out.put("a", a)
        out.put("v", v)
        return out.toString()
    }

    data class Meta(val name: String, val artist: String, val durMs: Long)

    fun audioInfo(c: Context, id: Long): Meta {
        try {
            c.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION),
                MediaStore.Audio.Media._ID + "=?", arrayOf(id.toString()), null
            )?.use { cur ->
                if (cur.moveToFirst()) {
                    val dn = cur.getString(0) ?: ""
                    val ar = cur.getString(1)?.takeIf { it != "<unknown>" } ?: ""
                    return Meta(dn.substringBeforeLast('.', dn), ar, cur.getLong(2))
                }
            }
        } catch (e: Exception) { }
        return Meta("", "", 0)
    }

    /** All music ids, sorted by file name (same idea as the list in the app). */
    fun audioIds(c: Context): List<Long> {
        val out = ArrayList<Pair<String, Long>>()
        try {
            c.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME),
                "is_ringtone=0 AND is_alarm=0 AND is_notification=0", null, null
            )?.use { cur ->
                while (cur.moveToNext()) out.add(Pair((cur.getString(1) ?: "").lowercase(), cur.getLong(0)))
            }
        } catch (e: Exception) { }
        out.sortBy { it.first }
        return out.map { it.second }
    }

    /** Where a song is stored, e.g. "Music/Bhajan/song.mp3". */
    fun audioPath(c: Context, id: Long): String {
        try {
            val proj = if (Build.VERSION.SDK_INT >= 29)
                arrayOf(MediaStore.MediaColumns.RELATIVE_PATH, MediaStore.Audio.Media.DISPLAY_NAME)
            else arrayOf(MediaStore.Audio.Media.DATA, MediaStore.Audio.Media.DISPLAY_NAME)
            c.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj,
                MediaStore.Audio.Media._ID + "=?", arrayOf(id.toString()), null
            )?.use { cur ->
                if (cur.moveToFirst()) {
                    val a = cur.getString(0) ?: ""
                    val n = cur.getString(1) ?: ""
                    return if (Build.VERSION.SDK_INT >= 29) a + n else a.removePrefix("/storage/emulated/0/")
                }
            }
        } catch (e: Exception) { }
        return ""
    }
}
