package com.shreeganesh.sangeet

import android.content.Context
import org.json.JSONObject

/** Alternate stream addresses of a radio station, taken from the bundled Excel database. */
object RadioDb {
    private var map: HashMap<String, List<String>>? = null

    private fun load(c: Context): HashMap<String, List<String>> {
        map?.let { return it }
        val m = HashMap<String, List<String>>()
        try {
            val txt = c.assets.open("database.js").bufferedReader().use { it.readText() }
            val json = txt.substringAfter("window.SGS_DB=").trimEnd().removeSuffix(";")
            val arr = JSONObject(json).getJSONArray("radios")
            for (i in 0 until arr.length()) {
                val r = arr.getJSONObject(i)
                val all = ArrayList<String>()
                val s = r.optString("Stream URL", "").trim()
                if (s.startsWith("http")) all.add(s)
                r.optString("Alternate URLs", "").split(";", ",", " ", "\n")
                    .map { it.trim() }.filter { it.startsWith("http") }.forEach { if (!all.contains(it)) all.add(it) }
                all.forEach { m[it] = all }
            }
        } catch (e: Exception) { }
        map = m
        return m
    }

    /** The given address first, then any other known addresses of the same station. */
    fun candidates(c: Context, url: String): List<String> {
        val out = LinkedHashSet<String>()
        if (url.startsWith("http")) out.add(url)
        load(c)[url]?.let { out.addAll(it) }
        return out.toList().take(5)
    }
}
