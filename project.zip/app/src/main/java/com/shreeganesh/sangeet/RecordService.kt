package com.shreeganesh.sangeet

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.Socket
import java.net.URL

/**
 * Records an online radio stream to a file (Music/SGS Recordings) without needing the app screen.
 * It saves the raw stream bytes, so it cannot record HLS (.m3u8) streams.
 */
class RecordService : Service() {
    companion object {
        const val A_START = "sgs.REC_START"
        const val A_STOP = "sgs.REC_STOP"
        const val CH = "sgs_rec"
        const val ID = 4
        @Volatile var active = false
        @Volatile var recName = ""
        @Volatile var t0 = 0L
        @Volatile var size = 0L

        fun start(ctx: Context, json: String) {
            try { ctx.startForegroundService(Intent(ctx, RecordService::class.java).setAction(A_START).putExtra("json", json)) } catch (e: Exception) { }
        }

        fun stop(ctx: Context) {
            if (!active) return
            try { ctx.startService(Intent(ctx, RecordService::class.java).setAction(A_STOP)) } catch (e: Exception) { }
        }

        fun stateJson(): String = JSONObject().put("active", active).put("name", recName).put("t0", t0).put("size", size).toString()

        fun takeRecs(c: Context): String {
            val p = c.getSharedPreferences("sgs_rec", Context.MODE_PRIVATE)
            val s = p.getString("done", "[]") ?: "[]"
            p.edit().remove("done").apply()
            return s
        }

        private fun addDone(c: Context, o: JSONObject) {
            val p = c.getSharedPreferences("sgs_rec", Context.MODE_PRIVATE)
            val a = try { JSONArray(p.getString("done", "[]")) } catch (e: Exception) { JSONArray() }
            a.put(o)
            p.edit().putString("done", a.toString()).apply()
        }
    }

    @Volatile private var stopFlag = false
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    private fun pi(a: String) = PendingIntent.getService(
        this, a.hashCode(), Intent(this, RecordService::class.java).setAction(a),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            A_START -> {
                val o = try { JSONObject(intent.getStringExtra("json") ?: "{}") } catch (e: Exception) { JSONObject() }
                val name = o.optString("name", "Radio")
                showForeground(name)
                if (active) return START_NOT_STICKY
                active = true; stopFlag = false; recName = name; t0 = System.currentTimeMillis(); size = 0
                val urls = listOf(o.optString("url"), o.optString("alt")).filter { it.startsWith("http") }
                val maxMs = o.optInt("max", 0) * 60_000L
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sgs:rec").apply { acquire(6 * 3600_000L) }
                @Suppress("DEPRECATION")
                wifi = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
                    .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "sgs:recwifi").apply { setReferenceCounted(false); acquire() }
                try { WidgetUpdater.updateAll(this) } catch (e: Exception) { }
                Thread { doRecord(name, urls, maxMs) }.start()
            }
            A_STOP -> stopFlag = true
        }
        return START_NOT_STICKY
    }

    private fun showForeground(name: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Recording", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 4, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(Lang.t(this, "🎙 रेकर्डिङ चलिरहेको छ", "🎙 Recording in progress")).setContentText(name)
            .setOngoing(true).setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Stop", pi(A_STOP)).build())
            .build()
        try {
            startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } catch (e: Exception) {
            nm.notify(ID, n)
        }
    }

    private class Conn(val input: InputStream, val type: String, val close: () -> Unit)

    private fun openUrl(url: String): Conn {
        var cur = url
        for (i in 0 until 6) {
            try {
                val c = URL(cur).openConnection() as HttpURLConnection
                c.connectTimeout = 10000; c.readTimeout = 15000
                c.instanceFollowRedirects = false
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) ShreeGaneshSangeetYantra")
                c.setRequestProperty("Icy-MetaData", "0")
                val code = c.responseCode
                if (code in 300..399) {
                    val loc = c.getHeaderField("Location") ?: throw IOException("redirect")
                    cur = URL(URL(cur), loc).toString(); c.disconnect(); continue
                }
                if (code != 200) { c.disconnect(); throw IOException("HTTP $code") }
                return Conn(c.inputStream, c.contentType ?: "") { c.disconnect() }
            } catch (e: IOException) {
                // old SHOUTcast servers answer "ICY 200 OK", which HttpURLConnection cannot read
                if ((e.message ?: "").contains("ICY") && cur.startsWith("http://")) return openIcy(cur)
                throw e
            }
        }
        throw IOException("too many redirects")
    }

    private fun openIcy(url: String): Conn {
        val u = URL(url)
        val s = Socket(u.host, if (u.port > 0) u.port else 80)
        s.soTimeout = 15000
        val path = if (u.file.isEmpty()) "/" else u.file
        s.getOutputStream().write(("GET $path HTTP/1.0\r\nHost: ${u.host}\r\nUser-Agent: Mozilla/5.0\r\nIcy-MetaData: 0\r\nConnection: close\r\n\r\n").toByteArray())
        val inp = BufferedInputStream(s.getInputStream())
        val sb = StringBuilder()
        var type = ""
        // read header lines until an empty line
        while (true) {
            sb.setLength(0)
            while (true) {
                val b = inp.read()
                if (b < 0 || b == '\n'.code) break
                if (b != '\r'.code) sb.append(b.toChar())
            }
            val line = sb.toString()
            if (line.isEmpty()) break
            if (line.lowercase().startsWith("content-type:")) type = line.substringAfter(':').trim()
        }
        return Conn(inp, type) { try { s.close() } catch (e: Exception) { } }
    }

    private fun doRecord(name: String, urls: List<String>, maxMs: Long) {
        var written = 0L
        var uri: Uri? = null
        var out: OutputStream? = null
        var ext = "mp3"
        var err = ""
        val start = System.currentTimeMillis()
        try {
            if (Build.VERSION.SDK_INT < 29) err = Lang.t(this@RecordService, "Android 10 वा माथि चाहिन्छ", "Android 10 or above is required")
            else if (urls.isEmpty()) err = Lang.t(this@RecordService, "लिंक छैन", "No link")
            else for (u in urls) {
                if (stopFlag) break
                if (Regex("\\.m3u8(\\?|#|$)", RegexOption.IGNORE_CASE).containsMatchIn(u)) { err = Lang.t(this@RecordService, "HLS (.m3u8) रेडियो रेकर्ड हुँदैन", "HLS (.m3u8) radio cannot be recorded"); continue }
                try {
                    val conn = openUrl(u)
                    val ct = conn.type.lowercase()
                    if (ct.contains("mpegurl") || ct.contains("html") || ct.contains("json") || ct.startsWith("text/")) {
                        err = Lang.t(this@RecordService, "यो सिधा आवाज (stream) होइन ($ct)", "This is not a direct audio stream ($ct)"); conn.close(); continue
                    }
                    if (out == null) {
                        ext = when {
                            ct.contains("aac") || ct.contains("mp4") || ct.contains("m4a") -> "aac"
                            ct.contains("ogg") || ct.contains("opus") -> "ogg"
                            else -> "mp3"
                        }
                        val mime = when (ext) { "aac" -> "audio/aac"; "ogg" -> "audio/ogg"; else -> "audio/mpeg" }
                        val stamp = java.text.SimpleDateFormat("yyyyMMdd-HHmm", java.util.Locale.US).format(java.util.Date())
                        val fname = name.replace(Regex("[^A-Za-z0-9_-]"), "_").trim('_').ifEmpty { "radio" } + "-" + stamp + "." + ext
                        val v = ContentValues().apply {
                            put(MediaStore.MediaColumns.DISPLAY_NAME, fname)
                            put(MediaStore.MediaColumns.MIME_TYPE, mime)
                            put(MediaStore.MediaColumns.RELATIVE_PATH, "Music/SGS Recordings")
                            put(MediaStore.MediaColumns.IS_PENDING, 1)
                        }
                        uri = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v)
                        out = uri?.let { contentResolver.openOutputStream(it) }
                        if (out == null) { err = Lang.t(this@RecordService, "फाइल बनाउन सकिएन", "Could not create the file"); conn.close(); break }
                    }
                    val buf = ByteArray(16384)
                    while (!stopFlag) {
                        val n = conn.input.read(buf)
                        if (n < 0) break
                        out!!.write(buf, 0, n)
                        written += n
                        size = written
                        if (maxMs > 0 && System.currentTimeMillis() - start >= maxMs) { stopFlag = true; break }
                        sendProgress()
                    }
                    conn.close()
                    if (written > 0) break // saved what the stream gave us
                } catch (e: Exception) {
                    err = e.javaClass.simpleName + (e.message?.let { ": $it" } ?: "")
                    if (written > 0) break
                }
            }
        } catch (e: Exception) {
            err = e.javaClass.simpleName
        }
        try { out?.flush(); out?.close() } catch (e: Exception) { }
        val rec = JSONObject().put("name", name).put("ts", System.currentTimeMillis()).put("ext", ext)
            .put("dur", (System.currentTimeMillis() - start) / 1000.0).put("size", written)
        if (written > 0 && uri != null) {
            try {
                contentResolver.update(uri!!, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            } catch (e: Exception) { }
            rec.put("ok", true).put("mid", ContentUris.parseId(uri!!))
        } else {
            try { uri?.let { contentResolver.delete(it, null, null) } } catch (e: Exception) { }
            rec.put("ok", false).put("err", err.ifEmpty { Lang.t(this@RecordService, "रेडियोले डेटा दिएन", "The radio sent no data") })
        }
        addDone(this, rec)
        active = false
        try { WidgetUpdater.updateAll(this) } catch (e: Exception) { }
        wake?.takeIf { it.isHeld }?.release()
        wifi?.takeIf { it.isHeld }?.release()
        PlayerBus.js?.invoke("window.__sgsRecDone&&window.__sgsRecDone()")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private var lastProg = 0L
    private fun sendProgress() {
        val now = System.currentTimeMillis()
        if (now - lastProg < 1000) return
        lastProg = now
        PlayerBus.js?.invoke("window.__sgsRecProg&&window.__sgsRecProg(" + size + ")")
    }

    override fun onDestroy() {
        stopFlag = true
        wake?.takeIf { it.isHeld }?.release()
        wifi?.takeIf { it.isHeld }?.release()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
