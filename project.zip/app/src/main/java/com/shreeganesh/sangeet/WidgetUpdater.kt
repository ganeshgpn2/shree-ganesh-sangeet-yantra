package com.shreeganesh.sangeet

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.ZoneId

object WidgetUpdater {
    const val A_TICK = "sgs.W_TICK"

    private fun fmtMs(ms: Long): String {
        val t = ms / 1000
        return if (t >= 3600) String.format("%d:%02d:%02d", t / 3600, (t % 3600) / 60, t % 60)
        else String.format("%d:%02d", t / 60, t % 60)
    }

    /** Shows how long the current item has been playing (counts by itself, no refresh needed). */
    private fun showTime(c: Context, v: RemoteViews, show: Boolean, playing: Boolean, id: Int = R.id.w_time, withTotal: Boolean = true) {
        if (!show) { v.setViewVisibility(id, View.GONE); return }
        v.setViewVisibility(id, View.VISIBLE)
        val now = SystemClock.elapsedRealtime()
        val pos = WidgetState.pos(c)
        val dur = WidgetState.dur(c)
        val fmt = if (withTotal && dur > 0) "%s / " + fmtMs(dur) else "%s"
        val base = if (playing) WidgetState.posAt(c) - pos else now - pos
        v.setChronometer(id, base, fmt, playing)
    }

    private fun cmdPi(c: Context, cmd: String, arg: String = ""): PendingIntent = PendingIntent.getActivity(
        c, (cmd + arg).hashCode(),
        Intent(c, WidgetActionActivity::class.java).setAction("w.$cmd.$arg")
            .putExtra("cmd", cmd).putExtra("arg", arg),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun updateAll(c: Context) {
        val mgr = AppWidgetManager.getInstance(c)
        fun ids(cls: Class<*>) = mgr.getAppWidgetIds(ComponentName(c, cls))
        ids(MusicWidget::class.java).let { if (it.isNotEmpty()) mgr.updateAppWidget(it, music(c)) }
        ids(FavWidget::class.java).let { if (it.isNotEmpty()) mgr.updateAppWidget(it, fav(c)) }
        ids(ClockWidget::class.java).let { if (it.isNotEmpty()) mgr.updateAppWidget(it, clock(c)) }
        ids(CassetteWidget::class.java).let { if (it.isNotEmpty()) mgr.updateAppWidget(it, cassette(c)) }
    }

    /** Widget 1: songs stored on the phone (device music). */
    private fun music(c: Context): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_music)
        val playingDev = WidgetState.playing(c) && WidgetState.kind(c) == "a"
        val key = WidgetState.devKey(c)
        val title = WidgetState.devTitle(c).ifEmpty { "फोनका गीत" }
        val sub = WidgetState.devSub(c)
        val path = key.removePrefix("ms:a").toLongOrNull()?.let { MediaScanner.audioPath(c, it) } ?: ""
        v.setTextViewText(R.id.w_path, if (path.isNotEmpty()) "📁 $path" else "")
        v.setTextViewText(R.id.w_title, title)
        v.setTextViewText(
            R.id.w_status,
            (if (playingDev) "▶ बज्दैछ" else "⏸ रोकिएको") + " · Music" + (if (sub.isNotEmpty()) " · $sub" else "")
        )
        v.setImageViewResource(R.id.w_play, if (playingDev) R.drawable.ic_w_pause else R.drawable.ic_w_play)
        showTime(c, v, WidgetState.kind(c) == "a" && WidgetState.key(c) == key && key.isNotEmpty(), playingDev)
        v.setOnClickPendingIntent(R.id.w_prev, cmdPi(c, "dprev", key))
        v.setOnClickPendingIntent(R.id.w_play, cmdPi(c, "dplay", key))
        v.setOnClickPendingIntent(R.id.w_next, cmdPi(c, "dnext", key))
        v.setOnClickPendingIntent(R.id.w_logo, cmdPi(c, "open"))
        v.setOnClickPendingIntent(R.id.w_title, cmdPi(c, "open"))
        return v
    }

    private fun fav(c: Context): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_fav)
        val favs = WidgetState.favs(c)
        if (favs.isEmpty()) {
            v.setTextViewText(R.id.w_title, "मनपर्ने रेडियो छैन")
            v.setTextViewText(R.id.w_status, "रेडियोको ⭐ थिच्नुहोस्")
            v.setTextViewText(R.id.w_link, "")
            v.setImageViewResource(R.id.w_play, R.drawable.ic_w_play)
            v.setViewVisibility(R.id.w_time, View.GONE)
            val open = cmdPi(c, "open")
            listOf(R.id.w_prev, R.id.w_play, R.id.w_next, R.id.w_logo, R.id.w_title).forEach { v.setOnClickPendingIntent(it, open) }
            return v
        }
        val cur = if (WidgetState.kind(c) == "r" && WidgetState.key(c).isNotEmpty()) WidgetState.key(c) else WidgetState.lastRadio(c)
        var idx = favs.indexOfFirst { it.key == cur }
        if (idx < 0) idx = WidgetState.favIdx(c).coerceIn(0, favs.size - 1)
        val st = favs[idx]
        val n = favs.size
        val prev = favs[(idx - 1 + n) % n]
        val next = favs[(idx + 1) % n]
        val isPlayingThis = WidgetState.playing(c) && WidgetState.kind(c) == "r" && WidgetState.key(c) == st.key
        val f = WidgetState.freqOf(c, st.key)
        v.setTextViewText(R.id.w_title, st.name)
        v.setTextViewText(R.id.w_link, if (st.key.startsWith("http")) "🔗 " + st.key else "")
        v.setTextViewText(
            R.id.w_status,
            (if (isPlayingThis) "▶ " else "⏸ ") + (if (f.isNotEmpty()) "$f MHz" else "FM") +
                (if (st.cat.isNotEmpty()) " · " + st.cat else "")
        )
        v.setImageViewResource(R.id.w_play, if (isPlayingThis) R.drawable.ic_w_pause else R.drawable.ic_w_play)
        showTime(c, v, WidgetState.kind(c) == "r" && WidgetState.key(c) == st.key, isPlayingThis)
        v.setOnClickPendingIntent(R.id.w_prev, cmdPi(c, "playfav", prev.key))
        v.setOnClickPendingIntent(R.id.w_next, cmdPi(c, "playfav", next.key))
        v.setOnClickPendingIntent(R.id.w_play, if (isPlayingThis) cmdPi(c, "toggle") else cmdPi(c, "playfav", st.key))
        v.setOnClickPendingIntent(R.id.w_logo, cmdPi(c, "open"))
        v.setOnClickPendingIntent(R.id.w_title, cmdPi(c, "open"))
        return v
    }

    private fun clock(c: Context): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_clock)
        v.setTextViewText(R.id.w_date, BsDate.text())
        val today = LocalDate.now()
        val fest = NepaliCal.festival(today)
        v.setTextViewText(R.id.w_event, "≈ " + NepaliCal.tithiText(today) + (if (fest.isNotEmpty()) " · $fest" else ""))
        val next = AlarmScheduler.nextAlarmMillis(c)
        if (next > 0) {
            val cal = java.util.Calendar.getInstance().apply { timeInMillis = next }
            val d = cal.toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
            val today = LocalDate.now()
            val day = when (d) { today -> "आज"; today.plusDays(1) -> "भोलि"; else -> BsDate.weekdayName(d) }
            v.setTextViewText(R.id.w_alarm, String.format("⏰ अर्को Alarm: %02d:%02d · %s", cal.get(java.util.Calendar.HOUR_OF_DAY), cal.get(java.util.Calendar.MINUTE), day))
            v.setTextViewText(R.id.w_astate, "चालु")
            v.setTextColor(R.id.w_astate, Color.parseColor("#7CFC9A"))
        } else {
            v.setTextViewText(R.id.w_alarm, "⏰ कुनै Alarm छैन")
            v.setTextViewText(R.id.w_astate, "बन्द")
            v.setTextColor(R.id.w_astate, Color.parseColor("#FF8A80"))
        }
        val open = cmdPi(c, "openalarm")
        v.setOnClickPendingIntent(R.id.w_bell, open)
        v.setOnClickPendingIntent(R.id.w_root, open)
        v.setOnClickPendingIntent(R.id.w_alarm, open)
        v.setOnClickPendingIntent(R.id.w_date, open)
        return v
    }

    /** Widget 4: the big cassette player (same look as the Now Playing screen). */
    private fun cassette(c: Context): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_cassette)
        val playing = WidgetState.playing(c)
        val title = WidgetState.title(c)
        v.setTextViewText(R.id.ck_track, if (title.isEmpty()) "श्री गणेश संगीत यन्त्र" else "♪ $title")
        // moving parts only while playing
        val on = if (playing) View.VISIBLE else View.GONE
        val off = if (playing) View.GONE else View.VISIBLE
        v.setViewVisibility(R.id.ck_reel_l_on, on); v.setViewVisibility(R.id.ck_reel_r_on, on); v.setViewVisibility(R.id.ck_vis_on, on)
        v.setViewVisibility(R.id.ck_reel_l_off, off); v.setViewVisibility(R.id.ck_reel_r_off, off); v.setViewVisibility(R.id.ck_vis_off, off)
        v.setImageViewResource(R.id.ck_led_play, if (playing) R.drawable.ck_led_play_on else R.drawable.ck_led_play_off)
        v.setImageViewResource(R.id.ck_led_rec, if (RecordService.active) R.drawable.ck_led_rec_on else R.drawable.ck_led_rec_off)
        v.setImageViewResource(R.id.ck_k_play, if (playing) R.drawable.ck_ic_pause else R.drawable.ck_ic_play)
        showTime(c, v, true, playing, R.id.ck_time, false)
        v.setOnClickPendingIntent(R.id.ck_k_rec, cmdPi(c, "ck_rec"))
        v.setOnClickPendingIntent(R.id.ck_k_prev, cmdPi(c, "ck_prev"))
        v.setOnClickPendingIntent(R.id.ck_k_rew, cmdPi(c, "ck_rew"))
        v.setOnClickPendingIntent(R.id.ck_k_play, cmdPi(c, "ck_toggle"))
        v.setOnClickPendingIntent(R.id.ck_k_ff, cmdPi(c, "ck_ff"))
        v.setOnClickPendingIntent(R.id.ck_k_next, cmdPi(c, "ck_next"))
        v.setOnClickPendingIntent(R.id.ck_k_stop, cmdPi(c, "ck_stop"))
        v.setOnClickPendingIntent(R.id.ck_track, cmdPi(c, "open"))
        return v
    }

    /** Refresh the date a few seconds after midnight. */
    fun scheduleMidnight(c: Context) {
        try {
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val t = LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli() + 5000
            val pi = PendingIntent.getBroadcast(
                c, 9001, Intent(c, ClockWidget::class.java).setAction(A_TICK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            am.setAndAllowWhileIdle(AlarmManager.RTC, t, pi)
        } catch (e: Exception) { }
    }
}
