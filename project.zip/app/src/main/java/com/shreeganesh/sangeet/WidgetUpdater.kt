package com.shreeganesh.sangeet

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.ZoneId

object WidgetUpdater {
    const val A_TICK = "sgs.W_TICK"

    private fun fmtMs(ms: Long): String {
        val t = ms / 1000
        return if (t >= 3600) String.format("%d:%02d:%02d", t / 3600, (t % 3600) / 60, t % 60)
        else String.format("%d:%02d", t / 60, t % 60)
    }

    /** Shows how long the current item has been playing (counts by itself, no refresh needed). */
    private fun showTime(c: Context, v: RemoteViews, show: Boolean, playing: Boolean, id: Int = R.id.w_time, withTotal: Boolean = true) {
        if (!show) { v.setViewVisibility(id, View.GONE); return }
        v.setViewVisibility(id, View.VISIBLE)
        val now = SystemClock.elapsedRealtime()
        val pos = WidgetState.pos(c)
        val dur = WidgetState.dur(c)
        val fmt = if (withTotal && dur > 0) "%s / " + fmtMs(dur) else "%s"
        val base = if (playing) WidgetState.posAt(c) - pos else now - pos
        v.setChronometer(id, base, fmt, playing)
    }

    private fun cmdPi(c: Context, cmd: String, arg: String = ""): PendingIntent = PendingIntent.getActivity(
        c, (cmd + arg).hashCode(),
        Intent(c, WidgetActionActivity::class.java).setAction("w.$cmd.$arg")
            .putExtra("cmd", cmd).putExtra("arg", arg),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun updateAll(c: Context) {
        val mgr = AppWidgetManager.getInstance(c)
        fun ids(cls: Class<*>) = mgr.getAppWidgetIds(ComponentName(c, cls))
        ids(MusicWidget::class.java).let { if (it.isNotEmpty()) mgr.updateAppWidget(it, music(c)) }
        ids(FavWidget::class.java).let { if (it.isNotEmpty()) mgr.updateAppWidget(it, fav(c)) }
        ids(ClockWidget::class.java).let { if (it.isNotEmpty()) mgr.updateAppWidget(it, clock(c)) }
        // the cassette widget is drawn per widget id, because every widget may have a different size
        ids(CassetteWidget::class.java).forEach { id -> mgr.updateAppWidget(id, cassette(c, mgr.getAppWidgetOptions(id))) }
    }

    /** Widget 1: songs stored on the phone (device music). */
    private fun music(c: Context): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_music)
        val playingDev = WidgetState.playing(c) && WidgetState.kind(c) == "a"
        val key = WidgetState.devKey(c)
        val title = WidgetState.devTitle(c).ifEmpty { "फोनका गीत" }
        val sub = WidgetState.devSub(c)
        val path = key.removePrefix("ms:a").toLongOrNull()?.let { MediaScanner.audioPath(c, it) } ?: ""
        v.setTextViewText(R.id.w_path, if (path.isNotEmpty()) "📁 $path" else "")
        v.setTextViewText(R.id.w_title, title)
        v.setTextViewText(
            R.id.w_status,
            (if (playingDev) "▶ बज्दैछ" else "⏸ रोकिएको") + " · Music" + (if (sub.isNotEmpty()) " · $sub" else "")
        )
        v.setImageViewResource(R.id.w_play, if (playingDev) R.drawable.ic_w_pause else R.drawable.ic_w_play)
        showTime(c, v, WidgetState.kind(c) == "a" && WidgetState.key(c) == key && key.isNotEmpty(), playingDev)
        v.setOnClickPendingIntent(R.id.w_prev, cmdPi(c, "dprev", key))
        v.setOnClickPendingIntent(R.id.w_play, cmdPi(c, "dplay", key))
        v.setOnClickPendingIntent(R.id.w_next, cmdPi(c, "dnext", key))
        v.setOnClickPendingIntent(R.id.w_logo, cmdPi(c, "open"))
        v.setOnClickPendingIntent(R.id.w_title, cmdPi(c, "open"))
        return v
    }

    private fun fav(c: Context): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_fav)
        val favs = WidgetState.favs(c)
        if (favs.isEmpty()) {
            v.setTextViewText(R.id.w_title, "मनपर्ने रेडियो छैन")
            v.setTextViewText(R.id.w_status, "रेडियोको ⭐ थिच्नुहोस्")
            v.setTextViewText(R.id.w_link, "")
            v.setImageViewResource(R.id.w_play, R.drawable.ic_w_play)
            v.setViewVisibility(R.id.w_time, View.GONE)
            val open = cmdPi(c, "open")
            listOf(R.id.w_prev, R.id.w_play, R.id.w_next, R.id.w_logo, R.id.w_title).forEach { v.setOnClickPendingIntent(it, open) }
            return v
        }
        val cur = if (WidgetState.kind(c) == "r" && WidgetState.key(c).isNotEmpty()) WidgetState.key(c) else WidgetState.lastRadio(c)
        var idx = favs.indexOfFirst { it.key == cur }
        if (idx < 0) idx = WidgetState.favIdx(c).coerceIn(0, favs.size - 1)
        val st = favs[idx]
        val n = favs.size
        val prev = favs[(idx - 1 + n) % n]
        val next = favs[(idx + 1) % n]
        val isPlayingThis = WidgetState.playing(c) && WidgetState.kind(c) == "r" && WidgetState.key(c) == st.key
        val f = WidgetState.freqOf(c, st.key)
        v.setTextViewText(R.id.w_title, st.name)
        v.setTextViewText(R.id.w_link, if (st.key.startsWith("http")) "🔗 " + st.key else "")
        v.setTextViewText(
            R.id.w_status,
            (if (isPlayingThis) "▶ " else "⏸ ") + (if (f.isNotEmpty()) "$f MHz" else "FM") +
                (if (st.cat.isNotEmpty()) " · " + st.cat else "")
        )
        v.setImageViewResource(R.id.w_play, if (isPlayingThis) R.drawable.ic_w_pause else R.drawable.ic_w_play)
        showTime(c, v, WidgetState.kind(c) == "r" && WidgetState.key(c) == st.key, isPlayingThis)
        v.setOnClickPendingIntent(R.id.w_prev, cmdPi(c, "playfav", prev.key))
        v.setOnClickPendingIntent(R.id.w_next, cmdPi(c, "playfav", next.key))
        v.setOnClickPendingIntent(R.id.w_play, if (isPlayingThis) cmdPi(c, "toggle") else cmdPi(c, "playfav", st.key))
        v.setOnClickPendingIntent(R.id.w_logo, cmdPi(c, "open"))
        v.setOnClickPendingIntent(R.id.w_title, cmdPi(c, "open"))
        return v
    }

    private fun clock(c: Context): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_clock)
        v.setTextViewText(R.id.w_date, BsDate.text())
        val today = LocalDate.now()
        val fest = NepaliCal.festival(today)
        v.setTextViewText(R.id.w_event, "≈ " + NepaliCal.tithiText(today) + (if (fest.isNotEmpty()) " · $fest" else ""))
        val next = AlarmScheduler.nextAlarmMillis(c)
        if (next > 0) {
            val cal = java.util.Calendar.getInstance().apply { timeInMillis = next }
            val d = cal.toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
            val today = LocalDate.now()
            val day = when (d) { today -> "आज"; today.plusDays(1) -> "भोलि"; else -> BsDate.weekdayName(d) }
            v.setTextViewText(R.id.w_alarm, String.format("⏰ अर्को Alarm: %02d:%02d · %s", cal.get(java.util.Calendar.HOUR_OF_DAY), cal.get(java.util.Calendar.MINUTE), day))
            v.setTextViewText(R.id.w_astate, "चालु")
            v.setTextColor(R.id.w_astate, Color.parseColor("#7CFC9A"))
        } else {
            v.setTextViewText(R.id.w_alarm, "⏰ कुनै Alarm छैन")
            v.setTextViewText(R.id.w_astate, "बन्द")
            v.setTextColor(R.id.w_astate, Color.parseColor("#FF8A80"))
        }
        val open = cmdPi(c, "openalarm")
        v.setOnClickPendingIntent(R.id.w_bell, open)
        v.setOnClickPendingIntent(R.id.w_root, open)
        v.setOnClickPendingIntent(R.id.w_alarm, open)
        v.setOnClickPendingIntent(R.id.w_date, open)
        return v
    }

    private val SKIN_BG = intArrayOf(
        R.drawable.ck_bg0, R.drawable.ck_bg1, R.drawable.ck_bg2, R.drawable.ck_bg3, R.drawable.ck_bg4,
        R.drawable.ck_bg5, R.drawable.ck_bg6, R.drawable.ck_bg7, R.drawable.ck_bg8, R.drawable.ck_bg9
    )
    private val PACK = intArrayOf(
        R.drawable.ck_pack0, R.drawable.ck_pack1, R.drawable.ck_pack2, R.drawable.ck_pack3,
        R.drawable.ck_pack4, R.drawable.ck_pack5, R.drawable.ck_pack6, R.drawable.ck_pack7
    )
    /** Tape pack size for a song position (0..1): the left (supply) pack shrinks, the right (take-up) pack grows, like a real cassette. */
    fun packLevelOf(progress: Double): Int = Math.round(progress.coerceIn(0.0, 1.0) * (PACK.size - 1)).toInt()

    private fun packLevel(c: Context, left: Boolean): Int {
        val now = SystemClock.elapsedRealtime()
        val posMs = WidgetState.pos(c) + (if (WidgetState.playing(c)) now - WidgetState.posAt(c) else 0L)
        val dur = WidgetState.dur(c)
        val lv = if (WidgetState.kind(c) == "a" && dur > 0) {
            packLevelOf(posMs.toDouble() / dur)                    // phone song: real progress
        } else {                                                    // live radio has no end: slow 70 s ping-pong like Now Playing
            val ph = (posMs / 1000.0) % 140.0
            packLevelOf(if (ph < 70.0) ph / 70.0 else (140.0 - ph) / 70.0)
        }
        return if (left) PACK.size - 1 - lv else lv
    }

    /** Fast-forward (dir=1) / rewind (dir=-1) pressed: reels wind fast for a moment, then go back to normal speed. */
    fun wind(c: Context, dir: Int) {
        val app = c.applicationContext
        WidgetState.setWind(app, dir, SystemClock.elapsedRealtime() + 2500)
        updateAll(app)
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ try { updateAll(app) } catch (e: Exception) { } }, 2600)
    }

    private val CLOCKS = intArrayOf(
        R.id.ck_clk1, R.id.ck_clk2, R.id.ck_clk3, R.id.ck_clk4, R.id.ck_clk5,
        R.id.ck2_clk6, R.id.ck2_clk7, R.id.ck2_clk8, R.id.ck2_clk9, R.id.ck2_clk10
    )
    /** track / time colour of each CD skin (same as the Now Playing SVG) */
    private val CD_ACCENT = intArrayOf(0xFF8FE3FF.toInt(), 0xFFA9D0FF.toInt(), 0xFFFFD6A0.toInt(), 0xFFA5F5EC.toInt(), 0xFFFFE9A8.toInt())
    /** every CD skin has its own disc artwork: one still image + one spinning flipper per skin */
    private val CD_ON = intArrayOf(R.id.ck_cd_on5, R.id.ck_cd_on6, R.id.ck_cd_on7, R.id.ck_cd_on8, R.id.ck_cd_on9)
    private val CD_OFF = intArrayOf(R.id.ck_cd_off5, R.id.ck_cd_off6, R.id.ck_cd_off7, R.id.ck_cd_off8, R.id.ck_cd_off9)

    /**
     * The widget art is a 360 x 322 design (same as the Now Playing screen). Android stretches a layout to whatever size the
     * user gave the widget, which made the wheels oval and everything bigger than Now Playing. So the layout is letter-boxed
     * (padding on the root) to keep exactly 360 : 322 whatever the widget size is.
     */
    private fun fitAspect(c: Context, v: RemoteViews, o: Bundle?) {
        if (o == null) return
        val land = c.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val w = (if (land) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH) else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH)).toFloat()
        val h = (if (land) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT) else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT)).toFloat()
        if (w <= 0f || h <= 0f) return
        val ratio = 360f / 322f
        var px = 0f
        var py = 0f
        if (w / h > ratio) px = (w - h * ratio) / 2f else py = (h - w / ratio) / 2f
        val d = c.resources.displayMetrics.density
        v.setViewPadding(R.id.w_root, (px * d).toInt(), (py * d).toInt(), (px * d).toInt(), (py * d).toInt())
    }

    /** Widget 4: the big cassette / CD player. Same 10 skins as the Now Playing screen; the round button on top cycles them. */
    private fun cassette(c: Context, opts: Bundle? = null): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_cassette)
        fitAspect(c, v, opts)
        val skin = WidgetState.skin(c)
        val isCd = skin >= 5
        val playing = WidgetState.playing(c)
        val title = WidgetState.title(c)
        val isRadio = WidgetState.kind(c) == "r" && title.isNotEmpty()
        v.setImageViewResource(R.id.ck_bg, SKIN_BG[skin])
        v.setTextViewText(R.id.ck_skin_n, "${skin + 1}/${WidgetState.SKINS}")
        v.setOnClickPendingIntent(R.id.ck_skin, cmdPi(c, "ck_skin"))
        // one analog clock face per skin (skin 1 = Devanagari numerals); each has hour, minute and second hands
        for (i in CLOCKS.indices) v.setViewVisibility(CLOCKS[i], if (i == skin) View.VISIBLE else View.GONE)
        v.setViewVisibility(R.id.ck_tape_g, if (isCd) View.GONE else View.VISIBLE)
        v.setViewVisibility(R.id.ck_cd_g, if (isCd) View.VISIBLE else View.GONE)
        val on = if (playing) View.VISIBLE else View.GONE
        val off = if (playing) View.GONE else View.VISIBLE
        val ledP = if (playing) R.drawable.ck_led_play_on else R.drawable.ck_led_play_off
        val ledR = if (RecordService.active) R.drawable.ck_led_rec_on else R.drawable.ck_led_rec_off
        if (isCd) {
            val ac = CD_ACCENT[skin - 5]
            v.setTextColor(R.id.ck2_track, ac); v.setTextColor(R.id.ck2_time, ac)
            v.setTextViewText(R.id.ck2_track, "▾ " + (if (title.isEmpty()) "गीत / रेडियो छान्नुहोस्" else if (isRadio) "● LIVE · $title" else "♪ $title"))
            for (i in CD_ON.indices) {
                v.setViewVisibility(CD_ON[i], if (i == skin - 5 && playing) View.VISIBLE else View.GONE)
                v.setViewVisibility(CD_OFF[i], if (i == skin - 5 && !playing) View.VISIBLE else View.GONE)
            }
            v.setImageViewResource(R.id.ck2_led_play, ledP); v.setImageViewResource(R.id.ck2_led_rec, ledR)
            showTime(c, v, true, playing, R.id.ck2_time, false)
            v.setOnClickPendingIntent(R.id.ck2_track, cmdPi(c, "ck_pick"))
        } else {
            v.setTextViewText(R.id.ck_track, "▾ " + (if (title.isEmpty()) "गीत / रेडियो छान्नुहोस्" else "♪ $title"))
            if (isRadio) {
                val f = WidgetState.freqOf(c, WidgetState.key(c))
                v.setTextViewText(R.id.ck_side, "● LIVE")
                v.setTextViewText(R.id.ck_dur, if (f.isNotEmpty()) "FM $f MHz" else "FM")
            } else {
                val d = WidgetState.dur(c)
                v.setTextViewText(R.id.ck_side, "SIDE A")
                v.setTextViewText(R.id.ck_dur, if (title.isNotEmpty() && d > 0) fmtMs(d) else "")
            }
            v.setImageViewResource(R.id.ck_pack_l, PACK[packLevel(c, true)]); v.setImageViewResource(R.id.ck_pack_r, PACK[packLevel(c, false)])
            val wind = if (playing) WidgetState.windDir(c) else 0
            // Now Playing turns the reels at a constant speed (left 1.4 s per turn, right 1.9 s per turn); only FF / REW are faster
            val norm = if (playing && wind == 0) View.VISIBLE else View.GONE
            v.setViewVisibility(R.id.ck_reel_l_s, norm); v.setViewVisibility(R.id.ck_reel_r_s, norm)
            val fwd = if (playing && wind > 0) View.VISIBLE else View.GONE
            val back = if (playing && wind < 0) View.VISIBLE else View.GONE
            v.setViewVisibility(R.id.ck_reel_l_ff, fwd); v.setViewVisibility(R.id.ck_reel_r_ff, fwd)
            v.setViewVisibility(R.id.ck_reel_l_rw, back); v.setViewVisibility(R.id.ck_reel_r_rw, back)
            v.setViewVisibility(R.id.ck_reel_l_off, off); v.setViewVisibility(R.id.ck_reel_r_off, off)
            v.setImageViewResource(R.id.ck_led_play, ledP); v.setImageViewResource(R.id.ck_led_rec, ledR)
            showTime(c, v, true, playing, R.id.ck_time, false)
            v.setOnClickPendingIntent(R.id.ck_track, cmdPi(c, "ck_pick"))
        }
        v.setImageViewResource(R.id.ck_k_play, if (playing) R.drawable.ck_ic_pause else R.drawable.ck_ic_play)
        v.setOnClickPendingIntent(R.id.ck_k_rec, cmdPi(c, "ck_rec"))
        v.setOnClickPendingIntent(R.id.ck_k_prev, cmdPi(c, "ck_prev"))
        v.setOnClickPendingIntent(R.id.ck_k_rew, cmdPi(c, "ck_rew"))
        v.setOnClickPendingIntent(R.id.ck_k_play, cmdPi(c, "ck_toggle"))
        v.setOnClickPendingIntent(R.id.ck_k_ff, cmdPi(c, "ck_ff"))
        v.setOnClickPendingIntent(R.id.ck_k_next, cmdPi(c, "ck_next"))
        v.setOnClickPendingIntent(R.id.ck_k_stop, cmdPi(c, "ck_stop"))
        return v
    }

    /** Refresh the date a few seconds after midnight. */
    fun scheduleMidnight(c: Context) {
        try {
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val t = LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli() + 5000
            val pi = PendingIntent.getBroadcast(
                c, 9001, Intent(c, ClockWidget::class.java).setAction(A_TICK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            am.setAndAllowWhileIdle(AlarmManager.RTC, t, pi)
        } catch (e: Exception) { }
    }
}
