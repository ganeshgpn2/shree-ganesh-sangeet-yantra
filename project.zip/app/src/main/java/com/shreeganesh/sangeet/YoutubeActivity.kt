package com.shreeganesh.sangeet

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.HorizontalScrollView
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

/**
 * YouTube video वा playlist link paste गर्दा आफैँ बज्ने, नाम राखेर Save गर्न मिल्ने screen.
 * Target string: "v:<videoId>" वा "p:<playlistId>"
 */
class YoutubeActivity : Activity() {

    private class Item(var name: String, val id: String)

    private var plWeb: WebView? = null
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var lastTarget: String? = null
    private val items = ArrayList<Item>()
    private lateinit var adapter: ArrayAdapter<Item>

    // playlist क्रम-संख्या block (१–१०, ११–२० ...) र रोकिएको ठाउँबाट फेरि बजाउने
    private var total = 0
    private var cur = 0
    private var page = 0
    private var panel: LinearLayout? = null
    private var tabs: LinearLayout? = null
    private val cells = ArrayList<Button>()
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable { override fun run() { poll(); handler.postDelayed(this, 2000) } }
    private var dpf = 1f

    private val prefs by lazy { getSharedPreferences("sgs_youtube", Context.MODE_PRIVATE) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#121417")) }

        // top bar
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#4682b4")); setPadding(dp(8), dp(28), dp(8), dp(8))
        }
        val back = Button(this).apply { text = "←"; setTextColor(Color.WHITE); setBackgroundColor(Color.TRANSPARENT); textSize = 22f; setOnClickListener { finish() } }
        val title = TextView(this).apply { text = "YOUTUBE"; setTextColor(Color.WHITE); textSize = 18f }
        bar.addView(back, LinearLayout.LayoutParams(dp(56), dp(48)))
        bar.addView(title)
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))

        // link row
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(12), dp(10), dp(12), 0) }
        val etLink = EditText(this).apply {
            hint = Lang.t(this@YoutubeActivity, "Video वा Playlist link paste गर्नुहोस्", "Paste a Video or Playlist link"); setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            setSingleLine(); imeOptions = EditorInfo.IME_ACTION_GO
        }
        val go = Button(this).apply { text = "PLAY" }
        row1.addView(etLink, LinearLayout.LayoutParams(0, -2, 1f))
        row1.addView(go, LinearLayout.LayoutParams(-2, -2))
        root.addView(row1, LinearLayout.LayoutParams(-1, -2))

        // name + save row
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(12), 0, dp(12), 0) }
        val etName = EditText(this).apply {
            hint = Lang.t(this@YoutubeActivity, "यो link को नाम (Save गर्न)", "Name for this link (to save)"); setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            setSingleLine(); imeOptions = EditorInfo.IME_ACTION_DONE
        }
        val save = Button(this).apply { text = "SAVE" }
        row2.addView(etName, LinearLayout.LayoutParams(0, -2, 1f))
        row2.addView(save, LinearLayout.LayoutParams(-2, -2))
        root.addView(row2, LinearLayout.LayoutParams(-1, -2))

        // player area (16:9): एउटै WebView ले video र playlist दुवै चलाउँछ
        val box = FrameLayout(this)
        val web = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            webViewClient = WebViewClient()
            webChromeClient = object : WebChromeClient() {
                override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                    if (customView != null) { cb.onCustomViewHidden(); return }
                    customView = view; customCb = cb
                    (window.decorView as FrameLayout).addView(view, FrameLayout.LayoutParams(-1, -1))
                }
                override fun onHideCustomView() {
                    customView?.let { (window.decorView as FrameLayout).removeView(it) }
                    customView = null; customCb?.onCustomViewHidden(); customCb = null
                }
            }
        }
        plWeb = web
        box.addView(web, FrameLayout.LayoutParams(-1, -1))
        val h = resources.displayMetrics.widthPixels * 9 / 16
        root.addView(box, LinearLayout.LayoutParams(-1, h).apply { topMargin = dp(8) })

        // क्रम-संख्या block panel (playlist बजेको बेला मात्र देखिन्छ)
        dpf = d
        val pn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE; setPadding(dp(8), dp(6), dp(8), 0) }
        val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val tb = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        hs.addView(tb)
        pn.addView(hs, LinearLayout.LayoutParams(-1, -2))
        for (r in 0 until 2) {
            val gr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until 5) {
                val b = Button(this).apply { textSize = 15f; setPadding(0, 0, 0, 0); minWidth = 0; minHeight = 0; isAllCaps = false }
                val k = r * 5 + c
                b.setOnClickListener { gotoIndex(page * 10 + k) }
                cells.add(b)
                gr.addView(b, LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
            }
            pn.addView(gr, LinearLayout.LayoutParams(-1, -2))
        }
        panel = pn; tabs = tb
        root.addView(pn, LinearLayout.LayoutParams(-1, -2))

        // saved list
        val head = TextView(this).apply {
            text = Lang.t(this@YoutubeActivity, "सुरक्षित (थिच्दा बज्छ · लामो थिच्दा नाम बदल्ने/मेट्ने)", "Saved (tap to play · long-press to rename/delete)")
            setTextColor(Color.LTGRAY); textSize = 13f; setPadding(dp(14), dp(10), dp(14), dp(4))
        }
        root.addView(head, LinearLayout.LayoutParams(-1, -2))
        val list = ListView(this).apply { divider = null }
        adapter = object : ArrayAdapter<Item>(this, android.R.layout.simple_list_item_1, items) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent) as TextView
                val it = items[position]
                v.text = (if (it.id.startsWith("p:")) "☰  " else "▶  ") + it.name
                v.setTextColor(Color.WHITE); v.textSize = 16f; v.setPadding(dp(14), dp(12), dp(14), dp(12))
                return v
            }
        }
        list.adapter = adapter
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        loadItems()

        fun hideKb() = (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(etLink.windowToken, 0)

        fun playTarget(t: String) {
            lastTarget = t
            total = 0; cur = 0; page = 0
            val id = t.substring(2)
            val pos = getPos(t)
            val idx = pos?.optInt("i", 0) ?: 0
            val st = pos?.optDouble("t", 0.0)?.toInt() ?: 0
            if (t.startsWith("p:")) {
                cur = idx; page = idx / 10
                panel?.visibility = View.VISIBLE; buildTabs()
                loadPlaylist(id, idx, st)
            } else {
                panel?.visibility = View.GONE
                // YouTube ले embed गर्ने app चिन्न Referer माग्छ (नत्र Error 152/153)
                val u = "https://www.youtube.com/embed/$id?autoplay=1&playsinline=1&rel=0" + (if (st >= 5) "&start=$st" else "")
                web.loadUrl(u, mapOf("Referer" to "https://$packageName"))
            }
        }

        fun play() {
            val t = parseTarget(etLink.text.toString().trim())
            if (t == null) { Toast.makeText(this, Lang.t(this@YoutubeActivity, "Link मिलेन", "Link not recognised"), Toast.LENGTH_SHORT).show(); return }
            hideKb(); playTarget(t)
        }

        go.setOnClickListener { play() }
        etLink.setOnEditorActionListener { _, a, _ -> if (a == EditorInfo.IME_ACTION_GO) { play(); true } else false }

        // link paste गर्नासाथ आफैँ बजाउने
        etLink.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val txt = s.toString().trim()
                val t = if (txt.length > 11) parseTarget(txt) else null
                if (t != null && t != lastTarget) { hideKb(); playTarget(t) }
            }
        })

        save.setOnClickListener {
            val t = parseTarget(etLink.text.toString().trim())
            if (t == null) { Toast.makeText(this, Lang.t(this@YoutubeActivity, "पहिले मान्य link राख्नुहोस्", "Enter a valid link first"), Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val name = etName.text.toString().trim().ifEmpty { (if (t.startsWith("p:")) "Playlist " else "YouTube ") + t.substring(2).take(11) }
            val old = items.find { it.id == t }
            if (old != null) old.name = name else items.add(0, Item(name, t))
            saveItems(); adapter.notifyDataSetChanged()
            etName.setText(""); hideKb()
            Toast.makeText(this, Lang.t(this@YoutubeActivity, "Save भयो: $name", "Saved: $name"), Toast.LENGTH_SHORT).show()
        }

        list.setOnItemClickListener { _, _, pos, _ ->
            val it = items[pos]
            etLink.setText(linkOf(it.id))
            etLink.setSelection(etLink.text.length)
            playTarget(it.id)
        }

        list.setOnItemLongClickListener { _, _, pos, _ ->
            val it = items[pos]
            AlertDialog.Builder(this).setTitle(it.name)
                .setItems(arrayOf(Lang.t(this@YoutubeActivity, "नाम बदल्ने", "Rename"), Lang.t(this@YoutubeActivity, "मेट्ने", "Delete"))) { _, which ->
                    if (which == 0) {
                        val e = EditText(this).apply { setText(it.name); setSelection(text.length) }
                        AlertDialog.Builder(this).setTitle(Lang.t(this@YoutubeActivity, "नयाँ नाम", "New name")).setView(e)
                            .setPositiveButton("OK") { _, _ ->
                                val n = e.text.toString().trim()
                                if (n.isNotEmpty()) { it.name = n; saveItems(); adapter.notifyDataSetChanged() }
                            }.setNegativeButton(Lang.t(this@YoutubeActivity, "रद्द", "Cancel"), null).show()
                    } else {
                        items.remove(it); saveItems(); adapter.notifyDataSetChanged()
                    }
                }.show()
            true
        }

        setContentView(root)
    }

    private fun loadPlaylist(id: String, index: Int, start: Int) {
        val u = "https://www.youtube.com/embed/videoseries?list=$id&autoplay=1&playsinline=1&rel=0" +
            (if (index > 0) "&index=$index" else "") + (if (start >= 5) "&start=$start" else "")
        plWeb?.loadUrl(u, mapOf("Referer" to "https://$packageName"))
    }

    private fun getPos(t: String): JSONObject? = try { JSONObject(prefs.getString("pos", "{}")!!).optJSONObject(t) } catch (e: Exception) { null }

    private fun savePos(t: String, i: Int, sec: Double) {
        try {
            val o = JSONObject(prefs.getString("pos", "{}")!!)
            if (i < 0 && sec <= 0) o.remove(t) else o.put(t, JSONObject().put("i", maxOf(i, 0)).put("t", sec))
            prefs.edit().putString("pos", o.toString()).apply()
        } catch (e: Exception) { }
    }

    /** क्रम-संख्या block थिचेपछि त्यही episode बजाउने */
    private fun gotoIndex(i: Int) {
        val t = lastTarget ?: return
        if (!t.startsWith("p:") || i >= total) return
        cur = i; page = i / 10; refreshBlocks(); savePos(t, i, 0.0)
        val js = "(function(){var p=document.getElementById('movie_player');if(p&&p.playVideoAt){p.playVideoAt($i);return 1}return 0})()"
        plWeb?.evaluateJavascript(js) { r -> if (r != "1") loadPlaylist(t.substring(2), i, 0) }
    }

    /** player बाट अहिलेको episode, समय, कुल संख्या पढ्ने; रोकिएको ठाउँ सुरक्षित राख्ने */
    private fun poll() {
        val t = lastTarget ?: return
        val js = "(function(){var p=document.getElementById('movie_player');if(!p||!p.getCurrentTime)return null;var l=p.getPlaylist?p.getPlaylist():null;return {i:p.getPlaylistIndex?p.getPlaylistIndex():-1,t:p.getCurrentTime(),n:l?l.length:0,s:p.getPlayerState()}})()"
        plWeb?.evaluateJavascript(js) { r ->
            try {
                if (r == null || r == "null") return@evaluateJavascript
                val o = JSONObject(r)
                val i = o.optInt("i", -1); val sec = o.optDouble("t", 0.0); val n = o.optInt("n", 0); val st = o.optInt("s", -1)
                if (t != lastTarget) return@evaluateJavascript
                if (t.startsWith("p:")) {
                    if (n > 0 && n != total) { total = n; buildTabs() }
                    if (i >= 0 && i != cur) { cur = i; page = i / 10; buildTabs() } else refreshBlocks()
                }
                if ((st == 1 || st == 2) && sec >= 1) savePos(t, if (t.startsWith("p:")) maxOf(i, 0) else 0, sec)
                else if (st == 0) { if (t.startsWith("p:")) savePos(t, maxOf(i, 0), 0.0) else savePos(t, -1, 0.0) }
            } catch (e: Exception) { }
        }
    }

    /** १–१०, ११–२० ... का पाना (tab) बनाउने */
    private fun buildTabs() {
        val tb = tabs ?: return
        tb.removeAllViews()
        val pages = (total + 9) / 10
        for (pg in 0 until maxOf(pages, 1)) {
            val a = pg * 10 + 1
            val z = if (total > 0) minOf(pg * 10 + 10, total) else a + 9
            val v = TextView(this).apply {
                text = "$a–$z"; textSize = 13f; gravity = Gravity.CENTER
                setPadding((12 * dpf).toInt(), (6 * dpf).toInt(), (12 * dpf).toInt(), (6 * dpf).toInt())
                setTextColor(if (pg == page) Color.WHITE else Color.LTGRAY)
                setBackgroundColor(if (pg == page) Color.parseColor("#4682b4") else Color.parseColor("#23272e"))
                setOnClickListener { page = pg; buildTabs() }
            }
            tb.addView(v, LinearLayout.LayoutParams(-2, -2).apply { setMargins(2, 2, 2, 2) })
        }
        refreshBlocks()
    }

    private fun refreshBlocks() {
        for (k in cells.indices) {
            val n = page * 10 + k
            val b = cells[k]
            if (total > 0 && n >= total) { b.visibility = View.INVISIBLE; continue }
            b.visibility = View.VISIBLE
            b.text = "${n + 1}"
            val on = n == cur
            b.setTextColor(Color.WHITE)
            b.setBackgroundColor(if (on) Color.parseColor("#e53935") else Color.parseColor("#2d333c"))
        }
    }

    private fun linkOf(t: String) =
        if (t.startsWith("p:")) "https://www.youtube.com/playlist?list=${t.substring(2)}" else "https://youtu.be/${t.substring(2)}"

    private fun loadItems() {
        items.clear()
        try {
            val a = JSONArray(prefs.getString("list", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                var id = o.getString("id")
                if (!id.startsWith("v:") && !id.startsWith("p:")) id = "v:$id" // पुरानो Save
                items.add(Item(o.getString("n"), id))
            }
        } catch (e: Exception) { }
    }

    private fun saveItems() {
        val a = JSONArray()
        items.forEach { a.put(JSONObject().put("n", it.name).put("id", it.id)) }
        prefs.edit().putString("list", a.toString()).apply()
    }

    /** "v:<id>" (एउटा video), "p:<id>" (playlist), वा null */
    private fun parseTarget(input: String): String? {
        if (Regex("^[A-Za-z0-9_-]{11}$").matches(input)) return "v:$input"
        val list = Regex("[?&]list=([A-Za-z0-9_-]+)").find(input)?.groupValues?.get(1)
        val video = Regex("(?:v=|youtu\\.be/|embed/|shorts/|live/)([A-Za-z0-9_-]{11})").find(input)?.groupValues?.get(1)
        if (input.contains("/playlist") && list != null) return "p:$list"
        if (video != null) return "v:$video"
        if (list != null) return "p:$list"
        return null
    }

    override fun onPause() { poll(); handler.removeCallbacks(ticker); plWeb?.onPause(); super.onPause() }

    override fun onResume() { super.onResume(); plWeb?.onResume(); handler.removeCallbacks(ticker); handler.postDelayed(ticker, 2000) }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (customView != null) plWeb?.webChromeClient?.onHideCustomView() else super.onBackPressed()
    }

    override fun onDestroy() { handler.removeCallbacks(ticker); plWeb?.destroy(); super.onDestroy() }
}
