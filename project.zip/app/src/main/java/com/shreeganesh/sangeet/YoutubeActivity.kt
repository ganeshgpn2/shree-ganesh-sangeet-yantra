package com.shreeganesh.sangeet

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView
import org.json.JSONArray
import org.json.JSONObject

/** YouTube link paste गर्दा आफैँ बज्ने, नाम राखेर Save गर्न मिल्ने screen. */
class YoutubeActivity : Activity() {

    private class Item(var name: String, val id: String)

    private var playerView: YouTubePlayerView? = null
    private var player: YouTubePlayer? = null
    private var pendingId: String? = null
    private var lastId: String? = null
    private val items = ArrayList<Item>()
    private lateinit var adapter: ArrayAdapter<Item>

    private val prefs by lazy { getSharedPreferences("sgs_youtube", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#121417")) }

        // top bar
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#4682b4")); setPadding(dp(8), dp(28), dp(8), dp(8))
        }
        val back = Button(this).apply { text = "←"; setTextColor(Color.WHITE); setBackgroundColor(Color.TRANSPARENT); textSize = 22f; setOnClickListener { finish() } }
        val title = TextView(this).apply { text = "YOUTUBE"; setTextColor(Color.WHITE); textSize = 18f }
        bar.addView(back, LinearLayout.LayoutParams(dp(56), dp(48)))
        bar.addView(title)
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))

        // link row
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(12), dp(10), dp(12), 0) }
        val etLink = EditText(this).apply {
            hint = "YouTube link paste गर्नुहोस्"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            setSingleLine(); imeOptions = EditorInfo.IME_ACTION_GO
        }
        val go = Button(this).apply { text = "PLAY" }
        row1.addView(etLink, LinearLayout.LayoutParams(0, -2, 1f))
        row1.addView(go, LinearLayout.LayoutParams(-2, -2))
        root.addView(row1, LinearLayout.LayoutParams(-1, -2))

        // name + save row
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(12), 0, dp(12), 0) }
        val etName = EditText(this).apply {
            hint = "यो link को नाम (Save गर्न)"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            setSingleLine(); imeOptions = EditorInfo.IME_ACTION_DONE
        }
        val save = Button(this).apply { text = "SAVE" }
        row2.addView(etName, LinearLayout.LayoutParams(0, -2, 1f))
        row2.addView(save, LinearLayout.LayoutParams(-2, -2))
        root.addView(row2, LinearLayout.LayoutParams(-1, -2))

        // player
        val pv = YouTubePlayerView(this)
        playerView = pv
        pv.addYouTubePlayerListener(object : AbstractYouTubePlayerListener() {
            override fun onReady(youTubePlayer: YouTubePlayer) {
                player = youTubePlayer
                pendingId?.let { youTubePlayer.loadVideo(it, 0f); pendingId = null }
            }
        })
        root.addView(pv, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        // saved list
        val head = TextView(this).apply {
            text = "सुरक्षित (थिच्दा बज्छ · लामो थिच्दा मेट्ने/नाम बदल्ने)"
            setTextColor(Color.LTGRAY); textSize = 13f; setPadding(dp(14), dp(10), dp(14), dp(4))
        }
        root.addView(head, LinearLayout.LayoutParams(-1, -2))
        val list = ListView(this).apply { divider = null }
        adapter = object : ArrayAdapter<Item>(this, android.R.layout.simple_list_item_1, items) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent) as TextView
                v.text = "▶  " + items[position].name
                v.setTextColor(Color.WHITE); v.textSize = 16f; v.setPadding(dp(14), dp(12), dp(14), dp(12))
                return v
            }
        }
        list.adapter = adapter
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        loadItems()

        fun hideKb() = (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(etLink.windowToken, 0)

        fun playId(id: String) {
            lastId = id
            val p = player
            if (p != null) p.loadVideo(id, 0f) else pendingId = id
        }

        fun play() {
            val id = extractVideoId(etLink.text.toString().trim())
            if (id == null) { Toast.makeText(this, "Link मिलेन", Toast.LENGTH_SHORT).show(); return }
            hideKb(); playId(id)
        }

        go.setOnClickListener { play() }
        etLink.setOnEditorActionListener { _, a, _ -> if (a == EditorInfo.IME_ACTION_GO) { play(); true } else false }

        // link paste गर्नासाथ आफैँ बजाउने
        etLink.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val t = s.toString().trim()
                val id = if (t.length > 11) extractVideoId(t) else null
                if (id != null && id != lastId) { hideKb(); playId(id) }
            }
        })

        save.setOnClickListener {
            val id = extractVideoId(etLink.text.toString().trim())
            if (id == null) { Toast.makeText(this, "पहिले मान्य link राख्नुहोस्", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val name = etName.text.toString().trim().ifEmpty { "YouTube $id" }
            val old = items.find { it.id == id }
            if (old != null) old.name = name else items.add(0, Item(name, id))
            saveItems(); adapter.notifyDataSetChanged()
            etName.setText(""); hideKb()
            Toast.makeText(this, "Save भयो: $name", Toast.LENGTH_SHORT).show()
        }

        list.setOnItemClickListener { _, _, pos, _ ->
            val it = items[pos]
            etLink.setText("https://youtu.be/${it.id}")
            etLink.setSelection(etLink.text.length)
            playId(it.id)
        }

        list.setOnItemLongClickListener { _, _, pos, _ ->
            val it = items[pos]
            AlertDialog.Builder(this).setTitle(it.name)
                .setItems(arrayOf("नाम बदल्ने", "मेट्ने")) { _, which ->
                    if (which == 0) {
                        val e = EditText(this).apply { setText(it.name); setSelection(text.length) }
                        AlertDialog.Builder(this).setTitle("नयाँ नाम").setView(e)
                            .setPositiveButton("OK") { _, _ ->
                                val n = e.text.toString().trim()
                                if (n.isNotEmpty()) { it.name = n; saveItems(); adapter.notifyDataSetChanged() }
                            }.setNegativeButton("रद्द", null).show()
                    } else {
                        items.remove(it); saveItems(); adapter.notifyDataSetChanged()
                    }
                }.show()
            true
        }

        setContentView(root)
    }

    private fun loadItems() {
        items.clear()
        try {
            val a = JSONArray(prefs.getString("list", "[]"))
            for (i in 0 until a.length()) { val o = a.getJSONObject(i); items.add(Item(o.getString("n"), o.getString("id"))) }
        } catch (e: Exception) { }
    }

    private fun saveItems() {
        val a = JSONArray()
        items.forEach { a.put(JSONObject().put("n", it.name).put("id", it.id)) }
        prefs.edit().putString("list", a.toString()).apply()
    }

    private fun extractVideoId(input: String): String? {
        if (Regex("^[A-Za-z0-9_-]{11}$").matches(input)) return input
        return Regex("(?:v=|youtu\\.be/|embed/|shorts/|live/)([A-Za-z0-9_-]{11})").find(input)?.groupValues?.get(1)
    }

    override fun onPause() { player?.pause(); super.onPause() }

    override fun onDestroy() { playerView?.release(); super.onDestroy() }
}
