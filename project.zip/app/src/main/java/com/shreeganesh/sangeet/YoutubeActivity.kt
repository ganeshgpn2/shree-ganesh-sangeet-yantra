package com.shreeganesh.sangeet

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView

/** YouTube link/ID paste गरेर एप भित्रै video चलाउने screen (YouTube IFrame Player). */
class YoutubeActivity : Activity() {

    private var playerView: YouTubePlayerView? = null
    private var player: YouTubePlayer? = null
    private var pendingId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#121417")) }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#4682b4")); setPadding(dp(8), dp(28), dp(8), dp(8))
        }
        val back = Button(this).apply { text = "←"; setTextColor(Color.WHITE); setBackgroundColor(Color.TRANSPARENT); textSize = 22f; setOnClickListener { finish() } }
        val title = TextView(this).apply { text = "YOUTUBE"; setTextColor(Color.WHITE); textSize = 18f }
        bar.addView(back, LinearLayout.LayoutParams(dp(56), dp(48)))
        bar.addView(title)
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(12), dp(12), dp(12), dp(4)) }
        val et = EditText(this).apply {
            hint = "YouTube link वा video ID"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            setSingleLine(); imeOptions = EditorInfo.IME_ACTION_GO
        }
        val go = Button(this).apply { text = "PLAY" }
        row.addView(et, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(go, LinearLayout.LayoutParams(-2, -2))
        root.addView(row, LinearLayout.LayoutParams(-1, -2))

        val pv = YouTubePlayerView(this)
        playerView = pv
        pv.addYouTubePlayerListener(object : AbstractYouTubePlayerListener() {
            override fun onReady(youTubePlayer: YouTubePlayer) {
                player = youTubePlayer
                pendingId?.let { youTubePlayer.loadVideo(it, 0f); pendingId = null }
            }
        })
        root.addView(pv, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        fun play() {
            val id = extractVideoId(et.text.toString().trim())
            if (id == null) { Toast.makeText(this, "Link मिलेन", Toast.LENGTH_SHORT).show(); return }
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(et.windowToken, 0)
            val p = player
            if (p != null) p.loadVideo(id, 0f) else pendingId = id
        }
        go.setOnClickListener { play() }
        et.setOnEditorActionListener { _, a, _ -> if (a == EditorInfo.IME_ACTION_GO) { play(); true } else false }

        setContentView(root)
    }

    private fun extractVideoId(input: String): String? {
        if (Regex("^[A-Za-z0-9_-]{11}$").matches(input)) return input
        return Regex("(?:v=|youtu\\.be/|embed/|shorts/|live/)([A-Za-z0-9_-]{11})").find(input)?.groupValues?.get(1)
    }

    override fun onPause() { player?.pause(); super.onPause() }

    override fun onDestroy() { playerView?.release(); super.onDestroy() }
}
