package com.shreeganesh.sangeet

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

/** Rings while the alarm is active: alarm sound + full-screen notification with Stop/Snooze. */
class AlarmService : Service() {
    companion object {
        const val CH = "sgs_alarm"
        const val ID = 2
        const val A_RING = "sgs.RING"
        const val A_STOP = "sgs.ASTOP"
        const val A_SNOOZE = "sgs.ASNOOZE"
        const val A_HANDLED = "sgs.AHANDLED"
        fun cmd(c: Context, a: String) {
            try { c.startService(Intent(c, AlarmService::class.java).setAction(a)) } catch (e: Exception) { }
        }
    }

    private var mp: MediaPlayer? = null
    private var wake: PowerManager.WakeLock? = null
    private var baseId = ""
    private val h = Handler(Looper.getMainLooper())

    private fun pi(a: String) = PendingIntent.getService(
        this, a.hashCode(), Intent(this, AlarmService::class.java).setAction(a),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            A_RING -> ring(intent.getStringExtra("id") ?: "", intent.getBooleanExtra("snz", false))
            A_SNOOZE -> { if (baseId.isNotEmpty()) AlarmScheduler.snooze(this, baseId); end() }
            A_STOP, A_HANDLED -> end()
            else -> end()
        }
        return START_NOT_STICKY
    }

    private fun ring(id: String, snz: Boolean) {
        baseId = id
        val a = AlarmScheduler.find(this, id)
        val sched = a?.optString("mode") == "sched"
        val title = a?.optString("label").orEmpty().ifEmpty { "Alarm" }
        val text = (a?.optString("time").orEmpty() + "  " + a?.optString("name").orEmpty()).trim()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH, "Alarm", NotificationManager.IMPORTANCE_HIGH).apply { setSound(null, null) }
        )
        val open = PendingIntent.getActivity(
            this, 100,
            Intent(this, MainActivity::class.java)
                .putExtra("alarm_id", id).putExtra("alarm_snz", snz)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title).setContentText(text)
            .setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true)
            .setContentIntent(open)
            .setFullScreenIntent(open, true)
            .addAction(Notification.Action.Builder(null, "Snooze 5 min", pi(A_SNOOZE)).build())
            .addAction(Notification.Action.Builder(null, "Stop", pi(A_STOP)).build())
            .build()
        try {
            startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } catch (e: Exception) {
            nm.notify(ID, n)
        }
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sgs:alarm").apply { acquire(2 * 60_000L) }
        if (!sched) tone()
        h.removeCallbacksAndMessages(null)
        h.postDelayed({ end() }, 90_000)
    }

    private fun tone() {
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            mp?.release()
            mp = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
                )
                setDataSource(this@AlarmService, uri)
                isLooping = true
                prepare()
                start()
            }
        } catch (e: Exception) { }
    }

    private fun end() {
        h.removeCallbacksAndMessages(null)
        try { mp?.stop() } catch (e: Exception) { }
        mp?.release(); mp = null
        wake?.takeIf { it.isHeld }?.release()
        stopForeground(STOP_FOREGROUND_REMOVE)
        getSystemService(NotificationManager::class.java).cancel(ID)
        stopSelf()
    }

    override fun onDestroy() {
        mp?.release(); mp = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
