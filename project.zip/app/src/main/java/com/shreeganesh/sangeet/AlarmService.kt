package com.shreeganesh.sangeet

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import org.json.JSONArray

/**
 * Plays the alarm natively (no WebView needed). It tries several radio streams in turn:
 * the chosen station, its alternate URLs, then streams that worked recently on this phone.
 * If none works it plays the phone's alarm sound. Uses the ALARM audio stream, so it is
 * heard even in silent mode. Stops on "Stop" or automatically after the set minutes (default 30).
 */
class AlarmService : Service() {
    companion object {
        const val CH = "sgs_alarm_quiet"
        const val ID = 2
        const val A_RING = "sgs.RING"
        const val A_STOP = "sgs.ASTOP"
        const val A_SNOOZE = "sgs.ASNOOZE"
        const val DEFAULT_MINUTES = 30
        const val TRY_SECONDS = 10L
        const val MAX_FAILS = 8
        fun cmd(c: Context, a: String) {
            try { c.startService(Intent(c, AlarmService::class.java).setAction(a)) } catch (e: Exception) { }
        }
    }

    private var tonePlayer: MediaPlayer? = null
    private var exo: ExoPlayer? = null
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null
    private var focus: AudioFocusRequest? = null
    private var baseId = ""
    private var candidates: List<String> = emptyList()
    private var idx = 0
    private var fails = 0
    private var ringing = false
    private val h = Handler(Looper.getMainLooper())

    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ALARM)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()

    private fun pi(a: String) = PendingIntent.getService(
        this, a.hashCode(), Intent(this, AlarmService::class.java).setAction(a),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            A_RING -> ring(intent.getStringExtra("id") ?: "")
            A_SNOOZE -> { if (baseId.isNotEmpty()) AlarmScheduler.snooze(this, baseId); end() }
            else -> end()
        }
        return START_NOT_STICKY
    }

    /** Chosen URL + alternate URLs from the bundled database + recently working streams. */
    private fun buildCandidates(key: String, url: String): List<String> {
        val out = LinkedHashSet<String>()
        if (url.startsWith("http")) out.add(url)
        try {
            val txt = assets.open("database.json").bufferedReader().use { it.readText() }
            val radios = org.json.JSONObject(txt).getJSONArray("radios")
            for (i in 0 until radios.length()) {
                val r = radios.getJSONObject(i)
                if (r.optString("Key") == key) {
                    val s = r.optString("Stream URL", "")
                    if (s.startsWith("http")) out.add(s.trim())
                    r.optString("Alternate URLs", "").split(";", ",", " ", "\n")
                        .map { it.trim() }.filter { it.startsWith("http") }.forEach { out.add(it) }
                }
            }
        } catch (e: Exception) { }
        AlarmScheduler.recentRadios(this).forEach { out.add(it) }
        return out.toList().take(6)
    }

    private fun ring(id: String) {
        if (ringing) { endAudioOnly() }
        ringing = true
        baseId = id
        fails = 0; idx = 0
        val a = AlarmScheduler.find(this, id)
        val title = a?.optString("label").orEmpty().ifEmpty { "Alarm" }
        val name = a?.optString("name").orEmpty()
        val text = (a?.optString("time").orEmpty() + "  " + name).trim()
        val type = a?.optString("type").orEmpty()
        val url = a?.optString("url").orEmpty()
        val key = a?.optString("key").orEmpty()
        val minutes = (a?.optInt("dur", 0) ?: 0).let { if (it > 0) it else DEFAULT_MINUTES }

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH, "Alarm (playing)", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 100, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title).setContentText(text)
            .setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Snooze 5 min", pi(A_SNOOZE)).build())
            .addAction(Notification.Action.Builder(null, "Stop", pi(A_STOP)).build())
            .build()
        try {
            startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } catch (e: Exception) {
            nm.notify(ID, n)
        }

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake?.takeIf { it.isHeld }?.release()
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sgs:alarm").apply {
            acquire((minutes + 2) * 60_000L)
        }
        @Suppress("DEPRECATION")
        wifi = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
            .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "sgs:alarmwifi")
            .apply { setReferenceCounted(false); acquire() }

        ensureAlarmVolume()
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setAudioAttributes(attrs).build()
        am.requestAudioFocus(focus!!)

        PlayerBus.js?.invoke("try{ra.pause();au.pause();vd.pause()}catch(e){}")

        candidates = if (type == "r") buildCandidates(key, url) else emptyList()
        if (candidates.isEmpty()) tone() else playCandidate()

        h.postDelayed({ end() }, minutes * 60_000L) // automatic stop
    }

    private fun ensureAlarmVolume() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            if (am.getStreamVolume(AudioManager.STREAM_ALARM) < max / 2)
                am.setStreamVolume(AudioManager.STREAM_ALARM, (max * 0.6).toInt().coerceAtLeast(1), 0)
        } catch (e: Exception) { }
    }

    private fun releaseExo() {
        exo?.let { it.clearVideoSurface(); it.stop(); it.release() }
        exo = null
    }

    private fun releaseTone() {
        tonePlayer?.let { try { it.stop() } catch (e: Exception) { }; it.release() }
        tonePlayer = null
    }

    private val timeout = Runnable { failCurrent("timeout") }

    private fun playCandidate() {
        h.removeCallbacks(timeout)
        releaseExo()
        if (!ringing) return
        if (fails >= MAX_FAILS) { tone(); return }
        val url = candidates[idx % candidates.size]
        try {
            val http = DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(8000).setReadTimeoutMs(8000)
                .setUserAgent("Mozilla/5.0 (Linux; Android) ShreeGaneshSangeetYantra")
            val p = ExoPlayer.Builder(this)
                .setMediaSourceFactory(DefaultMediaSourceFactory(http))
                .setAudioAttributes(
                    androidx.media3.common.AudioAttributes.Builder()
                        .setUsage(C.USAGE_ALARM).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(),
                    false
                )
                .setWakeMode(C.WAKE_MODE_NETWORK)
                .build()
            p.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_READY) { h.removeCallbacks(timeout); fails = 0 }
                    if (state == Player.STATE_ENDED) failCurrent("ended")
                }
                override fun onPlayerError(error: PlaybackException) {
                    failCurrent(error.errorCodeName)
                }
            })
            p.setMediaItem(MediaItem.fromUri(url))
            p.volume = 1f
            p.playWhenReady = true
            p.prepare()
            exo = p
            h.postDelayed(timeout, TRY_SECONDS * 1000)
        } catch (e: Exception) {
            failCurrent(e.javaClass.simpleName)
        }
    }

    private fun failCurrent(why: String) {
        if (!ringing) return
        h.removeCallbacks(timeout)
        fails++
        try {
            Toast.makeText(this, "Radio " + (idx % candidates.size + 1) + "/" + candidates.size + " failed: " + why, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { }
        idx++
        h.postDelayed({ playCandidate() }, 1500)
    }

    private fun tone() {
        releaseExo(); releaseTone()
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            val m = MediaPlayer()
            m.setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            )
            m.setDataSource(this, uri)
            m.isLooping = true
            m.prepare()
            m.start()
            tonePlayer = m
        } catch (e: Exception) { }
    }

    private fun endAudioOnly() {
        h.removeCallbacksAndMessages(null)
        releaseExo(); releaseTone()
    }

    private fun end() {
        ringing = false
        endAudioOnly()
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            focus?.let { am.abandonAudioFocusRequest(it) }
        } catch (e: Exception) { }
        wake?.takeIf { it.isHeld }?.release()
        wifi?.takeIf { it.isHeld }?.release()
        stopForeground(STOP_FOREGROUND_REMOVE)
        getSystemService(NotificationManager::class.java).cancel(ID)
        stopSelf()
    }

    override fun onDestroy() {
        ringing = false
        endAudioOnly()
        wake?.takeIf { it.isHeld }?.release()
        wifi?.takeIf { it.isHeld }?.release()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
