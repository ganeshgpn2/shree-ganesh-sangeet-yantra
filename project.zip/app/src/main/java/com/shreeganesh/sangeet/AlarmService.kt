package com.shreeganesh.sangeet

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

/**
 * Plays the alarm natively (no WebView needed): the chosen network radio,
 * or the phone's alarm sound as a fallback. Uses the ALARM audio stream so it
 * is heard even when the phone is on silent. Stops only on "Stop", or
 * automatically after the configured minutes (default 30).
 */
class AlarmService : Service() {
    companion object {
        const val CH = "sgs_alarm_quiet"
        const val ID = 2
        const val A_RING = "sgs.RING"
        const val A_STOP = "sgs.ASTOP"
        const val A_SNOOZE = "sgs.ASNOOZE"
        const val DEFAULT_MINUTES = 30
        fun cmd(c: Context, a: String) {
            try { c.startService(Intent(c, AlarmService::class.java).setAction(a)) } catch (e: Exception) { }
        }
    }

    private var mp: MediaPlayer? = null
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null
    private var focus: AudioFocusRequest? = null
    private var baseId = ""
    private var failCount = 0
    private val h = Handler(Looper.getMainLooper())

    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ALARM)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()

    private fun pi(a: String) = PendingIntent.getService(
        this, a.hashCode(), Intent(this, AlarmService::class.java).setAction(a),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            A_RING -> ring(intent.getStringExtra("id") ?: "")
            A_SNOOZE -> { if (baseId.isNotEmpty()) AlarmScheduler.snooze(this, baseId); end() }
            else -> end()
        }
        return START_NOT_STICKY
    }

    private fun ring(id: String) {
        baseId = id
        failCount = 0
        val a = AlarmScheduler.find(this, id)
        val title = a?.optString("label").orEmpty().ifEmpty { "Alarm" }
        val name = a?.optString("name").orEmpty()
        val text = (a?.optString("time").orEmpty() + "  " + name).trim()
        val type = a?.optString("type").orEmpty()
        val url = a?.optString("url").orEmpty()
        val minutes = (a?.optInt("dur", 0) ?: 0).let { if (it > 0) it else DEFAULT_MINUTES }

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH, "Alarm (playing)", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 100, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title).setContentText(text)
            .setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Snooze 5 min", pi(A_SNOOZE)).build())
            .addAction(Notification.Action.Builder(null, "Stop", pi(A_STOP)).build())
            .build()
        try {
            startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } catch (e: Exception) {
            nm.notify(ID, n)
        }

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake?.takeIf { it.isHeld }?.release()
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sgs:alarm").apply {
            acquire((minutes + 2) * 60_000L)
        }
        @Suppress("DEPRECATION")
        wifi = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
            .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "sgs:alarmwifi")
            .apply { setReferenceCounted(false); acquire() }

        ensureAlarmVolume()
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setAudioAttributes(attrs).build()
        am.requestAudioFocus(focus!!)

        // Make sure the HTML app is not playing something at the same time.
        PlayerBus.js?.invoke("try{ra.pause();au.pause();vd.pause()}catch(e){}")

        if (type == "r" && url.startsWith("http")) startRadio(url) else tone()

        h.removeCallbacksAndMessages(null)
        h.postDelayed({ end() }, minutes * 60_000L) // automatic stop
    }

    private fun ensureAlarmVolume() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            if (am.getStreamVolume(AudioManager.STREAM_ALARM) < max / 2)
                am.setStreamVolume(AudioManager.STREAM_ALARM, (max * 0.6).toInt().coerceAtLeast(1), 0)
        } catch (e: Exception) { }
    }

    private fun releaseMp() {
        mp?.let {
            it.setOnErrorListener(null); it.setOnCompletionListener(null); it.setOnPreparedListener(null)
            try { it.stop() } catch (e: Exception) { }
            it.release()
        }
        mp = null
    }

    private fun startRadio(url: String) {
        releaseMp()
        try {
            val m = MediaPlayer()
            m.setAudioAttributes(attrs)
            m.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK)
            m.setDataSource(url)
            m.setOnPreparedListener { failCount = 0; it.start() }
            m.setOnErrorListener { _, _, _ -> retry(url); true }
            m.setOnCompletionListener { retry(url) }
            m.prepareAsync()
            mp = m
        } catch (e: Exception) {
            retry(url)
        }
    }

    private fun retry(url: String) {
        failCount++
        if (failCount > 6) { tone(); return } // radio not reachable: use alarm sound
        h.postDelayed({ startRadio(url) }, 3000)
    }

    private fun tone() {
        releaseMp()
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            val m = MediaPlayer()
            m.setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            )
            m.setDataSource(this, uri)
            m.isLooping = true
            m.prepare()
            m.start()
            mp = m
        } catch (e: Exception) { }
    }

    private fun end() {
        h.removeCallbacksAndMessages(null)
        releaseMp()
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            focus?.let { am.abandonAudioFocusRequest(it) }
        } catch (e: Exception) { }
        wake?.takeIf { it.isHeld }?.release()
        wifi?.takeIf { it.isHeld }?.release()
        stopForeground(STOP_FOREGROUND_REMOVE)
        getSystemService(NotificationManager::class.java).cancel(ID)
        stopSelf()
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        releaseMp()
        wake?.takeIf { it.isHeld }?.release()
        wifi?.takeIf { it.isHeld }?.release()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
