package com.shreeganesh.sangeet

/** Lets the native side (service, widgets) send commands to the HTML player. */
object PlayerBus {
    @Volatile var js: ((String) -> Unit)? = null

    fun toggle() = run("toggle", "")
    fun next() = run("next", "")
    fun prev() = run("prev", "")

    fun script(cmd: String, arg: String): String {
        val a = arg.replace(Regex("[^A-Za-z0-9_\\-:.]"), "")
        return when (cmd) {
            "toggle" -> "(function(){try{if(Q&&Q.length){toggle()}else{var l=allStations();if(l.length)playRadio(l,0)}}catch(e){}})()"
            "next" -> "try{step(1)}catch(e){}"
            "prev" -> "try{step(-1)}catch(e){}"
            "playfav" -> "(function(){try{var f=allStations().filter(function(x){return CFG.fav.r.indexOf(x.key)>=0});var i=f.findIndex(function(x){return x.key=='" + a + "'});if(i>=0)playRadio(f,i)}catch(e){}})()"
            "openalarm" -> "try{openO('als')}catch(e){}"
            else -> ""
        }
    }

    fun run(cmd: String, arg: String) {
        val s = script(cmd, arg)
        if (s.isNotEmpty()) js?.invoke(s)
    }
}
