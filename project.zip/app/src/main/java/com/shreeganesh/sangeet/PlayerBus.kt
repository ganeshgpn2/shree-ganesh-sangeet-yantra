package com.shreeganesh.sangeet

/** Lets the native service send commands (play/pause/next/prev) to the HTML player. */
object PlayerBus {
    @Volatile var js: ((String) -> Unit)? = null

    fun toggle() = js?.invoke("if(typeof toggle=='function')toggle()")
    fun next() = js?.invoke("if(typeof step=='function')step(1)")
    fun prev() = js?.invoke("if(typeof step=='function')step(-1)")
}
