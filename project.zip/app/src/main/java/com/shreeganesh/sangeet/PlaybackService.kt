package com.shreeganesh.sangeet

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.wifi.WifiManager
import android.os.IBinder
import android.os.PowerManager

class PlaybackService : Service() {

    companion object {
        const val CH = "sgs_playback"
        const val ID = 1
        const val A_UPDATE = "sgs.UPDATE"
        const val A_TOGGLE = "sgs.TOGGLE"
        const val A_NEXT = "sgs.NEXT"
        const val A_PREV = "sgs.PREV"
        @Volatile var running = false

        fun send(ctx: Context, title: String, sub: String, playing: Boolean) {
            val i = Intent(ctx, PlaybackService::class.java).setAction(A_UPDATE)
                .putExtra("t", title).putExtra("s", sub).putExtra("p", playing)
            try {
                if (running) ctx.startService(i)
                else if (playing) ctx.startForegroundService(i)
            } catch (e: Exception) {
            }
        }
    }

    private var session: MediaSession? = null
    private var title = "Shree Ganesh Sangeet Yantra"
    private var sub = ""
    private var playing = false
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH, "Playback", NotificationManager.IMPORTANCE_LOW)
        )
        session = MediaSession(this, "SGS").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() { if (!playing) PlayerBus.toggle() }
                override fun onPause() { if (playing) PlayerBus.toggle() }
                override fun onSkipToNext() { PlayerBus.next() }
                override fun onSkipToPrevious() { PlayerBus.prev() }
            })
            isActive = true
        }
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sgs:play").apply { setReferenceCounted(false) }
        @Suppress("DEPRECATION")
        wifi = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
            .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "sgs:wifi").apply { setReferenceCounted(false) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            A_UPDATE -> {
                title = intent.getStringExtra("t") ?: title
                sub = intent.getStringExtra("s") ?: ""
                playing = intent.getBooleanExtra("p", false)
            }
            A_TOGGLE -> PlayerBus.toggle()
            A_NEXT -> PlayerBus.next()
            A_PREV -> PlayerBus.prev()
        }
        refresh()
        return START_NOT_STICKY
    }

    private fun pi(a: String): PendingIntent = PendingIntent.getService(
        this, a.hashCode(), Intent(this, PlaybackService::class.java).setAction(a),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun act(icon: Int, label: String, a: String) =
        Notification.Action.Builder(Icon.createWithResource(this, icon), label, pi(a)).build()

    private fun refresh() {
        val s = session ?: return
        s.setMetadata(
            MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, sub)
                .putString(MediaMetadata.METADATA_KEY_ALBUM, "Shree Ganesh Sangeet Yantra")
                .build()
        )
        s.setPlaybackState(
            PlaybackState.Builder()
                .setActions(
                    PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or
                        PlaybackState.ACTION_PLAY_PAUSE or PlaybackState.ACTION_SKIP_TO_NEXT or
                        PlaybackState.ACTION_SKIP_TO_PREVIOUS
                )
                .setState(
                    if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                    PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1f
                ).build()
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setContentText(sub)
            .setContentIntent(open)
            .setOngoing(playing)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(act(android.R.drawable.ic_media_previous, "Previous", A_PREV))
            .addAction(
                if (playing) act(android.R.drawable.ic_media_pause, "Pause", A_TOGGLE)
                else act(android.R.drawable.ic_media_play, "Play", A_TOGGLE)
            )
            .addAction(act(android.R.drawable.ic_media_next, "Next", A_NEXT))
            .setStyle(
                Notification.MediaStyle()
                    .setMediaSession(s.sessionToken)
                    .setShowActionsInCompactView(0, 1, 2)
            )
            .build()

        var fg = false
        try {
            startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            fg = true
        } catch (e: Exception) {
        }
        if (playing) {
            wake?.takeIf { !it.isHeld }?.acquire()
            wifi?.takeIf { !it.isHeld }?.acquire()
        } else {
            if (fg) stopForeground(STOP_FOREGROUND_DETACH)
            wake?.takeIf { it.isHeld }?.release()
            wifi?.takeIf { it.isHeld }?.release()
        }
        getSystemService(NotificationManager::class.java).notify(ID, n)
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        running = false
        wake?.takeIf { it.isHeld }?.release()
        wifi?.takeIf { it.isHeld }?.release()
        session?.release()
        session = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
