package com.shreeganesh.sangeet

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.wifi.WifiManager
import android.content.ContentUris
import android.os.Handler
import android.provider.MediaStore
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import org.json.JSONArray
import org.json.JSONObject

class PlaybackService : Service() {

    companion object {
        const val CH = "sgs_playback"
        const val ID = 1
        const val A_UPDATE = "sgs.UPDATE"
        const val A_TOGGLE = "sgs.TOGGLE"
        const val A_NEXT = "sgs.NEXT"
        const val A_PREV = "sgs.PREV"
        const val A_R_PLAY = "sgs.R_PLAY"
        const val A_R_PLAYKEY = "sgs.R_PLAYKEY"
        const val A_R_TOGGLE = "sgs.R_TOGGLE"
        const val A_R_PAUSE = "sgs.R_PAUSE"
        const val A_R_RESUME = "sgs.R_RESUME"
        const val A_R_STOP = "sgs.R_STOP"
        const val A_R_PLAYONE = "sgs.R_PLAYONE"
        const val A_M_SEEKBY = "sgs.M_SEEKBY"
        const val A_STOP_ALL = "sgs.STOP_ALL"
        const val A_M_PLAY = "sgs.M_PLAY"
        const val A_M_PLAYKEY = "sgs.M_PLAYKEY"
        const val A_M_TOGGLE = "sgs.M_TOGGLE"
        const val A_M_PAUSE = "sgs.M_PAUSE"
        const val A_M_RESUME = "sgs.M_RESUME"
        const val A_M_STOP = "sgs.M_STOP"
        const val A_M_SEEK = "sgs.M_SEEK"
        const val A_M_NEXT = "sgs.M_NEXT"
        const val A_M_PREV = "sgs.M_PREV"
        @Volatile var running = false
        /** True while the Android (native) player is the one playing phone songs. */
        @Volatile var musicMode = false
        @Volatile var mShuf = false
        @Volatile var mRep = 0
        @Volatile var mEot = false

        fun musicCmd(ctx: Context, action: String, json: String = "", key: String = "", n: Long = 0L, d: Int = 0) {
            val i = Intent(ctx, PlaybackService::class.java).setAction(action)
                .putExtra("json", json).putExtra("key", key).putExtra("n", n).putExtra("d", d)
            try {
                val starting = action == A_M_PLAY || action == A_M_PLAYKEY || action == A_M_TOGGLE
                if (running) ctx.startService(i) else if (starting) ctx.startForegroundService(i)
            } catch (e: Exception) { }
        }

        fun musicFlags(shuf: Boolean, rep: Int, eot: Boolean) { mShuf = shuf; mRep = rep; mEot = eot }
        /** True while the Android (native) player is the one playing the radio. */
        @Volatile var radioMode = false
        @Volatile private var inst: PlaybackService? = null

        /** Radio commands. Start commands may start the service; others only reach a running service. */
        fun radioCmd(ctx: Context, action: String, json: String = "", key: String = "") {
            val i = Intent(ctx, PlaybackService::class.java).setAction(action)
                .putExtra("json", json).putExtra("key", key)
            try {
                val starting = action == A_R_PLAY || action == A_R_PLAYKEY || action == A_R_TOGGLE || action == A_R_PLAYONE
                if (running) ctx.startService(i) else if (starting) ctx.startForegroundService(i)
            } catch (e: Exception) { }
        }

        /** Simple commands from the widgets (only reach a running service). */
        fun sendAction(ctx: Context, action: String, n: Long = 0L) {
            if (!running) return
            try { ctx.startService(Intent(ctx, PlaybackService::class.java).setAction(action).putExtra("n", n)) } catch (e: Exception) { }
        }

        fun radioVolume(v: Float) {
            val s = inst ?: return
            Handler(Looper.getMainLooper()).post { s.exo?.volume = v.coerceIn(0f, 1f) }
        }

        fun radioStateJson(): String {
            val s = inst
            val o = JSONObject().put("mode", radioMode && s != null)
            if (s != null && radioMode) {
                o.put("idx", s.ri).put("playing", s.rPlay)
                o.put("q", JSONArray(s.rq.map { it.key }))
            }
            return o.toString()
        }

        fun send(ctx: Context, title: String, sub: String, playing: Boolean) {
            val i = Intent(ctx, PlaybackService::class.java).setAction(A_UPDATE)
                .putExtra("t", title).putExtra("s", sub).putExtra("p", playing)
            try {
                if (running) ctx.startService(i)
                else if (playing) ctx.startForegroundService(i)
            } catch (e: Exception) {
            }
        }
    }

    private class RSt(val name: String, val url: String, val key: String, val cat: String)

    private var session: MediaSession? = null
    @Volatile private var rq: List<RSt> = emptyList()
    @Volatile private var ri = 0
    @Volatile private var rPlay = false
    private var exo: ExoPlayer? = null
    @Volatile private var aq: List<Long> = emptyList()
    @Volatile private var ai = 0
    @Volatile private var aPlay = false
    private val metaCache = HashMap<Long, MediaScanner.Meta>()
    private var lastPackLv = -1
    private val posTick = object : Runnable {
        override fun run() {
            if (!musicMode) return
            val p = exo
            if (p != null) {
                val d = if (p.duration > 0) p.duration else 0L
                PlayerBus.js?.invoke("window.__sgsPos&&window.__sgsPos(" + p.currentPosition + "," + d + "," + (if (aPlay) 1 else 0) + ")")
                if (aPlay && d > 0) { // cassette widget: redraw only when the tape pack changes size (a few times per song)
                    val lv = WidgetUpdater.packLevelOf(p.currentPosition.toDouble() / d)
                    if (lv != lastPackLv) { lastPackLv = lv; try { WidgetUpdater.updateAll(this@PlaybackService) } catch (e: Exception) { } }
                }
            }
            h.postDelayed(this, 500)
        }
    }
    private var cands: List<String> = emptyList()
    private var ci = 0
    private var rRetry = 0
    private val h = Handler(Looper.getMainLooper())
    private val rTimeout = Runnable { failCand("timeout") }
    private val idleStop = Runnable {
        if (!rPlay && !aPlay) { try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Exception) { }; stopSelf() }
    }
    private var title = "Shree Ganesh Sangeet Yantra"
    private var sub = ""
    private var playing = false
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        inst = this
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH, "Playback", NotificationManager.IMPORTANCE_LOW)
        )
        session = MediaSession(this, "SGS").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() { if (radioMode) { if (!rPlay) radioToggle() } else if (musicMode) { if (!aPlay) musicToggle() } else if (!playing) PlayerBus.toggle() }
                override fun onPause() { if (radioMode) { if (rPlay) radioToggle() } else if (musicMode) { if (aPlay) musicToggle() } else if (playing) PlayerBus.toggle() }
                override fun onSkipToNext() { if (radioMode) radioStep(1) else if (musicMode) musicStep(1) else PlayerBus.next() }
                override fun onSkipToPrevious() { if (radioMode) radioStep(-1) else if (musicMode) musicStep(-1) else PlayerBus.prev() }
                override fun onSeekTo(pos: Long) { if (musicMode) musicSeek(pos) }
            })
            isActive = true
        }
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sgs:play").apply { setReferenceCounted(false) }
        @Suppress("DEPRECATION")
        wifi = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
            .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "sgs:wifi").apply { setReferenceCounted(false) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        var handled = false
        when (intent?.action) {
            A_UPDATE -> {
                title = intent.getStringExtra("t") ?: title
                sub = intent.getStringExtra("s") ?: ""
                playing = intent.getBooleanExtra("p", false)
            }
            A_TOGGLE -> if (radioMode) { radioToggle(); handled = true } else if (musicMode) { musicToggle(); handled = true } else PlayerBus.toggle()
            A_NEXT -> if (radioMode) { radioStep(1); handled = true } else if (musicMode) { musicStep(1); handled = true } else PlayerBus.next()
            A_PREV -> if (radioMode) { radioStep(-1); handled = true } else if (musicMode) { musicStep(-1); handled = true } else PlayerBus.prev()
            A_M_PLAY -> { musicPlayJson(intent.getStringExtra("json") ?: ""); handled = true }
            A_M_PLAYKEY -> { musicPlayKey(intent.getStringExtra("key") ?: "", intent.getIntExtra("d", 0)); handled = true }
            A_M_TOGGLE -> { musicToggle(); handled = true }
            A_M_PAUSE -> { if (musicMode && exo?.playWhenReady == true) exo?.playWhenReady = false; handled = true }
            A_M_RESUME -> { musicResume(); handled = true }
            A_M_STOP -> { musicStop(); handled = true }
            A_M_SEEK -> { musicSeek(intent.getLongExtra("n", 0L)); handled = true }
            A_M_NEXT -> { musicStep(1); handled = true }
            A_M_PREV -> { musicStep(-1); handled = true }
            A_R_PLAY -> { radioPlayJson(intent.getStringExtra("json") ?: ""); handled = true }
            A_R_PLAYKEY -> { radioPlayKey(intent.getStringExtra("key") ?: ""); handled = true }
            A_R_TOGGLE -> { radioToggle(); handled = true }
            A_R_PAUSE -> { if (exo?.playWhenReady == true) exo?.playWhenReady = false; handled = true }
            A_R_RESUME -> { radioResume(); handled = true }
            A_R_STOP -> { radioStop(); handled = true }
            A_R_PLAYONE -> { radioPlayOne(intent.getStringExtra("json") ?: ""); handled = true }
            A_M_SEEKBY -> { musicSeekBy(intent.getLongExtra("n", 0L)); handled = true }
            A_STOP_ALL -> { stopAll(); handled = true }
        }
        if (!handled) refresh()
        return START_NOT_STICKY
    }

    private fun pi(a: String): PendingIntent = PendingIntent.getService(
        this, a.hashCode(), Intent(this, PlaybackService::class.java).setAction(a),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun act(icon: Int, label: String, a: String) =
        Notification.Action.Builder(Icon.createWithResource(this, icon), label, pi(a)).build()

    private fun refresh() {
        val s = session ?: return
        s.setMetadata(
            MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, sub)
                .putString(MediaMetadata.METADATA_KEY_ALBUM, "Shree Ganesh Sangeet Yantra")
                .build()
        )
        s.setPlaybackState(
            PlaybackState.Builder()
                .setActions(
                    PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or
                        PlaybackState.ACTION_PLAY_PAUSE or PlaybackState.ACTION_SKIP_TO_NEXT or
                        PlaybackState.ACTION_SKIP_TO_PREVIOUS
                )
                .setState(
                    if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                    PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1f
                ).build()
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setContentText(sub)
            .setContentIntent(open)
            .setOngoing(playing)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(act(android.R.drawable.ic_media_previous, "Previous", A_PREV))
            .addAction(
                if (playing) act(android.R.drawable.ic_media_pause, "Pause", A_TOGGLE)
                else act(android.R.drawable.ic_media_play, "Play", A_TOGGLE)
            )
            .addAction(act(android.R.drawable.ic_media_next, "Next", A_NEXT))
            .setStyle(
                Notification.MediaStyle()
                    .setMediaSession(s.sessionToken)
                    .setShowActionsInCompactView(0, 1, 2)
            )
            .build()

        var fg = false
        try {
            startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            fg = true
        } catch (e: Exception) {
        }
        if (playing) {
            wake?.takeIf { !it.isHeld }?.acquire()
            wifi?.takeIf { !it.isHeld }?.acquire()
        } else {
            if (fg) stopForeground(STOP_FOREGROUND_DETACH)
            wake?.takeIf { it.isHeld }?.release()
            wifi?.takeIf { it.isHeld }?.release()
        }
        getSystemService(NotificationManager::class.java).notify(ID, n)
    }

    // ================= Android (native) radio player =================

    private fun radioPlayJson(json: String) {
        try {
            val o = JSONObject(json)
            val a = o.getJSONArray("q")
            val list = ArrayList<RSt>()
            for (i in 0 until a.length()) {
                val x = a.getJSONObject(i)
                val u = x.optString("u")
                if (u.startsWith("http")) list.add(RSt(x.optString("n"), u, x.optString("k", u), x.optString("c")))
            }
            val want = o.optInt("i", 0)
            val key = a.optJSONObject(want)?.optString("k")
            rq = list
            ri = list.indexOfFirst { it.key == key }.let { if (it < 0) 0 else it }
            if (rq.isEmpty()) return
            radioMode = true
            startStation(true)
        } catch (e: Exception) { }
    }

    private fun radioPlayOne(json: String) {
        try {
            val o = JSONObject(json)
            val key = o.optString("k")
            val url = o.optString("u", key)
            if (!url.startsWith("http")) return
            val list = WidgetState.favs(this).filter { it.key.startsWith("http") }
                .map { RSt(it.name, it.key, it.key, it.cat) }.toMutableList()
            var i = list.indexOfFirst { it.key == key }
            if (i < 0) { list.add(0, RSt(o.optString("n"), url, key, o.optString("c"))); i = 0 }
            rq = list; ri = i
            radioMode = true
            startStation(true)
        } catch (e: Exception) { }
    }

    private fun radioPlayKey(key: String) {
        val favs = WidgetState.favs(this).filter { it.key.startsWith("http") }
        if (favs.isEmpty()) return
        rq = favs.map { RSt(it.name, it.key, it.key, it.cat) }
        ri = rq.indexOfFirst { it.key == key }.let { if (it < 0) 0 else it }
        radioMode = true
        startStation(true)
    }

    private fun radioStep(d: Int) {
        if (rq.isEmpty()) return
        ri = (ri + d + rq.size) % rq.size
        startStation(false)
    }

    private fun radioToggle() {
        val p = exo
        if (p == null || p.playbackState == Player.STATE_IDLE || p.playbackState == Player.STATE_ENDED) {
            if (rq.isNotEmpty()) { radioMode = true; startStation(false) }
            return
        }
        p.playWhenReady = !p.playWhenReady
    }

    private fun radioResume() {
        val p = exo
        if (p == null || p.playbackState == Player.STATE_IDLE) { if (rq.isNotEmpty() && radioMode) startStation(false) }
        else if (!p.playWhenReady) p.playWhenReady = true
    }

    private fun radioStop() {
        h.removeCallbacks(rTimeout)
        try { exo?.stop() } catch (e: Exception) { }
        radioMode = false
        rPlay = false
    }

    private fun ensureExo(): ExoPlayer {
        exo?.let { return it }
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(8000).setReadTimeoutMs(10000)
            .setUserAgent("Mozilla/5.0 (Linux; Android) ShreeGaneshSangeetYantra")
        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http))) // web, phone files (content://) and more
            .setAudioAttributes(
                androidx.media3.common.AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
        p.addListener(object : Player.Listener {
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                if (radioMode) { rPlay = playWhenReady; syncOut(false) }
                else if (musicMode) { aPlay = playWhenReady; syncMusic(false) }
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (radioMode) {
                    if (state == Player.STATE_READY) {
                        h.removeCallbacks(rTimeout)
                        rRetry = 0
                        cands.getOrNull(ci)?.let { AlarmScheduler.rememberRadio(this@PlaybackService, it) }
                        syncOut(false)
                    } else if (state == Player.STATE_ENDED) {
                        failCand("ended")
                    }
                } else if (musicMode) {
                    if (state == Player.STATE_ENDED) musicEnded()
                    else if (state == Player.STATE_READY) syncMusic(false)
                }
            }
            override fun onPlayerError(error: PlaybackException) {
                if (radioMode) failCand(error.errorCodeName)
                else if (musicMode) musicError(error.errorCodeName)
            }
        })
        exo = p
        return p
    }

    private fun startStation(queueChanged: Boolean) {
        val st = rq.getOrNull(ri) ?: return
        h.removeCallbacks(idleStop)
        musicMode = false
        h.removeCallbacks(posTick)
        cands = RadioDb.candidates(this, st.url).ifEmpty { listOf(st.url) }
        ci = 0
        rRetry = 0
        rPlay = true
        syncOut(queueChanged) // shows the notification at once
        startCand()
    }

    private fun startCand() {
        if (!radioMode) return
        h.removeCallbacks(rTimeout)
        try {
            val p = ensureExo()
            p.setMediaItem(MediaItem.fromUri(cands[ci]))
            p.prepare()
            p.playWhenReady = true
            h.postDelayed(rTimeout, 12_000)
        } catch (e: Exception) {
            failCand(e.javaClass.simpleName)
        }
    }

    /** Try the next address of the station; if all fail, retry a few times (network may be back). */
    private fun failCand(why: String) {
        if (!radioMode) return
        h.removeCallbacks(rTimeout)
        ci++
        if (ci < cands.size) { startCand(); return }
        rRetry++
        if (rRetry <= 4) {
            ci = 0
            h.postDelayed({ startCand() }, 3000L * rRetry)
        } else {
            try { exo?.stop() } catch (e: Exception) { }
            rPlay = false
            val st = rq.getOrNull(ri)
            try { Toast.makeText(this, "Radio बजेन: " + (st?.name ?: "") + " ($why)", Toast.LENGTH_LONG).show() } catch (e: Exception) { }
            // let the HTML player try in its own way
            PlayerBus.js?.invoke("window.__sgsNative&&window.__sgsNative({fail:1})")
            radioMode = false
            playing = false
            refresh()
        }
    }

    /** Tell the notification, widgets and (if open) the HTML screen about the current state. */
    private fun syncOut(sendQueue: Boolean) {
        val st = rq.getOrNull(ri) ?: return
        title = st.name
        sub = "Radio · " + st.cat.ifEmpty { "Live" }
        playing = rPlay
        refresh()
        try {
            WidgetState.saveState(
                this,
                JSONObject().put("t", st.name).put("s", sub).put("p", rPlay).put("k", "r")
                    .put("key", st.key).put("pos", exo?.currentPosition ?: 0L).put("dur", 0).toString()
            )
            WidgetUpdater.updateAll(this)
        } catch (e: Exception) { }
        val m = JSONObject().put("idx", ri).put("playing", rPlay)
        if (sendQueue) m.put("q", JSONArray(rq.map { it.key }))
        PlayerBus.js?.invoke("window.__sgsNative&&window.__sgsNative($m)")
        h.removeCallbacks(idleStop)
        if (!rPlay) h.postDelayed(idleStop, 30 * 60_000L)
    }

    // ================= Android (native) music player =================

    private fun metaOf(id: Long): MediaScanner.Meta = metaCache.getOrPut(id) { MediaScanner.audioInfo(this, id) }

    private fun musicPlayJson(json: String) {
        try {
            val o = JSONObject(json)
            if (o.has("ids")) {
                val a = o.getJSONArray("ids")
                val l = ArrayList<Long>(a.length())
                for (i in 0 until a.length()) l.add(a.getLong(i))
                aq = l
            }
            if (aq.isEmpty()) {
                PlayerBus.js?.invoke("window.__sgsNativeM&&window.__sgsNativeM({fail:1})")
                return
            }
            ai = o.optInt("i", 0).coerceIn(0, aq.size - 1)
            startTrack(true)
        } catch (e: Exception) { }
    }

    /** Used by the Music widget: play (or step from) a song even when the app screen is closed. */
    private fun musicPlayKey(key: String, delta: Int) {
        val ids = if (aq.isEmpty()) MediaScanner.audioIds(this) else aq
        if (ids.isEmpty()) return
        aq = ids
        val id = key.removePrefix("ms:a").toLongOrNull()
        var i = if (id == null) 0 else ids.indexOf(id).let { if (it < 0) 0 else it }
        if (delta != 0 && id != null) i = (i + delta + ids.size) % ids.size
        ai = i
        startTrack(true)
    }

    private fun startTrack(queueChanged: Boolean) {
        val id = aq.getOrNull(ai) ?: return
        h.removeCallbacks(idleStop)
        h.removeCallbacks(rTimeout)
        radioMode = false
        musicMode = true
        aPlay = true
        syncMusic(queueChanged) // notification at once
        try {
            val p = ensureExo()
            p.setMediaItem(MediaItem.fromUri(ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)))
            p.prepare()
            p.playWhenReady = true
        } catch (e: Exception) {
            musicError(e.javaClass.simpleName)
        }
        h.removeCallbacks(posTick)
        h.post(posTick)
    }

    private fun nextIndex(d: Int): Int {
        if (aq.size <= 1) return 0
        return if (mShuf) {
            var r = (0 until aq.size).random()
            if (r == ai) r = (r + 1) % aq.size
            r
        } else (ai + d + aq.size) % aq.size
    }

    private fun musicStep(d: Int) {
        if (aq.isEmpty()) return
        ai = nextIndex(d)
        startTrack(false)
    }

    private fun musicToggle() {
        val p = exo
        if (p == null || p.playbackState == Player.STATE_IDLE || p.playbackState == Player.STATE_ENDED) {
            if (aq.isNotEmpty()) startTrack(false)
            return
        }
        p.playWhenReady = !p.playWhenReady
    }

    private fun musicResume() {
        val p = exo
        if (p == null || p.playbackState == Player.STATE_IDLE) { if (aq.isNotEmpty() && musicMode) startTrack(false) }
        else if (!p.playWhenReady) p.playWhenReady = true
    }

    private fun musicSeekBy(delta: Long) {
        val p = exo ?: return
        if (!musicMode) return
        val dur = if (p.duration > 0) p.duration else Long.MAX_VALUE
        p.seekTo((p.currentPosition + delta).coerceIn(0, dur))
        syncMusic(false)
    }

    /** Stop button of the cassette widget: stop everything and remove the notification. */
    private fun stopAll() {
        radioStop(); musicStop()
        h.removeCallbacksAndMessages(null)
        playing = false; rPlay = false; aPlay = false
        PlayerBus.js?.invoke("try{ra.pause();au.pause();vd.pause()}catch(e){}")
        WidgetState.setPlaying(this, false)
        try { WidgetUpdater.updateAll(this) } catch (e: Exception) { }
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Exception) { }
        getSystemService(NotificationManager::class.java).cancel(ID)
        stopSelf()
    }

    private fun musicSeek(ms: Long) {
        try { exo?.seekTo(ms.coerceAtLeast(0)) } catch (e: Exception) { }
        syncMusic(false)
    }

    private fun musicStop() {
        h.removeCallbacks(posTick)
        try { exo?.stop() } catch (e: Exception) { }
        musicMode = false
        aPlay = false
    }

    /** A song finished: stop (sleep timer), repeat, or go to the next one. */
    private fun musicEnded() {
        val p = exo ?: return
        if (mEot) { // "stop when this song finishes"
            p.playWhenReady = false
            aPlay = false
            syncMusic(false)
            return
        }
        if (mRep == 2) { p.seekTo(0); p.playWhenReady = true; return }
        val last = !mShuf && ai + 1 >= aq.size
        if (last && mRep != 1) { // end of the list
            p.playWhenReady = false
            aPlay = false
            syncMusic(false)
            return
        }
        ai = if (last) 0 else nextIndex(1)
        startTrack(false)
    }

    private fun musicError(why: String) {
        try { Toast.makeText(this, "गीत बजेन ($why)", Toast.LENGTH_SHORT).show() } catch (e: Exception) { }
        if (aq.size > 1) { ai = (ai + 1) % aq.size; h.postDelayed({ if (musicMode) startTrack(false) }, 800) }
        else { aPlay = false; syncMusic(false) }
    }

    private fun syncMusic(sendQueue: Boolean) {
        val id = aq.getOrNull(ai) ?: return
        val m = metaOf(id)
        title = m.name.ifEmpty { "Music" }
        sub = m.artist
        playing = aPlay
        refresh()
        try {
            WidgetState.saveState(
                this,
                JSONObject().put("t", title).put("s", sub).put("p", aPlay).put("k", "a")
                    .put("key", "ms:a$id").put("pos", exo?.currentPosition ?: 0L).put("dur", m.durMs).toString()
            )
            WidgetUpdater.updateAll(this)
        } catch (e: Exception) { }
        val msg = JSONObject().put("idx", ai).put("cid", id).put("playing", aPlay)
            .put("dur", m.durMs).put("pos", exo?.currentPosition ?: 0L)
        if (sendQueue) msg.put("q", JSONArray(aq))
        PlayerBus.js?.invoke("window.__sgsNativeM&&window.__sgsNativeM($msg)")
        h.removeCallbacks(idleStop)
        if (!aPlay) h.postDelayed(idleStop, 30 * 60_000L)
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        if (!((radioMode && rPlay) || (musicMode && aPlay))) stopSelf() // the Android radio player keeps playing without the app screen
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        running = false
        radioMode = false
        musicMode = false
        inst = null
        h.removeCallbacksAndMessages(null)
        try { exo?.release() } catch (e: Exception) { }
        exo = null
        WidgetState.setPlaying(this, false)
        try { WidgetUpdater.updateAll(this) } catch (e: Exception) { }
        wake?.takeIf { it.isHeld }?.release()
        wifi?.takeIf { it.isHeld }?.release()
        session?.release()
        session = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
