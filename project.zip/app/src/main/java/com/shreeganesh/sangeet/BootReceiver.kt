package com.shreeganesh.sangeet

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Re-creates all alarms and refreshes widgets after phone restart, app update, or time change. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) WidgetState.setPlaying(ctx, false)
        AlarmScheduler.scheduleAll(ctx)
        WidgetUpdater.scheduleMidnight(ctx)
        try { WidgetState.reconcile(ctx); WidgetUpdater.updateAll(ctx) } catch (e: Exception) { }
    }
}
