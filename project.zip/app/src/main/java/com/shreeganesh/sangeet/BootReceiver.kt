package com.shreeganesh.sangeet

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Re-creates all alarms after phone restart, app update, or time change. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        AlarmScheduler.scheduleAll(ctx)
    }
}
