# Shree Ganesh Sangeet Yantra V9
Step 1: native Android WebView shell + V8 HTML + Excel database (database/database.json).

## Cassette / CD widget (step34, step35)
`app/src/main/res/layout/widget_cassette.xml` and the `ck_*` images are GENERATED from the real Now Playing SVG skins
(`assets/index.html`) by `python3 tools/gen_widget_from_svg.py` (needs python3 + playwright/chromium).
Same 360 x 322 design grid, same 10 skins (5 cassette + 5 CD), same key row (7 keys, play/pause shares the middle key).
If a Now Playing skin changes, run the script again. Old Pillow generators are in `tools/old/` (not used any more).
step35: widget is letter-boxed to the exact 360:322 ratio of Now Playing (WidgetUpdater.fitAspect) so wheels stay round and the size
matches; reels turn at the Now Playing speed (Now Playing reels 2.8 s/turn; widget reels 30 frames x 187 ms (calibrated on the phone, see REEL_FLIP_MS), disc 1.8 s/turn); art is rendered with the real page CSS.

## YouTube: क्रम-संख्या block र resume
- Playlist बज्दा १–१०, ११–२० ... का पाना र नम्बर block (थिच्दा त्यही episode बज्छ)।
- रोकिएको episode र समय हरेक २ सेकेन्डमा SharedPreferences "sgs_youtube" (key "pos") मा सुरक्षित; फेरि बजाउँदा त्यहीँबाट।

## भाषा (English / नेपाली)
- पूर्वनिर्धारित English। Settings → Language बाट नेपाली छान्न मिल्छ (localStorage "sgs-lang"; native भागका लागि Lang.kt)।
- app/src/main/assets/i18n.js: नेपाली पाठ → English शब्दकोश; MutationObserver ले नयाँ पाठ आफैँ अनुवाद गर्छ। नयाँ नेपाली पाठ थपे यहाँ [नेपाली, English] जोडी थप्नुहोस्।
