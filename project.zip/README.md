# Shree Ganesh Sangeet Yantra V9
Step 1: native Android WebView shell + V8 HTML + Excel database (database/database.json).
